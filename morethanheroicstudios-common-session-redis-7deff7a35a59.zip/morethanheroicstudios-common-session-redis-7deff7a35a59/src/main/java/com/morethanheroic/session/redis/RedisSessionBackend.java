package com.morethanheroic.session.redis;

import com.morethanheroic.dependencyinjection.condition.ConditionalOnPropertyExists;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.RedisPassword;
import org.springframework.data.redis.connection.RedisStandaloneConfiguration;
import org.springframework.data.redis.connection.lettuce.LettuceConnectionFactory;
import org.springframework.session.data.redis.config.annotation.web.http.EnableRedisHttpSession;

@Slf4j
@Configuration
@EnableRedisHttpSession(maxInactiveIntervalInSeconds = 31556926)
@ConditionalOnPropertyExists(value = "session.backend.redis")
public class RedisSessionBackend {

    @Value("${common.session.redis.host-name}")
    private String redisHostName;

    @Value("${common.session.redis.port}")
    private int redisPort;

    @Value("${common.session.redis.password:''}")
    private String redisPassword;

    @Bean
    public LettuceConnectionFactory redisConnectionFactory() {
        log.info("Using Redis as session backend!");
        log.info("Connecting to Redis at " + redisHostName + ":" + redisPort + "!");

        final RedisStandaloneConfiguration redisStandaloneConfiguration = new RedisStandaloneConfiguration();

        redisStandaloneConfiguration.setHostName(redisHostName);
        redisStandaloneConfiguration.setPort(redisPort);

        if (!redisPassword.isEmpty()) {
            redisStandaloneConfiguration.setPassword(RedisPassword.of(redisPassword));
        }

        return new LettuceConnectionFactory(redisStandaloneConfiguration);
    }
}
