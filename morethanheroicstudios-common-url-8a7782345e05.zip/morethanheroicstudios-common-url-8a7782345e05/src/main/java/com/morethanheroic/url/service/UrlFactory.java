package com.morethanheroic.url.service;

import org.springframework.stereotype.Service;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Optional;

@Service
public class UrlFactory {

    public Optional<URL> newURL(final String location) {
        if (location.isEmpty()) {
            return Optional.empty();
        }

        try {
            return Optional.of(new URL(location));
        } catch (MalformedURLException e) {
            return Optional.empty();
        }
    }
}
