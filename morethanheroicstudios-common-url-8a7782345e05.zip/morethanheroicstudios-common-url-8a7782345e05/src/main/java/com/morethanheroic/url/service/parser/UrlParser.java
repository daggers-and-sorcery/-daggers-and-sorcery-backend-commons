package com.morethanheroic.url.service.parser;

import org.apache.commons.io.FilenameUtils;
import org.springframework.stereotype.Service;

import java.net.URL;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Optional;

@Service
public class UrlParser {

    public Optional<String> parseExtension(final URL url) {
        final String path3 = url.getPath();

        if (path3 == null) {
            return Optional.empty();
        }

        Path path = Paths.get(path3);

        if (path == null) {
            return Optional.empty();
        }

        final Path path2 = path.getFileName();

        if (path2 == null) {
            return Optional.empty();
        }

        final String extension = FilenameUtils.getExtension(path2.toString()).toLowerCase()
                .replaceAll(";.*", "");

        return Optional.of(extension);
    }
}
