package com.morethanheroic.url.service.entity;

import com.morethanheroic.url.domain.UrlEntity;
import com.morethanheroic.url.service.UrlFactory;
import com.morethanheroic.url.service.parser.UrlParser;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.net.URL;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class UrlEntityFactory {

    private final UrlParser urlParser;
    private final UrlFactory urlFactory;

    public Optional<UrlEntity> newEntity(final String url) {
        final Optional<URL> entryUrl = urlFactory.newURL(url);

        if (!entryUrl.isPresent()) {
            return Optional.empty();
        }

        final URL realUrl = entryUrl.get();

        return urlParser.parseExtension(entryUrl.get())
                .map(extension -> UrlEntity.builder()
                        .url(url)
                        .protocol(realUrl.getProtocol())
                        .host(realUrl.getHost())
                        .extension(extension)
                        .build()
                );

    }
}
