package com.morethanheroic.url.domain;

import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class UrlEntity {

    private final String url;
    private final String extension;
    private final String protocol;
    private final String host;
}
