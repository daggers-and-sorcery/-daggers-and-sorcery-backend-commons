# Common URL

## Changelog

- ***1.0.0***
    - Initial release with the UrlEntity domain and the required services.