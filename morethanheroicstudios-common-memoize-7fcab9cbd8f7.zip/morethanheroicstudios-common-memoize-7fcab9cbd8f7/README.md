# Common Memoize

## Changelog

- ***1.1.0***
    - Updated Gradle version to 5.0-rc-1.
    - Updated Java version to Java 11.
    - Updated Spring Boot version to 2.1.0.RELEASE.
    - Replaced compile lombok dependency with compileOnly.