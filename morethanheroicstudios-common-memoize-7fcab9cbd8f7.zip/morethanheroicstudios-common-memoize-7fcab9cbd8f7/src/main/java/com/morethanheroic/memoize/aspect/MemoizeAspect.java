package com.morethanheroic.memoize.aspect;

import com.morethanheroic.memoize.context.InvocationContext;
import com.morethanheroic.memoize.service.RequestScopeCache;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;

/**
 * This aspect is used to create the memoize functionality with the {@link com.morethanheroic.memoize.Memoize} annotation.
 *
 * @see <a href="https://en.wikipedia.org/wiki/Memoization">https://en.wikipedia.org/wiki/Memoization</a>
 */
@Slf4j
@Aspect
@Component
public class MemoizeAspect {

    @Autowired
    private RequestScopeCache requestScopeCache;

    @Around("@annotation(com.morethanheroic.memoize.Memoize)")
    @SuppressWarnings("checkstyle:illegalthrows")
    public Object memoize(ProceedingJoinPoint proceedingJoinPoint) throws Throwable {
        if (!isRequestContext()) {
            return proceedingJoinPoint.proceed();
        }

        final InvocationContext invocationContext = buildInvocationContext(proceedingJoinPoint);

        Object result = requestScopeCache.get(invocationContext);
        if (RequestScopeCache.NONE == result) {
            result = proceedingJoinPoint.proceed();

            log.debug("Memoizing result: " + result + ", for method invocation: " + invocationContext);

            requestScopeCache.put(invocationContext, result);
        } else {
            log.debug("Using memoized result: " + result + ", for method invocation: " + invocationContext);
        }

        return result;
    }

    private InvocationContext buildInvocationContext(ProceedingJoinPoint proceedingJoinPoint) {
        return new InvocationContext(
                proceedingJoinPoint.getSignature().getDeclaringType(),
                proceedingJoinPoint.getSignature().getName(),
                proceedingJoinPoint.getArgs()
        );
    }

    private boolean isRequestContext() {
        return RequestContextHolder.getRequestAttributes() != null;
    }
}
