package com.morethanheroic.template.service;

import com.morethanheroic.template.service.domain.TemplateRenderingContext;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

@Service
@RequiredArgsConstructor
public class ThymeleafTemplateRenderer implements TemplateRenderer {

    private final TemplateEngine templateEngine;

    @Override
    public String renderTemplate(final TemplateRenderingContext templateRenderingContext) {
        return this.templateEngine.process(templateRenderingContext.getTemplateLocation(),
                buildThymeleafContext(templateRenderingContext));
    }

    private Context buildThymeleafContext(final TemplateRenderingContext templateRenderingContext) {
        return new Context(
                templateRenderingContext.getLocale(),
                templateRenderingContext.getVariables()
        );
    }
}
