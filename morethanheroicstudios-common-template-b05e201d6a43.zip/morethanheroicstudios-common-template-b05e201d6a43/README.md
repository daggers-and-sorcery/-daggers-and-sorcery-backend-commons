# Common Template

This module is responsible for rendering displayable text from an input file and a rendering context. This especially come handy when we want to send emails.

# Changelog

- ***1.2.0***
    - Re-thinking the TemplateRenderingContext.
- ***1.1.0***
    - Re-thinking the template file location handling.
- ***1.0.0***
    - Initial release with Thymeleaf support.