# Common Event

This package provides a common way to fire application-wide events.

## Changelog

- ***1.1.0***
    - Revised the used dependencies. Removed the ones that were unnecessary.
- ***1.0.0***
    - Initial release.
