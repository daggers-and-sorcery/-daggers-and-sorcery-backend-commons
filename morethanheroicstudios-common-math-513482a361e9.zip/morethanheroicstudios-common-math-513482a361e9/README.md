# Common Math

## Changelog

- ***1.0.3***
    - Fixed that a method was accidentally made private instead of public.
- ***1.0.2***
    - Added a method that can be used to calculate if a random number is under a given percentage.
- ***1.0.1***
    - Fixed the auto-detection of the classes/module.
- ***1.0.0***
    - Initial release with some basic random and percentage calculation logic.