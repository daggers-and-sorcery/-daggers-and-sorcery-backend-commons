package com.morethanheroic.math.service;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Random;

/**
 * Methods to calculate percentages.
 */
@Service
@RequiredArgsConstructor
public class PercentageCalculator {

    private final Random random;
    private final RandomCalculator randomCalculator;

    /**
     * Calculate how many percentage is the actualValue of the maximumValue.
     *
     * @param actualValue  the value to calculate the percentage
     * @param maximumValue the maximum value that represents the 100%
     * @return the calculated percentage
     */
    public double calculatePercentage(double actualValue, double maximumValue) {
        return actualValue * 100 / maximumValue;
    }

    /**
     * Calculate the maximumValue that corresponds to the given percentage of the maximumValue.
     *
     * @param percentage   the percentage to calculate
     * @param maximumValue the maximum value that represents the 100%
     * @return the calculation result
     */
    public double calculatePercentageOf(double percentage, double maximumValue) {
        return maximumValue * (percentage * 0.01);
    }

    /**
     * Calculate if a random roll between 1 to 100 is higher than the provided value to hit.
     *
     * @param valueToHit the value to hit as a target
     * @return true if the random value was lower than the provided one and false otherwise.
     */
    public boolean calculatePercentageHit(final int valueToHit) {
        return valueToHit >= randomCalculator.randomNumberBetween(1, 100);
    }

    /**
     * Calculate if a generated random number is under the given percentage. The percentage can be a floating point
     * number like 0.0125. This method is usually used in drop calculation when a percentage between 0% and 100% should
     * be under a provided drop chance like 0.0125%.
     *
     * @param value the given percentage target
     * @return true if the random number is under the percentage and false otherwise
     */
    public boolean calculateUnderPercentage(final double value) {
        return 100 * random.nextDouble() < value;
    }
}
