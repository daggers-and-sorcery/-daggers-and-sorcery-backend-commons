# Common User

This module provides a common way for adding the user related feature to a web application. Users can be created, edited or extended.

## Installation

Add this project as a dependency to the application and enable class path scanning for `com.morethanheroic.user`.

## Changelog

- ***2.1.1***
    - Updated the version of the `common-dependency-injection` library.
    - Updated Spring Boot version from 2.0.6.RELEASE to 2.1.2.RELEASE.
- ***2.1.0***
    - Replaced the existing password hashing logic with the `PasswordEncoder` from `common-security`.
    - Removed the `PasswordHasher` class.
    - Removed the `hasAnyRoleFrom` deprecated method from the `UserEntity` class.
- ***2.0.1***
    - Added the `setRoles` and the `clearRoles` methods to the `UserRoleManipulator`.
    - From this release onwards we will publish the javadocs and sources with the binary jar files.
- ***2.0.0***
    - Split the user domain and the view to two separate artifacts called `common-user` and `common-user-view`.
- ***1.4.15***
    - Removed the `username` field from the `EmailFactoryRequest` because it was unneeded.
- ***1.4.14***
    - Fixed that `getUserEntities()` requires a transaction to run because of a bug in MyBatis' Cursor implementation.
- ***1.4.13***
    - Added `getUserEntities()` to the UserEntityFactory.
- ***1.4.12***
    - Added a way to check if an email address is already used by a user.
    - Added a way to update the email address of an user.
- ***1.4.11***
    - Added `UserEntity.hasRole` and `UserEntity.hasAnyRole`. 
    - Updated Spring Boot version to 2.0.1. 
    - Deprecated the `UserEntity.hasAnyRoleFrom` method.
- ***1.4.10***
    - Added equals and hashcode for the default `UserEntity`.
- ***1.4.9***
    - Fixed a wrong SQL query added by the previous role deletion logic.
- ***1.4.8***
    - Adding the remove role functionality to the `RoleManipulator`.
- ***1.4.7***
    - Fixed an NPE that happened when the username was generated.
- ***1.4.6***
    - The `DefaultUserEntityFactory` allow the creation of users without usernames. A new unique username will be generated if it's not specified.
- ***1.4.5***
    - Removed leftover role implementations that not used the role locator feature. Made the role locators in the role provider a non-required resource.
- ***1.4.4***
    - Added role locators.
- ***1.4.3***
    - Added a way to programmatically add roles for users.
- ***1.4.2***
    - Updating Spring Boot version to 2.0.0.RELEASE.
- ***1.4.1***
    - Fixed one of the database changelog.
- ***1.4.0***
    - Added password hashing.
- ***1.3.7***
    - Fixed a bug that caused an NPE in the `DefaultUserEntityFactory` when the user was not found in the repository.
- ***1.3.6***
    - Extended the `UserEntityFactory` to be able to create users by email and password.
- ***1.3.5***
    - Fixing a chaining problem with the authorization.
- ***1.3.4***
    - Added the accept_newsletter to the sql schema.
- ***1.3.3***
    - Removed the `@Component` from the `Authorization` filter.
- ***1.3.2***
    - Fixed that the liquibase xml for roles contained a wrong table name.
- ***1.3.1***
    - Fixed that the authorization filter thrown an NPE if the user was not logged in.
- ***1.3.0***
    - Various refactor changes and added a `javax.servlet.Filter` to restrict url access by role.
- ***1.2.0***
    - Added roles handling to the user.
- ***1.1.0***
    - Moved the user repository handling to the module.
- ***1.0.18***
    - Added the user sql files.
- ***1.0.17***
    - Deprecating the previous way of creating users in the `UserEntityFactory`.
    - Adding new methods, especially for creating `UserEntity` instances using username and email.