package com.morethanheroic.user.view.user.resolver;

import com.morethanheroic.user.domain.UserEntity;
import com.morethanheroic.user.view.user.service.ViewUserEntityFactory;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.MethodParameter;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.support.WebDataBinderFactory;
import org.springframework.web.context.request.NativeWebRequest;
import org.springframework.web.method.support.HandlerMethodArgumentResolver;
import org.springframework.web.method.support.ModelAndViewContainer;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

@Slf4j
@Component
@RequiredArgsConstructor
public class UserEntityHandlerMethodArgumentResolver implements HandlerMethodArgumentResolver {

    private final ViewUserEntityFactory viewUserEntityFactory;

    @Override
    public boolean supportsParameter(MethodParameter parameter) {
        return parameter.getParameterType().equals(UserEntity.class);
    }

    @Override
    public UserEntity resolveArgument(MethodParameter parameter, ModelAndViewContainer mavContainer, NativeWebRequest webRequest, WebDataBinderFactory binderFactory) throws Exception {
        final HttpSession session = ((HttpServletRequest) webRequest.getNativeRequest()).getSession();

        return viewUserEntityFactory.getUserEntity(session).orElse(null);
    }
}