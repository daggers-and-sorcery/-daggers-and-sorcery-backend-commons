package com.morethanheroic.user.view.user.service;

import com.morethanheroic.user.domain.UserEntity;
import com.morethanheroic.user.service.factory.UserEntityFactory;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpSession;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class ViewUserEntityFactory {

    private final UserEntityFactory<UserEntity> userEntityFactory;

    public Optional<UserEntity> getUserEntity(final HttpSession httpSession) {
        final Object userId = httpSession.getAttribute("USER_ID");

        return userId == null ? Optional.empty() : Optional.of(userEntityFactory.getUserEntity((int) userId));
    }
}
