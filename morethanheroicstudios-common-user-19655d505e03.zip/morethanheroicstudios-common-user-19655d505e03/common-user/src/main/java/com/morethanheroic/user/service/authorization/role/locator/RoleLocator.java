package com.morethanheroic.user.service.authorization.role.locator;

import com.morethanheroic.user.domain.authorization.Role;

import java.util.List;

public interface RoleLocator {

    List<Role> provideRoles();
}
