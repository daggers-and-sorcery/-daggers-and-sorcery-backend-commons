package com.morethanheroic.user.domain.authorization;

public interface Role {

    String getId();
}
