package com.morethanheroic.user.service.authorization.role;

import com.morethanheroic.user.domain.authorization.Role;
import com.morethanheroic.user.service.authorization.role.locator.RoleProvider;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class RoleFactory {

    private final List<Role> roles;

    public RoleFactory(final RoleProvider roleProvider) {
        roles = roleProvider.locateRoles();
    }

    public Optional<Role> getRole(final String roleId) {
        return roles.stream()
                .filter(role -> role.getId().equals(roleId))
                .findFirst();
    }
}
