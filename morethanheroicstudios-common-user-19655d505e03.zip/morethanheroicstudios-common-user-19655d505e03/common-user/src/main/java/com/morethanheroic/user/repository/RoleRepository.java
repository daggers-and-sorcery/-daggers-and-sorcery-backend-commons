package com.morethanheroic.user.repository;

import com.morethanheroic.user.domain.authorization.Role;
import com.morethanheroic.user.repository.domain.RoleDatabaseEntity;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface RoleRepository {

    @Select("SELECT * FROM role WHERE user_id = #{userId}")
    List<RoleDatabaseEntity> findRolesForUser(@Param("userId") int userId);

    @Insert("INSERT INTO role SET user_id = #{role.userId}, role_id = #{role.roleId}")
    void insert(@Param("role") RoleDatabaseEntity role);

    @Delete("DELETE FROM role WHERE user_id = #{userId} AND role_id = #{role}")
    void remove(@Param("userId") int userId, @Param("role") Role role);

    /**
     * Clear all of the roles from a specified user.
     *
     * @param userId the ide of the user to clear the roles from
     */
    @Delete("DELETE FROM role WHERE user_id = #{userId}")
    void clear(@Param("userId") int userId);
}
