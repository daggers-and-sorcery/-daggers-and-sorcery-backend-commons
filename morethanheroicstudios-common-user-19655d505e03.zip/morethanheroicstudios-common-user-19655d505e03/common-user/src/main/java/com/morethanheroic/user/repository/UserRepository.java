package com.morethanheroic.user.repository;

import com.morethanheroic.user.repository.domain.UserDatabaseEntity;
import org.apache.ibatis.annotations.*;
import org.apache.ibatis.cursor.Cursor;

@Mapper
public interface UserRepository {

    @Select("SELECT * FROM user WHERE id = #{id}")
    UserDatabaseEntity findUserById(@Param("id") int id);

    @Select("SELECT * FROM user WHERE username = #{username} AND password = #{password}")
    UserDatabaseEntity findUserByUsernameAndPassword(
            @Param("username") String username,
            @Param("password") String password
    );

    @Select("SELECT * FROM user WHERE email = #{email}")
    UserDatabaseEntity findUserByEmail(
            @Param("email") String email
    );

    @Select("SELECT * FROM user WHERE password = #{password} AND email = #{email}")
    UserDatabaseEntity findUserByEmailAndPassword(
            @Param("email") String email,
            @Param("password") String password
    );

    @Select("SELECT * FROM user")
    Cursor<UserDatabaseEntity> findUsers();

    @Insert("INSERT INTO user SET username = #{username}, password = #{password}, email = #{email}, accept_newsletter = #{acceptNewsletter}")
    void insertUser(
            @Param("username") String username,
            @Param("password") String password,
            @Param("email") String email,
            @Param("acceptNewsletter") boolean acceptNewsletter
    );

    @Update("UPDATE user SET password = #{password} WHERE id = #{id}")
    void updateUserPassword(
            @Param("id") int id,
            @Param("password") String password
    );

    @Update("UPDATE user SET email = #{email} WHERE id = #{id}")
    void updateUserEmail(
            @Param("id") int id,
            @Param("email") String email
    );

    @Select("SELECT EXISTS(SELECT 1 FROM user WHERE email = #{email})")
    boolean isEmailRegistered(
            @Param("email") String email
    );
}
