package com.morethanheroic.user.service.authorization.role.locator;

import com.morethanheroic.user.domain.authorization.Role;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class RoleProvider {

    private final List<RoleLocator> roleLocators;

    public RoleProvider(@Autowired(required = false) final List<RoleLocator> roleLocators) {
        this.roleLocators = roleLocators != null ? roleLocators : new ArrayList<>();
    }

    public List<Role> locateRoles() {
        return roleLocators.stream()
                .flatMap(roleLocator -> roleLocator.provideRoles().stream())
                .collect(Collectors.toList());
    }
}
