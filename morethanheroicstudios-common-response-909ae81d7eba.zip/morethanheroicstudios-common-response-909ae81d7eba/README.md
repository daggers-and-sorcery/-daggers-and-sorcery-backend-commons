# Common Response

## Changelog

- ***1.1.1***
    - Deprecated the `ResultResponseFactory` and created a new `StatusResponseFactory`,
    - Added a message field to the status response.
- ***1.1.0***
    - Updated gradle version.
    - Deprecated the existing solution because it ended up being outdated and unnecessary complex.
    - Added the ResultResponseFactory to support rapid successful or unsuccessful response creation.