package com.morethanheroic.response.service;

import com.morethanheroic.response.domain.PartialResponse;

import java.util.Collection;

@Deprecated
public interface PartialResponseCollectionBuilder<T extends ResponseBuilderConfiguration> {

    Collection<? extends PartialResponse> build(T responseBuilderConfiguration);
}
