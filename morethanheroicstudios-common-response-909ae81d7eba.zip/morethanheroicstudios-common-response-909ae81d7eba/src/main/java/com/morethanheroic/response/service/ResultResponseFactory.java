package com.morethanheroic.response.service;

import com.morethanheroic.response.service.domain.StatusResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

/**
 * @deprecated Deprecated because of the incorrect name. Please use the {@link StatusResponseFactory} instead.
 */
@Service
@Deprecated
@RequiredArgsConstructor
public class ResultResponseFactory {

    private final StatusResponseFactory statusResponseFactory;

    public StatusResponse newSuccessfulResponse() {
        return statusResponseFactory.newSuccessfulResponse();
    }

    public StatusResponse newUnsuccessfulResponse() {
        return statusResponseFactory.newUnsuccessfulResponse();
    }
}
