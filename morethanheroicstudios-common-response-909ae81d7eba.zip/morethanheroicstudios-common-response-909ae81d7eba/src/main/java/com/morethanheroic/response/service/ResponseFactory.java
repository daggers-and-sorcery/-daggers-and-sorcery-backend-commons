package com.morethanheroic.response.service;

import com.morethanheroic.response.domain.Response;
import com.morethanheroic.response.service.domain.StatusBasedPartialResponse;
import org.springframework.stereotype.Service;

@Service
@Deprecated
public class ResponseFactory {

    private static final boolean SUCCESSFUL_REQUEST = true;
    private static final boolean FAILED_REQUEST = false;

    @Deprecated
    public Response successfulResponse() {
        final Response response = new Response();

        response.setData("result", StatusBasedPartialResponse.builder()
                .successful(SUCCESSFUL_REQUEST)
                .build()
        );

        return response;
    }

    @Deprecated
    public Response failedResponse() {
        final Response response = new Response();

        response.setData("result", StatusBasedPartialResponse.builder()
                .successful(FAILED_REQUEST)
                .build()
        );

        return response;
    }
}
