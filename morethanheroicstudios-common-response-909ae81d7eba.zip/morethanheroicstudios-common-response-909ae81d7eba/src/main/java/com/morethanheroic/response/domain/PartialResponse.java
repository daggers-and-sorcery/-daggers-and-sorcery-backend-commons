package com.morethanheroic.response.domain;

/**
 * It's a marker class for now.
 */
@Deprecated
public abstract class PartialResponse {
}
