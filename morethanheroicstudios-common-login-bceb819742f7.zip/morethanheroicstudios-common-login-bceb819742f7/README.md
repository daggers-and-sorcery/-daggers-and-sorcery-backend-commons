# Common Login

## Changelog

- ***2.2.3***
    - Fixed that the InfoEndpointExtender logic required at least one extenders (for no reason).
- ***2.2.2***
    - Added a new sql change to add a missed column from the kongregate_user_map table.
- ***2.2.1***
    - Revised the Kongregate login.
- ***2.2.0***
    - Moved the info extender classes from the service module to the view.
    - Using only the service module from the verification modules so we are not going to expose the verification endpoint accidentally.
- ***2.1.1***
    - Fixed a bug where spring was unable to autowire the UserEntityFinders.
- ***2.1.0***
    - Added Kongregate Login.
- ***2.0.0***
    - Split the module to two. One service module called common-login and one view module called common-login-view.