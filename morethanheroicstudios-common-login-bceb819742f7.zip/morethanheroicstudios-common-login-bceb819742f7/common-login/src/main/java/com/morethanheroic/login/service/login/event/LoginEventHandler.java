package com.morethanheroic.login.service.login.event;

import com.morethanheroic.event.EventHandler;
import com.morethanheroic.login.service.login.event.domain.LoginEventConfiguration;

/**
 * Handle successful login events here.
 */
public abstract class LoginEventHandler implements EventHandler<LoginEventConfiguration> {
}
