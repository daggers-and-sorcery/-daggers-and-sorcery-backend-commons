package com.morethanheroic.login.service.login.domain;

import com.morethanheroic.user.domain.UserEntity;
import lombok.Builder;
import lombok.Getter;

import java.util.Optional;

@Getter
@Builder
public class LoginEvaluationResult {

    private final LoginResult result;
    private final UserEntity user;

    public Optional<UserEntity> getUser() {
        return Optional.ofNullable(user);
    }
}
