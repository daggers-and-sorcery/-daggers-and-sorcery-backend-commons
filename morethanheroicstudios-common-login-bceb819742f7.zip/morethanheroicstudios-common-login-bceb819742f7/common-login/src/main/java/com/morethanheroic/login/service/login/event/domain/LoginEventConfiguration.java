package com.morethanheroic.login.service.login.event.domain;

import com.morethanheroic.event.EventConfiguration;
import com.morethanheroic.user.domain.UserEntity;
import lombok.Builder;
import lombok.Getter;
import lombok.ToString;

@Builder
@Getter
@ToString
public class LoginEventConfiguration implements EventConfiguration {

    private UserEntity userEntity;
}
