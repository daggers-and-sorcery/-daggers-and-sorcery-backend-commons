package com.morethanheroic.login.service.login.domain.entity;

import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class EmailLoginEntity implements LoginEntity {

    private String email;
    private String password;
}
