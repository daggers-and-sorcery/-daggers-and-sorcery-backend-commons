package com.morethanheroic.login.service.login.domain.entity;

public interface LoginEntity {
}
