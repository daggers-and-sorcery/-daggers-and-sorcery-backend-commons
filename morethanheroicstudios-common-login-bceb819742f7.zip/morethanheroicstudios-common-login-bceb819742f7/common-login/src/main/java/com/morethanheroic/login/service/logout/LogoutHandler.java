package com.morethanheroic.login.service.logout;

import com.morethanheroic.session.domain.SessionEntity;
import org.springframework.stereotype.Service;

@Service
public class LogoutHandler {

    public void handleRequest(final SessionEntity sessionEntity) {
        sessionEntity.close();
    }
}
