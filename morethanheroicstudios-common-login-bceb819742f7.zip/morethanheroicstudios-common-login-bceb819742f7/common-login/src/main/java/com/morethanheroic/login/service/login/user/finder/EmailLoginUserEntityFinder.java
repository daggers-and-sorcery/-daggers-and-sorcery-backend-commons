package com.morethanheroic.login.service.login.user.finder;

import com.morethanheroic.login.service.login.domain.entity.EmailLoginEntity;
import com.morethanheroic.user.domain.UserEntity;
import com.morethanheroic.user.service.factory.UserEntityFactory;
import com.morethanheroic.user.service.factory.domain.EmailAndPasswordFactoryRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
@RequiredArgsConstructor
public class EmailLoginUserEntityFinder implements UserEntityFinder<EmailLoginEntity> {

    private final UserEntityFactory userEntityFactory;

    @Override
    public Class<EmailLoginEntity> finderFor() {
        return EmailLoginEntity.class;
    }

    @Override
    public Optional<UserEntity> find(final EmailLoginEntity loginEntity) {
        return Optional.ofNullable(
                userEntityFactory.getUserEntity(
                        EmailAndPasswordFactoryRequest.builder()
                                .email(loginEntity.getEmail())
                                .password(loginEntity.getPassword())
                                .build()
                )
        );
    }
}
