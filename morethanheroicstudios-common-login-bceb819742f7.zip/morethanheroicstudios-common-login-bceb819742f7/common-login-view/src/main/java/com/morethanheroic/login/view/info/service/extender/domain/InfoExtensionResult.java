package com.morethanheroic.login.view.info.service.extender.domain;

import com.morethanheroic.response.domain.PartialResponse;

public interface InfoExtensionResult {

    PartialResponse getExtensionData();

    String getExtensionName();
}
