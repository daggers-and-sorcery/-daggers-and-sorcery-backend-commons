package com.morethanheroic.login.view.info.controller;

import com.morethanheroic.login.view.info.response.InfoResponseBuilder;
import com.morethanheroic.login.view.info.response.domain.InfoResponseBuilderConfiguration;
import com.morethanheroic.response.domain.Response;
import com.morethanheroic.user.domain.UserEntity;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
public class InfoController {

    private final InfoResponseBuilder infoResponseBuilder;

    @GetMapping("/user/info")
    public Response info(final UserEntity userEntity) {
        return infoResponseBuilder.build(
                InfoResponseBuilderConfiguration.builder()
                        .userEntity(userEntity)
                        .build()
        );
    }
}
