package com.morethanheroic.login.view.login.email.request.domain;

import lombok.Data;

@Data
public class EmailBasedLoginRequest {

    private String email;
    private String password;
}
