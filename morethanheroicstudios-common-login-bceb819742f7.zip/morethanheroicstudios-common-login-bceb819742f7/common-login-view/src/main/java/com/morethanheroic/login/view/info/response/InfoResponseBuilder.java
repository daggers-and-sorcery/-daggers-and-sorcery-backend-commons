package com.morethanheroic.login.view.info.response;

import com.morethanheroic.login.view.info.service.extender.InfoEndpointExtender;
import com.morethanheroic.login.view.info.service.extender.domain.InfoExtensionResult;
import com.morethanheroic.login.view.info.response.domain.InfoResponseBuilderConfiguration;
import com.morethanheroic.login.view.info.response.domain.LoginInfoPartialResponse;
import com.morethanheroic.login.view.info.response.domain.UserInfoPartialResponse;
import com.morethanheroic.response.domain.Response;
import com.morethanheroic.response.service.ResponseBuilder;
import com.morethanheroic.user.domain.UserEntity;
import com.morethanheroic.user.domain.authorization.Role;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class InfoResponseBuilder implements ResponseBuilder<InfoResponseBuilderConfiguration> {

    private final InfoResponseFactory infoResponseFactory;
    private final List<InfoEndpointExtender> infoEndpointExtenders;

    public InfoResponseBuilder(final InfoResponseFactory infoResponseFactory,
                               @Autowired(required = false) final List<InfoEndpointExtender> infoEndpointExtenders) {
        this.infoResponseFactory = infoResponseFactory;

        if(infoEndpointExtenders != null) {
            this.infoEndpointExtenders = infoEndpointExtenders;
        } else {
            this.infoEndpointExtenders = Collections.emptyList();
        }
    }

    @Override
    public Response build(final InfoResponseBuilderConfiguration infoResponseBuilderConfiguration) {
        final UserEntity userEntity = infoResponseBuilderConfiguration.getUserEntity();
        final Response response = infoResponseFactory
                .newResponse(infoResponseBuilderConfiguration.getUserEntity());

        response.setData("login",
                LoginInfoPartialResponse.builder()
                        .isLoggedIn(userEntity != null)
                        .build()
        );

        if (userEntity != null) {
            response.setData("user",
                    UserInfoPartialResponse.builder()
                            .name(userEntity.getUsername())
                            .roles(
                                    userEntity.getRoles().stream()
                                            .map(Role::getId)
                                            .collect(Collectors.toList())
                            )
                            .build()
            );
        }

        infoEndpointExtenders.stream()
                .map(infoEndpointExtender -> infoEndpointExtender.extendInfo(userEntity))
                .filter(Optional::isPresent)
                .map(Optional::get)
                .forEach(infoExtensionResult ->
                        response.setData(infoExtensionResult.getExtensionName(), infoExtensionResult.getExtensionData())
                );

        return response;
    }
}
