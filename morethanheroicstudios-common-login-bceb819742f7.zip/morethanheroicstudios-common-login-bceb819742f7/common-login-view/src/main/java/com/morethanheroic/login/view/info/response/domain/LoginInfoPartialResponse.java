package com.morethanheroic.login.view.info.response.domain;

import com.morethanheroic.response.domain.PartialResponse;
import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class LoginInfoPartialResponse extends PartialResponse {

    private final boolean isLoggedIn;
}
