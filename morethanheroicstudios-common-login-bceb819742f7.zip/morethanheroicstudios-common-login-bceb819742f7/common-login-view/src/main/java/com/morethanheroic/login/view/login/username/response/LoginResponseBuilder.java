package com.morethanheroic.login.view.login.username.response;

import com.morethanheroic.login.view.login.username.response.domain.LoginResponseBuilderConfiguration;
import com.morethanheroic.response.domain.Response;
import com.morethanheroic.response.service.ResponseBuilder;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class LoginResponseBuilder implements ResponseBuilder<LoginResponseBuilderConfiguration> {

    private final LoginPartialResponseBuilder loginPartialResponseBuilder;

    @Override
    public Response build(LoginResponseBuilderConfiguration loginResponseBuilderConfiguration) {
        Response response = new Response();

        response.setData("login", loginPartialResponseBuilder.build(loginResponseBuilderConfiguration));

        return response;
    }
}
