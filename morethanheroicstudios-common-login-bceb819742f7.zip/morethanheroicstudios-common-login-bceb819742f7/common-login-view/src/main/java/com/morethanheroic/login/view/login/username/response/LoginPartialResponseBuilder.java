package com.morethanheroic.login.view.login.username.response;

import com.morethanheroic.login.service.login.domain.LoginEvaluationResult;
import com.morethanheroic.login.view.login.username.response.domain.LoginPartialResponse;
import com.morethanheroic.login.view.login.username.response.domain.LoginResponseBuilderConfiguration;
import com.morethanheroic.login.view.login.username.response.domain.UserPartialResponse;
import com.morethanheroic.response.domain.PartialResponse;
import com.morethanheroic.response.service.PartialResponseBuilder;
import com.morethanheroic.user.domain.UserEntity;
import com.morethanheroic.user.domain.authorization.Role;
import org.springframework.stereotype.Service;

import java.util.Set;
import java.util.stream.Collectors;

@Service
public class LoginPartialResponseBuilder implements PartialResponseBuilder<LoginResponseBuilderConfiguration> {

    @Override
    public PartialResponse build(LoginResponseBuilderConfiguration loginResponseBuilderConfiguration) {
        final LoginEvaluationResult loginEvaluationResult =
                loginResponseBuilderConfiguration.getLoginEvaluationResult();

        return LoginPartialResponse.builder()
                .result(loginEvaluationResult.getResult())
                .user(buildUserResponse(loginEvaluationResult.getUser().orElse(null)))
                .build();
    }

    private UserPartialResponse buildUserResponse(final UserEntity userEntity) {
        if (userEntity == null) {
            return null;
        }

        return UserPartialResponse.builder()
                .roles(buildRoles(userEntity))
                .build();
    }

    private Set<String> buildRoles(final UserEntity userEntity) {
        return userEntity.getRoles().stream()
                .map(Role::getId)
                .collect(Collectors.toSet());
    }
}
