package com.morethanheroic.login.view.logout.controller;

import com.morethanheroic.login.service.logout.LogoutHandler;
import com.morethanheroic.response.domain.Response;
import com.morethanheroic.response.service.ResponseFactory;
import com.morethanheroic.session.domain.SessionEntity;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
public class LogoutController {

    private final LogoutHandler logoutHandler;
    private final ResponseFactory responseFactory;

    @GetMapping("/user/logout")
    public Response logout(final SessionEntity sessionEntity) {
        logoutHandler.handleRequest(sessionEntity);

        return responseFactory.successfulResponse();
    }
}
