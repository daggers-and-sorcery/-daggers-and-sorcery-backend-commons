package com.morethanheroic.login.view.info.response;

import com.morethanheroic.response.domain.Response;
import com.morethanheroic.user.domain.UserEntity;
import org.springframework.stereotype.Service;

@Service
public class InfoResponseFactory {

    public Response newResponse(final UserEntity userEntity) {
        return new Response();
    }
}
