package com.morethanheroic.login.view.info.service.extender.domain;

import com.morethanheroic.response.domain.PartialResponse;
import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class DefaultInfoExtensionResult implements InfoExtensionResult {

    private final PartialResponse extensionData;
    private final String extensionName;
}
