package com.morethanheroic.login.view.login.username.response.domain;

import com.morethanheroic.login.service.login.domain.LoginEvaluationResult;
import com.morethanheroic.login.service.login.domain.LoginResult;
import com.morethanheroic.response.service.ResponseBuilderConfiguration;
import com.morethanheroic.user.domain.UserEntity;
import com.morethanheroic.user.domain.authorization.Role;
import lombok.Builder;
import lombok.Getter;
import lombok.ToString;

import java.util.Optional;
import java.util.Set;

@Builder
@Getter
@ToString
public class LoginResponseBuilderConfiguration implements ResponseBuilderConfiguration {

    private final LoginEvaluationResult loginEvaluationResult;
}
