package com.morethanheroic.login.view.login.email.controller;

import com.morethanheroic.login.service.login.LoginHandler;
import com.morethanheroic.login.service.login.domain.LoginEvaluationResult;
import com.morethanheroic.login.service.login.domain.LoginResult;
import com.morethanheroic.login.service.login.domain.entity.EmailLoginEntity;
import com.morethanheroic.login.view.login.email.request.domain.EmailBasedLoginRequest;
import com.morethanheroic.login.view.login.username.response.LoginResponseBuilder;
import com.morethanheroic.login.view.login.username.response.domain.LoginResponseBuilderConfiguration;
import com.morethanheroic.response.domain.Response;
import com.morethanheroic.session.domain.SessionEntity;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
@ConditionalOnProperty(name = "login.email-based-login.enabled", havingValue = "true")
public class EmailBasedLoginController {

    private final LoginHandler loginHandler;
    private final LoginResponseBuilder loginResponseBuilder;

    @PostMapping("/user/login-by-email")
    public Response login(@RequestBody final EmailBasedLoginRequest loginRequest, final SessionEntity sessionEntity) {
        final LoginEvaluationResult loginEvaluationResult = loginHandler.handleLogin(sessionEntity,
                EmailLoginEntity.builder()
                        .email(loginRequest.getEmail())
                        .password(loginRequest.getPassword())
                        .build()
        );

        return loginResponseBuilder.build(
                LoginResponseBuilderConfiguration.builder()
                        .loginEvaluationResult(loginEvaluationResult)
                        .build()
        );
    }
}
