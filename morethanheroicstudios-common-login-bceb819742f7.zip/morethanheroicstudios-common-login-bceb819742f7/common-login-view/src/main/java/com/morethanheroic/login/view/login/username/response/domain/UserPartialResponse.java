package com.morethanheroic.login.view.login.username.response.domain;

import com.morethanheroic.response.domain.PartialResponse;
import lombok.Builder;
import lombok.Getter;

import java.util.Set;

@Getter
@Builder
public class UserPartialResponse extends PartialResponse {

    private final Set<String> roles;
}
