package com.morethanheroic.login.view.info.response.domain;

import java.util.List;

import com.morethanheroic.response.domain.PartialResponse;
import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class UserInfoPartialResponse extends PartialResponse {

  private final String name;
  private final List<String> roles;
}
