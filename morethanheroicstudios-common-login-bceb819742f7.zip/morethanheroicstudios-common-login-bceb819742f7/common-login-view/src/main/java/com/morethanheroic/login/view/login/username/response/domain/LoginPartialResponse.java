package com.morethanheroic.login.view.login.username.response.domain;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.morethanheroic.login.service.login.domain.LoginResult;
import com.morethanheroic.response.domain.PartialResponse;
import lombok.Builder;
import lombok.Getter;
import lombok.ToString;

import java.util.Optional;

@Builder
@Getter
@ToString
public class LoginPartialResponse extends PartialResponse {

    private final LoginResult result;
    private final UserPartialResponse user;

    @JsonInclude(JsonInclude.Include.NON_ABSENT)
    public Optional<UserPartialResponse> getUser() {
        return Optional.ofNullable(user);
    }
}
