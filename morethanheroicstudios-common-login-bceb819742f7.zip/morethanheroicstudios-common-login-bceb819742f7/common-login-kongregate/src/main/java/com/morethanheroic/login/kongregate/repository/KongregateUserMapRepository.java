package com.morethanheroic.login.kongregate.repository;

import com.morethanheroic.login.kongregate.repository.domain.KongregateUserMapDatabaseEntity;
import org.apache.ibatis.annotations.*;

@Mapper
public interface KongregateUserMapRepository {

    @Select("SELECT * FROM kongregate_user_map WHERE kongregate_user_id = #{kongregateUserId}")
    KongregateUserMapDatabaseEntity findByKongregateUserId(
            @Param("kongregateUserId") int kongregateUserId
    );

    @Insert("INSERT INTO kongregate_user_map SET user_id = #{userId}, kongregate_user_id = #{kongregateUserId}, kongregate_authentication_token = #{authenticationToken}")
    void insertKongregateUser(
            @Param("userId") int userId,
            @Param("kongregateUserId") int kongregateUserId,
            @Param("authenticationToken") String authenticationToken
    );

    @Update("UPDATE kongregate_user_map SET kongregate_authentication_token = #{authenticationToken} WHERE kongregate_user_id = #{kongregateUserId}")
    void updateKongregateUserAuthenticationToken(
            @Param("kongregateUserId") int kongregateUserId,
            @Param("authenticationToken") String authenticationToken
    );
}
