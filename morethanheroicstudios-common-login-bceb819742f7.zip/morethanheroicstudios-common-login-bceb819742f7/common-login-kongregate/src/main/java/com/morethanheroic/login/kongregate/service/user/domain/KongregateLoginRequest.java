package com.morethanheroic.login.kongregate.service.user.domain;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class KongregateLoginRequest {

    @JsonProperty("api_key")
    private final String apiKey;

    @JsonProperty("user_id")
    private final int userId;

    @JsonProperty("game_auth_token")
    private final String authenticationToken;
}
