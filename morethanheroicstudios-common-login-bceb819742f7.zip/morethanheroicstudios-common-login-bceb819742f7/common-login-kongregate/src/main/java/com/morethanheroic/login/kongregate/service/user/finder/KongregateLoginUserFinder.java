package com.morethanheroic.login.kongregate.service.user.finder;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.morethanheroic.login.kongregate.configuration.KongregateLoginConfigurationProperties;
import com.morethanheroic.login.kongregate.repository.KongregateUserMapRepository;
import com.morethanheroic.login.kongregate.repository.domain.KongregateUserMapDatabaseEntity;
import com.morethanheroic.login.kongregate.service.domain.entity.KongregateLoginEntity;
import com.morethanheroic.login.kongregate.service.user.domain.KongregateLoginRequest;
import com.morethanheroic.login.kongregate.service.user.domain.KongregateLoginResponse;
import com.morethanheroic.login.service.login.domain.LoginEvaluationResult;
import com.morethanheroic.login.service.login.domain.LoginResult;
import com.morethanheroic.login.service.login.user.finder.UserEntityFinder;
import com.morethanheroic.user.domain.UserEntity;
import com.morethanheroic.user.service.factory.UserEntityFactory;
import lombok.RequiredArgsConstructor;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.client.methods.RequestBuilder;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.Optional;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class KongregateLoginUserFinder implements UserEntityFinder<KongregateLoginEntity> {

    private final UserEntityFactory userEntityFactory;
    private final KongregateUserMapRepository kongregateUserMapRepository;
    private final ObjectMapper objectMapper;
    private final KongregateLoginConfigurationProperties kongregateLoginConfigurationProperties;

    @Override
    public Class<KongregateLoginEntity> finderFor() {
        return KongregateLoginEntity.class;
    }

    @Override
    public Optional<UserEntity> find(final KongregateLoginEntity kongregateLoginEntity) {
        final KongregateUserMapDatabaseEntity kongregateUserMapDatabaseEntity =
                kongregateUserMapRepository.findByKongregateUserId(kongregateLoginEntity.getUserId());

        // Register user
        if (kongregateUserMapDatabaseEntity == null) {
            final Optional<String> username = queryUserData(kongregateLoginEntity);

            // Non existing user!
            if (!username.isPresent()) {
                return Optional.empty();
            }

            final UserEntity userEntity = userEntityFactory.newUserEntity(username.get(), UUID.randomUUID().toString(),
                    UUID.randomUUID() + "@kongregate", false);

            kongregateUserMapRepository.insertKongregateUser(userEntity.getId(), kongregateLoginEntity.getUserId(),
                    kongregateLoginEntity.getAuthenticationToken());

            return Optional.of(userEntity);
        }

        // Auth token is different so the user changed password
        if (!kongregateUserMapDatabaseEntity.getKongregateAuthenticationToken()
                .equals(kongregateLoginEntity.getAuthenticationToken())) {
            final Optional<String> username = queryUserData(kongregateLoginEntity);

            // Non existing user! Eg, a fake auth.
            if (!username.isPresent()) {
                return Optional.empty();
            }

            // Updating the user's auth token
            kongregateUserMapRepository.updateKongregateUserAuthenticationToken(kongregateLoginEntity.getUserId(),
                    kongregateLoginEntity.getAuthenticationToken());
        }

        return Optional.of(userEntityFactory.getUserEntity(kongregateUserMapDatabaseEntity.getUserId()));
    }

    //TODO: Move the user's data away from here
    private Optional<String> queryUserData(final KongregateLoginEntity kongregateLoginEntity) {
        final HttpClient client = HttpClientBuilder.create().build();

        try {
            // Query the user data
            final String requestBody = objectMapper.writeValueAsString(
                    KongregateLoginRequest.builder()
                            .apiKey(kongregateLoginConfigurationProperties.getApiKey())
                            .userId(kongregateLoginEntity.getUserId())
                            .authenticationToken(kongregateLoginEntity.getAuthenticationToken())
                            .build()
            );

            final HttpUriRequest request = RequestBuilder.get()
                    .setUri("https://api.kongregate.com/api/authenticate.json")
                    .setEntity(new StringEntity(requestBody, ContentType.APPLICATION_JSON))
                    .build();

            final HttpResponse response = client.execute(request);

            final String responseBody = EntityUtils.toString(response.getEntity());

            final KongregateLoginResponse kongregateLoginResponse =
                    objectMapper.readValue(responseBody, KongregateLoginResponse.class);

            if (!kongregateLoginResponse.isSuccess()) {
                return Optional.empty();
            }

            return Optional.of(kongregateLoginResponse.getUsername());
        } catch (IOException e) {
            throw new RuntimeException("Failed to send a login request to Kongregat!", e);
        }
    }
}
