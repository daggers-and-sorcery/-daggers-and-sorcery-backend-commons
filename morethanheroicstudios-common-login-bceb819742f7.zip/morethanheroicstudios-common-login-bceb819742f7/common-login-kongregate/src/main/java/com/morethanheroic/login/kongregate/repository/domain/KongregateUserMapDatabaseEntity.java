package com.morethanheroic.login.kongregate.repository.domain;

import lombok.Data;

@Data
public class KongregateUserMapDatabaseEntity {

    private int userId;
    private int kongregateUserId;
    private String kongregateAuthenticationToken;
}
