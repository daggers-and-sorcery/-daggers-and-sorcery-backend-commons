package com.morethanheroic.payment.ingenico.service.callback;

import com.morethanheroic.payment.domain.PaymentEntity;
import com.morethanheroic.payment.domain.PaymentStatus;
import com.morethanheroic.payment.service.callback.PaymentCallback;
import com.morethanheroic.payment.service.manipulator.PaymentManipulator;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class UpdateStatusPaymentCallback implements PaymentCallback {

    private final PaymentManipulator paymentManipulator;

    @Override
    public void callback(PaymentEntity paymentEntity) {
        paymentManipulator.updateStatus(paymentEntity.getId(), PaymentStatus.FINISHED);
    }
}
