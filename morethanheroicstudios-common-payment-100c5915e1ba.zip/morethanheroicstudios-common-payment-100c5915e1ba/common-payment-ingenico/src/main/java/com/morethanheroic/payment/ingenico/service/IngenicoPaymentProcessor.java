package com.morethanheroic.payment.ingenico.service;

import com.morethanheroic.payment.domain.PaymentContext;
import com.morethanheroic.payment.domain.PaymentEntity;
import com.morethanheroic.payment.domain.result.PaymentResult;
import com.morethanheroic.payment.domain.result.PaymentResultEntity;
import com.morethanheroic.payment.ingenico.configuration.IngenicoPaymentProperties;
import com.morethanheroic.payment.ingenico.service.domain.IngenicoPaymentResultEntity;
import com.morethanheroic.payment.ingenico.service.sha.IngenicoShaInCalculator;
import com.morethanheroic.payment.ingenico.service.sha.domain.ShaCalculationInput;
import com.morethanheroic.payment.service.PaymentProcessor;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.Currency;

@Service
@ConditionalOnProperty(name = "payment.provider", havingValue = "ingenico")
@RequiredArgsConstructor
public class IngenicoPaymentProcessor implements PaymentProcessor<PaymentContext> {

    private final IngenicoPaymentProperties ingenicoPaymentProperties;
    private final IngenicoShaInCalculator ingenicoShaInCalculator;

    @Override
    public PaymentResultEntity processPayment(final PaymentContext paymentContext) {
        final PaymentEntity paymentEntity = paymentContext.getPaymentEntity();
        final String pspId = ingenicoPaymentProperties.getPspId();
        final String orderId = paymentEntity.getId();
        final long price = calculatePrice(paymentEntity);
        final String currency = paymentEntity.getCurrency().getCurrencyCode();
        final String language = paymentEntity.getLocale().getLanguage();
        final String shaIn = calculateShaIn(
                ShaCalculationInput.builder()
                        .pspId(pspId)
                        .orderId(orderId)
                        .amount(price)
                        .currency(currency)
                        .language(language)
                        .build()
        );

        return IngenicoPaymentResultEntity.builder()
                .result(PaymentResult.SUCCESSFUL)
                .shaIn(shaIn)
                .pspId(pspId)
                .orderId(orderId)
                .amount(calculatePrice(paymentEntity))
                .currency(currency)
                .language(language)
                .build();
    }

    private String calculateShaIn(final ShaCalculationInput shaCalculationInput) {
        return ingenicoShaInCalculator.calculateShaIn(shaCalculationInput);
    }

    private long calculatePrice(final PaymentEntity paymentEntity) {
        if (paymentEntity.getCurrency().equals(Currency.getInstance("HUF"))) {
            return paymentEntity.getPrice().longValueExact();
        }

        return paymentEntity.getPrice().multiply(new BigDecimal(100)).longValueExact();
    }
}
