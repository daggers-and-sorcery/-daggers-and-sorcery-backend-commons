package com.morethanheroic.payment.ingenico.service.sha.domain;

import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class ShaCalculationInput {

    private final String pspId;
    private final String orderId;
    private final long amount;
    private final String currency;
    private final String language;
}
