package com.morethanheroic.payment.ingenico.service.domain;

import com.morethanheroic.payment.domain.result.PaymentResult;
import com.morethanheroic.payment.domain.result.PaymentResultEntity;
import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class IngenicoPaymentResultEntity implements PaymentResultEntity {

    private final PaymentResult result;
    private final String shaIn;
    private final String pspId;
    private final String orderId;
    private final long amount;
    private final String currency;
    private final String language;
}
