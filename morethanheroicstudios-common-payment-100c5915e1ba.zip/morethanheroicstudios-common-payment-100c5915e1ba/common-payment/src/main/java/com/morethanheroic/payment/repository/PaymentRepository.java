package com.morethanheroic.payment.repository;

import com.morethanheroic.payment.domain.PaymentStatus;
import com.morethanheroic.payment.repository.domain.PaymentDatabaseEntity;
import org.apache.ibatis.annotations.*;

@Mapper
public interface PaymentRepository {

    @Select("SELECT * FROM payment WHERE id = #{id}")
    PaymentDatabaseEntity findById(@Param("id") String id);

    @Update("UPDATE payment SET status = #{status} WHERE id = #{id}")
    void updateStatus(@Param("id") String id, @Param("status") PaymentStatus status);

    @Update("UPDATE payment SET provider_id = #{providerId} WHERE id = #{id}")
    void updateProviderId(@Param("id") String id, @Param("providerId") String providerId);

    @Insert("INSERT INTO payment SET id = #{payment.id}, user_id = #{payment.userId}, price = #{payment.price}, currency = #{payment.currency}, locale = #{payment.locale}, status = #{payment.status}, provider = #{payment.provider}, provider_id = #{payment.providerId}")
    void insert(@Param("payment") PaymentDatabaseEntity paymentDatabaseEntity);
}
