package com.morethanheroic.payment.service.manipulator;

import com.morethanheroic.payment.domain.PaymentEntity;
import com.morethanheroic.payment.domain.PaymentItemEntity;
import com.morethanheroic.payment.repository.domain.PaymentItemDatabaseEntity;
import org.apache.commons.lang3.StringUtils;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.stereotype.Service;

@Service
@ConditionalOnBean(PaymentManipulator.class)
public class PaymentItemTransformer {

    private static final int MAXIMUM_DESCRIPTION_LENGTH = 128;

    public PaymentItemDatabaseEntity convert(final PaymentEntity parentPaymentEntity, final PaymentItemEntity paymentItemEntity) {
        final PaymentItemDatabaseEntity paymentItemDatabaseEntity = new PaymentItemDatabaseEntity();

        paymentItemDatabaseEntity.setPaymentId(parentPaymentEntity.getId());
        paymentItemDatabaseEntity.setItemId(paymentItemEntity.getItemId());
        paymentItemDatabaseEntity.setItemType(paymentItemEntity.getItemType());
        paymentItemDatabaseEntity.setName(paymentItemEntity.getName());
        paymentItemDatabaseEntity.setDescription(
                StringUtils.abbreviate(paymentItemEntity.getDescription(), MAXIMUM_DESCRIPTION_LENGTH));
        paymentItemDatabaseEntity.setQuantity(paymentItemEntity.getQuantity());
        paymentItemDatabaseEntity.setUnit(paymentItemEntity.getUnit());
        paymentItemDatabaseEntity.setUnitPrice(paymentItemEntity.getUnitPrice());
        paymentItemDatabaseEntity.setPrice(paymentItemEntity.getPrice());

        return paymentItemDatabaseEntity;
    }
}
