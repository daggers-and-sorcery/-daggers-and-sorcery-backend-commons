package com.morethanheroic.payment.repository.domain;

import com.morethanheroic.payment.domain.PaymentStatus;
import lombok.Data;

import java.math.BigDecimal;

@Data
public class PaymentDatabaseEntity {

    private String id;
    private String providerId;
    private int userId;
    private BigDecimal price;
    private String currency;
    private String locale;
    private PaymentStatus status;
    private String provider;
}
