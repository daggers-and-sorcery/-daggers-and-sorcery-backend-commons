package com.morethanheroic.payment.domain;

import com.morethanheroic.user.domain.UserEntity;

import java.math.BigDecimal;
import java.util.Currency;
import java.util.List;
import java.util.Locale;

/**
 * Contains the data of a payment.
 */
public interface PaymentEntity {

    /**
     * The unique id of the transaction. Used to identify the transaction.
     *
     * @return the unique id
     */
    String getId();

    /**
     * Contains the id of the transaction in the payment provider's system.
     *
     * @return the provider's id for the transaction
     */
    String getProviderId();

    /**
     * The user who initiated the transaction.
     *
     * @return the initiater of the transaction
     */
    UserEntity getUser();

    /**
     * The price to be paid.
     *
     * @return the price to be paid
     */
    BigDecimal getPrice();

    /**
     * The currency of the payment.
     *
     * @return the currency of the payment
     */
    Currency getCurrency();

    /**
     * The status of the payment.
     *
     * @return the status of the payment
     */
    PaymentStatus getStatus();

    /**
     * The locale of the interfaces that should be shown while handling the payment.
     *
     * @return the locale of the payment interfaces
     */
    Locale getLocale();

    /**
     * The items the user paying for.
     *
     * @return the items the user paying for
     */
    List<? extends PaymentItemEntity> getItems();

    /**
     * The payment provider that handle this payment.
     *
     * @return the payment provider
     */
    String getProvider();
}
