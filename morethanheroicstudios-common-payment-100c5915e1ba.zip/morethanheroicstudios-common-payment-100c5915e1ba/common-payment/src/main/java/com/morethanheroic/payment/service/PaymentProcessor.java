package com.morethanheroic.payment.service;

import com.morethanheroic.payment.domain.PaymentContext;
import com.morethanheroic.payment.domain.PaymentEntity;
import com.morethanheroic.payment.domain.result.PaymentResultEntity;

public interface PaymentProcessor<T extends PaymentContext> {

    PaymentResultEntity processPayment(T payment);
}
