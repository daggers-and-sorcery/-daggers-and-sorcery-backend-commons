package com.morethanheroic.payment.domain;

import java.math.BigDecimal;

/**
 * Contains the data of one item the user could pay for.
 */
public interface PaymentItemEntity {

    /**
     * The id of the payment item.
     *
     * @return the id of the payment item
     */
    int getId();

    /**
     * The id of the sold item. This exists to help us search back what kind of item did we sold.
     *
     * @return the id of the item
     */
    String getItemId();

    /**
     * Type of the item sold. Many shops have various types of items and the id's of those items can clash if the types
     * can have the same ids.
     *
     * @return the type of the item
     */
    String getItemType();

    /**
     * The name of the item.
     *
     * @return the name of the item
     */
    String getName();

    /**
     * The description of the item.
     *
     * @return the description of the item
     */
    String getDescription();

    /**
     * The quantity of the item.
     *
     * @return the quantity of the item
     */
    int getQuantity();

    /**
     * The unit type of the item (eg kg or liter).
     *
     * @return the unit type of the item
     */
    String getUnit();

    /**
     * The unit price of the item.
     *
     * @return the unit price of the item
     */
    BigDecimal getUnitPrice();

    /**
     * The total price of all of the units.
     *
     * @return the total price of the items
     */
    BigDecimal getPrice();
}
