package com.morethanheroic.payment.service.manipulator;

import com.morethanheroic.payment.domain.PaymentEntity;
import com.morethanheroic.payment.repository.PaymentItemRepository;
import com.morethanheroic.payment.repository.PaymentRepository;
import com.morethanheroic.payment.repository.domain.PaymentDatabaseEntity;
import com.morethanheroic.payment.service.manipulator.persistence.PaymentInsertExtender;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class PaymentSaver {

    private final PaymentTransformer paymentTransformer;
    private final PaymentRepository paymentRepository;
    private final PaymentItemRepository paymentItemRepository;
    private final PaymentItemTransformer paymentItemTransformer;
    private final List<PaymentInsertExtender> paymentInsertExtenders;

    public PaymentSaver(
            @Autowired final PaymentTransformer paymentTransformer,
            @Autowired final PaymentRepository paymentRepository,
            @Autowired final PaymentItemRepository paymentItemRepository,
            @Autowired final PaymentItemTransformer paymentItemTransformer,
            @Autowired(required = false) final List<PaymentInsertExtender> paymentInsertExtenders
    ) {
        this.paymentTransformer = paymentTransformer;
        this.paymentRepository = paymentRepository;
        this.paymentItemRepository = paymentItemRepository;
        this.paymentItemTransformer = paymentItemTransformer;

        if(paymentInsertExtenders  == null) {
            this.paymentInsertExtenders =  new ArrayList<>();
        } else {
            this.paymentInsertExtenders = paymentInsertExtenders;
        }
    }

    /**
     * Save the payment entity into the database. The related payment items will also be saved.
     *
     * @param paymentEntity the payment to save
     */
    public void save(final PaymentEntity paymentEntity) {
        final PaymentDatabaseEntity paymentDatabaseEntity = paymentTransformer.convert(paymentEntity);

        paymentRepository.insert(paymentDatabaseEntity);

        paymentEntity.getItems().stream()
                .map(paymentItem -> paymentItemTransformer.convert(paymentEntity, paymentItem))
                .forEach(paymentItemRepository::insert);

        paymentInsertExtenders.forEach(paymentInsertExtender -> paymentInsertExtender.insert(paymentEntity));
    }
}
