package com.morethanheroic.payment.domain;

import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class DefaultPaymentContext implements PaymentContext {

    private final PaymentEntity paymentEntity;
}
