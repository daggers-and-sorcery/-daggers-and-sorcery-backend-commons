package com.morethanheroic.payment.repository;

import com.morethanheroic.payment.repository.domain.PaymentItemDatabaseEntity;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface PaymentItemRepository {

    @Select("SELECT * FROM payment_items WHERE payment_id = #{paymentId} AND id = #{paymentItemId}")
    PaymentItemDatabaseEntity findItem(@Param("paymentId") String paymentId,
                                       @Param("paymentItemId") int paymentItemId);

    @Select("SELECT * FROM payment_items WHERE payment_id = #{paymentId}")
    List<PaymentItemDatabaseEntity> findItemsByPaymentId(@Param("paymentId") String paymentId);

    @Insert("INSERT INTO payment_items SET payment_id = #{paymentId}, item_id = #{itemId}, item_type = #{itemType}, name = #{name}, description = #{description}, quantity = #{quantity}, unit = #{unit}, unit_price = #{unitPrice}, price = #{price}")
    void insert(PaymentItemDatabaseEntity paymentItemDatabaseEntity);
}
