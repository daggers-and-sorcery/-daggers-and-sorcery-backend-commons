package com.morethanheroic.payment.service.manipulator.persistence;

import com.morethanheroic.payment.domain.PaymentItemEntity;

import java.util.List;

public interface PaymentItemEntityFactory {

    List<? extends PaymentItemEntity> getItemEntities(String paymentId);

    PaymentItemEntity getItemEntity(String paymentId, int paymentItemId);
}
