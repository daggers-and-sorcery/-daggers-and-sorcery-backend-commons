package com.morethanheroic.payment.domain;

import lombok.Builder;
import lombok.Getter;
import lombok.ToString;

import java.math.BigDecimal;

@Getter
@Builder
@ToString
public class DefaultPaymentItemEntity implements PaymentItemEntity {

    private final int id;
    private final String itemId;
    private final String itemType;
    private final String name;
    private final String description;
    private final int quantity;
    private final String unit;
    private final BigDecimal unitPrice;
    private final BigDecimal price;
}
