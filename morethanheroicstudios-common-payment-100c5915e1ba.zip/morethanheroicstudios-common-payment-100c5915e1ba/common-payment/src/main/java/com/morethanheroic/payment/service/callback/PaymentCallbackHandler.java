package com.morethanheroic.payment.service.callback;

import com.morethanheroic.payment.domain.PaymentEntity;
import com.morethanheroic.payment.domain.PaymentStatus;
import com.morethanheroic.payment.service.callback.domain.PaymentCallbackEntity;
import com.morethanheroic.payment.service.manipulator.PaymentManipulator;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class PaymentCallbackHandler {

    private final List<PaymentCallback> paymentCallbacks;
    private final PaymentManipulator paymentManipulator;

    public void handlePaymentCallback(final PaymentCallbackEntity paymentCallbackEntity) {
        final PaymentEntity paymentEntity = paymentManipulator.find(paymentCallbackEntity.getPaymentId());

        if (paymentEntity.getStatus() == PaymentStatus.FINISHED) {
            return;
        }

        paymentCallbacks.forEach(paymentCallback -> paymentCallback.callback(paymentEntity));
    }
}
