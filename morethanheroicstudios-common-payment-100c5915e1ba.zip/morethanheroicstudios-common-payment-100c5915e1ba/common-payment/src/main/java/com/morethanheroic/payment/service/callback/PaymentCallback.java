package com.morethanheroic.payment.service.callback;

import com.morethanheroic.payment.domain.PaymentEntity;

/**
 * This method should be implemented when we want to handle the actual result of a payment. Usually this happens when
 * the payment server calls back to the application to notify us that the payment was successfully done.
 */
public interface PaymentCallback {

    /**
     * Called when the payment server calls back the application.
     *
     * @param paymentEntity the payment entity that's we are notified about
     */
    void callback(PaymentEntity paymentEntity);
}
