package com.morethanheroic.payment.domain;

public enum PaymentStatus {

    INITIATED,
    FINISHED
}
