package com.morethanheroic.payment.service.manipulator;

import com.morethanheroic.payment.domain.PaymentEntity;
import com.morethanheroic.payment.repository.domain.PaymentDatabaseEntity;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.stereotype.Service;

@Service
@ConditionalOnBean(PaymentManipulator.class)
public class PaymentTransformer {

    public PaymentDatabaseEntity convert(final PaymentEntity paymentEntity) {
        final PaymentDatabaseEntity paymentDatabaseEntity = new PaymentDatabaseEntity();

        paymentDatabaseEntity.setId(paymentEntity.getId());
        paymentDatabaseEntity.setPrice(paymentEntity.getPrice());
        paymentDatabaseEntity.setCurrency(paymentEntity.getCurrency().getCurrencyCode());
        paymentDatabaseEntity.setUserId(paymentEntity.getUser().getId());
        paymentDatabaseEntity.setLocale(paymentEntity.getLocale().toString());
        paymentDatabaseEntity.setStatus(paymentEntity.getStatus());
        paymentDatabaseEntity.setProvider(paymentEntity.getProvider());

        return paymentDatabaseEntity;
    }
}
