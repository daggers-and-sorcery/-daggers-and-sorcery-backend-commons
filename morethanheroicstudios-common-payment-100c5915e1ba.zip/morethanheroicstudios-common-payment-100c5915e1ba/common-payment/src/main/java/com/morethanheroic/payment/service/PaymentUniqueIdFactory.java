package com.morethanheroic.payment.service;

import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
@ConditionalOnBean(PaymentHandler.class)
public class PaymentUniqueIdFactory {

    public String newUniquePaymentId() {
        return UUID.randomUUID().toString();
    }
}
