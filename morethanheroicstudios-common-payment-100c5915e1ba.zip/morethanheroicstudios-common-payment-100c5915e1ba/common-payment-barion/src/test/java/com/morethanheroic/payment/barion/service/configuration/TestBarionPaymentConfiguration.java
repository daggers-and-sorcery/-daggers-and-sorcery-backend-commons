package com.morethanheroic.payment.barion.service.configuration;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.morethanheroic.payment.repository.PaymentRepository;
import com.morethanheroic.payment.repository.domain.PaymentDatabaseEntity;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("com.morethanheroic.payment")
public class TestBarionPaymentConfiguration {

    @Bean
    public ObjectMapper objectMapper() {
        return new ObjectMapper();
    }
}
