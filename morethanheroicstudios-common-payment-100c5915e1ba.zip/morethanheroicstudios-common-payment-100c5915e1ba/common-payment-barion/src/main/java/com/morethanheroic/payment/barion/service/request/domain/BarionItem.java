package com.morethanheroic.payment.barion.service.request.domain;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Getter;

import java.math.BigDecimal;

@Getter
@Builder
@JsonAutoDetect(
        fieldVisibility = JsonAutoDetect.Visibility.ANY,
        getterVisibility = JsonAutoDetect.Visibility.NONE,
        setterVisibility = JsonAutoDetect.Visibility.NONE
)
public class BarionItem {

    @JsonProperty("Name")
    private final String name;

    @JsonProperty("Description")
    private final String description;

    @JsonProperty("Quantity")
    private final int quantity;

    @JsonProperty("Unit")
    private final String unit;

    @JsonProperty("UnitPrice")
    private final BigDecimal unitPrice;

    @JsonProperty("ItemTotal")
    private final BigDecimal totalPrice;
}
