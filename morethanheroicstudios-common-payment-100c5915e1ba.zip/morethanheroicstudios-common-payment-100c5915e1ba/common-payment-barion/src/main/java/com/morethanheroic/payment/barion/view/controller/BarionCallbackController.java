package com.morethanheroic.payment.barion.view.controller;

import com.morethanheroic.payment.service.callback.PaymentCallbackHandler;
import com.morethanheroic.payment.service.callback.domain.PaymentCallbackEntity;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
public class BarionCallbackController {

    private final PaymentCallbackHandler paymentCallbackHandler;

    /**
     * This mapping is responsible for handling the callbacks from the Barion servers. It's a POST mapping without a
     * body by design. Doesn't change it to GET because it's not going to work.
     *
     * @param paymentId the payment's id that this callback belongs to
     */
    @PostMapping("/payment/barion/callback/{paymentId}")
    public void barionCallback(@PathVariable final String paymentId) {
        paymentCallbackHandler.handlePaymentCallback(
                PaymentCallbackEntity.builder()
                        .paymentId(paymentId)
                        .build()
        );
    }
}
