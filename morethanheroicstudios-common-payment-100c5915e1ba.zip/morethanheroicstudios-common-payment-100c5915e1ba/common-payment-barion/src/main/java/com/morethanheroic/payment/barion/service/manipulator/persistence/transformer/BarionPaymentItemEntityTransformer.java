package com.morethanheroic.payment.barion.service.manipulator.persistence.transformer;

import com.morethanheroic.payment.repository.domain.PaymentItemDatabaseEntity;
import com.morethanheroic.payment.barion.service.domain.BarionPaymentItemEntity;
import org.springframework.stereotype.Service;

@Service
public class BarionPaymentItemEntityTransformer {

    public BarionPaymentItemEntity transform(final PaymentItemDatabaseEntity paymentItemDatabaseEntity) {
        return BarionPaymentItemEntity.builder()
                .id(paymentItemDatabaseEntity.getId())
                .itemId(paymentItemDatabaseEntity.getItemId())
                .itemType(paymentItemDatabaseEntity.getItemType())
                .name(paymentItemDatabaseEntity.getName())
                .description(paymentItemDatabaseEntity.getDescription())
                .quantity(paymentItemDatabaseEntity.getQuantity())
                .unitPrice(paymentItemDatabaseEntity.getUnitPrice())
                .unit(paymentItemDatabaseEntity.getUnit())
                .price(paymentItemDatabaseEntity.getPrice())
                .build();
    }
}
