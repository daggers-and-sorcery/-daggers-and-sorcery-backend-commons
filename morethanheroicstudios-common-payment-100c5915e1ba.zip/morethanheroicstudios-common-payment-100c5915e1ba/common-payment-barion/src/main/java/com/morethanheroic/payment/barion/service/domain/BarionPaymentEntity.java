package com.morethanheroic.payment.barion.service.domain;

import com.morethanheroic.payment.domain.PaymentEntity;
import com.morethanheroic.payment.domain.PaymentStatus;
import com.morethanheroic.user.domain.UserEntity;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.math.BigDecimal;
import java.util.Currency;
import java.util.List;
import java.util.Locale;

@ToString
@Getter
@Builder
public class BarionPaymentEntity implements PaymentEntity {

    private final String id;
    private final String providerId;
    private final UserEntity user;
    private final BigDecimal price;
    private final Currency currency;
    private final Locale locale;
    private final List<BarionPaymentItemEntity> items;
    private final BarionPaymentType paymentType;

    @Setter
    private PaymentStatus status;

    @Override
    public String getProvider() {
        return "BARION";
    }
}
