package com.morethanheroic.payment.barion.repository.domain;

import com.morethanheroic.payment.barion.service.domain.BarionPaymentType;
import lombok.Data;

@Data
public class BarionPaymentDatabaseEntity {

    private String id;
    private BarionPaymentType paymentType;
}
