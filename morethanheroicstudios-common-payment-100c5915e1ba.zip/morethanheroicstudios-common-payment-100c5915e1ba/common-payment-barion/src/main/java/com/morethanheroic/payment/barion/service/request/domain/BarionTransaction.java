package com.morethanheroic.payment.barion.service.request.domain;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Getter;

import java.math.BigDecimal;
import java.util.List;

@Getter
@Builder
@JsonAutoDetect(
        fieldVisibility = JsonAutoDetect.Visibility.ANY,
        getterVisibility = JsonAutoDetect.Visibility.NONE,
        setterVisibility = JsonAutoDetect.Visibility.NONE
)
public class BarionTransaction {

    @JsonProperty("POSTransactionId")
    private final String posTransactionId;

    @JsonProperty("Payee")
    private final String payee;

    @JsonProperty("Items")
    private final List<BarionItem> items;

    @JsonProperty("Total")
    private final BigDecimal total;
}
