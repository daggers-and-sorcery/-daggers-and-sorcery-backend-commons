package com.morethanheroic.payment.barion.service.domain;

import com.morethanheroic.payment.domain.PaymentContext;
import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class BarionPaymentContext implements PaymentContext {

    private final BarionPaymentEntity paymentEntity;
}
