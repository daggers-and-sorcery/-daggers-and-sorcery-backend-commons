package com.morethanheroic.payment.barion.repository;

import com.morethanheroic.payment.barion.repository.domain.BarionPaymentDatabaseEntity;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

@Mapper
public interface BarionPaymentRepository {

    @Select("SELECT * FROM barion_payment WHERE id = #{paymentId}")
    BarionPaymentDatabaseEntity findById(@Param("paymentId") String paymentId);

    @Insert("INSERT INTO barion_payment SET id = #{payment.id}, payment_type = #{payment.paymentType}")
    void insert(@Param("payment") BarionPaymentDatabaseEntity barionPaymentDatabaseEntity);
}
