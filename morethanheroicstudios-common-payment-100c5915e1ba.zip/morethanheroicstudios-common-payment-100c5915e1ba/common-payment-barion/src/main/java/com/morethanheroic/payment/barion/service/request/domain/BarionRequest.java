package com.morethanheroic.payment.barion.service.request.domain;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Getter;

import java.util.List;

@Getter
@Builder
@JsonAutoDetect(
        fieldVisibility = JsonAutoDetect.Visibility.ANY,
        getterVisibility = JsonAutoDetect.Visibility.NONE,
        setterVisibility = JsonAutoDetect.Visibility.NONE
)
public class BarionRequest {

    @JsonProperty("POSKey")
    private final String posKey;

    @JsonProperty("PaymentType")
    private final String paymentType;

    @JsonProperty("GuestCheckOut")
    private final boolean guestCheckoutAllowed;

    @JsonProperty("FundingSources")
    private final List<String> fundingSources;

    @JsonProperty("PaymentRequestId")
    private final String paymentRequestId;

    @JsonProperty("RedirectUrl")
    private final String redirectUrl;

    @JsonProperty("CallbackUrl")
    private final String callbackUrl;

    @JsonProperty("Transactions")
    private final List<BarionTransaction> transactions;

    @JsonProperty("Locale")
    private final String locale;

    @JsonProperty("Currency")
    private final String currency;
}
