package com.morethanheroic.payment.barion.service.request;

import com.morethanheroic.payment.barion.service.BarionPaymentProcessor;
import com.morethanheroic.payment.barion.service.domain.BarionFundingSource;
import com.morethanheroic.payment.barion.service.domain.BarionPaymentEntity;
import com.morethanheroic.payment.barion.service.request.domain.BarionItem;
import com.morethanheroic.payment.barion.service.request.domain.BarionRequest;
import com.morethanheroic.payment.barion.service.request.domain.BarionTransaction;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

@Service
@ConditionalOnBean(BarionPaymentProcessor.class)
public class BarionRequestFactory {

    @Value("${payment.provider.barion.pos-key}")
    private String posKey;

    @Value("${payment.provider.barion.guest-checkout-allowed:'true'}")
    private boolean guestCheckoutAllowed;

    @Value("${payment.provider.barion.funding-sources:'ALL'}")
    private List<BarionFundingSource> fundingSources;

    @Value("${payment.provider.barion.redirect-url-base}")
    private String redirectUrlBase;

    @Value("${payment.provider.barion.callback-url-base}")
    private String callbackUrlBase;

    @Value("${payment.provider.barion.payment-recipient}")
    private String paymentRecipient;

    public BarionRequest newRequest(final BarionPaymentEntity paymentEntity) {
        return BarionRequest.builder()
                .posKey(posKey)
                .paymentType(paymentEntity.getPaymentType().name())
                .guestCheckoutAllowed(guestCheckoutAllowed)
                .fundingSources(
                        fundingSources.stream()
                                .map(BarionFundingSource::getFoundingSourceName)
                                .collect(Collectors.toList())
                )
                .paymentRequestId(String.valueOf(paymentEntity.getId()))
                .redirectUrl(redirectUrlBase + paymentEntity.getId())
                .callbackUrl(callbackUrlBase + "payment/barion/callback/" + paymentEntity.getId())
                .transactions(
                        Collections.singletonList(
                                BarionTransaction.builder()
                                        .posTransactionId(String.valueOf(paymentEntity.getId()))
                                        .payee(paymentRecipient)
                                        .total(paymentEntity.getPrice())
                                        .items(
                                                paymentEntity.getItems().stream()
                                                        .map(barionPaymentItemEntity ->
                                                                BarionItem.builder()
                                                                        .name(barionPaymentItemEntity.getName())
                                                                        .description(barionPaymentItemEntity.getDescription())
                                                                        .quantity(barionPaymentItemEntity.getQuantity())
                                                                        .unit(barionPaymentItemEntity.getUnit())
                                                                        .unitPrice(barionPaymentItemEntity.getUnitPrice())
                                                                        .totalPrice(barionPaymentItemEntity.getPrice())
                                                                        .build()
                                                        )
                                                        .collect(Collectors.toList())
                                        )
                                        .build()
                        )
                )
                .locale(paymentEntity.getLocale().toString().replace("_", "-"))
                .currency(paymentEntity.getCurrency().getCurrencyCode())
                .build();
    }
}
