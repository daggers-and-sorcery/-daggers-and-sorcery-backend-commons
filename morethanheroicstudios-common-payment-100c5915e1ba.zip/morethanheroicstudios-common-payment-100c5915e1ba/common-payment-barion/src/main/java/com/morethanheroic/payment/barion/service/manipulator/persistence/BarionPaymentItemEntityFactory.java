package com.morethanheroic.payment.barion.service.manipulator.persistence;

import com.morethanheroic.payment.domain.PaymentItemEntity;
import com.morethanheroic.payment.repository.PaymentItemRepository;
import com.morethanheroic.payment.repository.domain.PaymentItemDatabaseEntity;
import com.morethanheroic.payment.barion.service.domain.BarionPaymentItemEntity;
import com.morethanheroic.payment.barion.service.manipulator.persistence.transformer.BarionPaymentItemEntityTransformer;
import com.morethanheroic.payment.service.manipulator.persistence.PaymentItemEntityFactory;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@Primary
@RequiredArgsConstructor
public class BarionPaymentItemEntityFactory implements PaymentItemEntityFactory {

    private final PaymentItemRepository paymentItemRepository;
    private final BarionPaymentItemEntityTransformer barionPaymentItemEntityTransformer;

    @Override
    public List<BarionPaymentItemEntity> getItemEntities(final String paymentId) {
        final List<PaymentItemDatabaseEntity> paymentItemDatabaseEntities =
                paymentItemRepository.findItemsByPaymentId(paymentId);

        return paymentItemDatabaseEntities.stream()
                .map(barionPaymentItemEntityTransformer::transform)
                .collect(Collectors.toList());
    }

    @Override
    public PaymentItemEntity getItemEntity(String paymentId, int paymentItemId) {
        return barionPaymentItemEntityTransformer.transform(paymentItemRepository.findItem(paymentId, paymentItemId));
    }
}
