package com.morethanheroic.payment.barion.service.domain;

public enum BarionPaymentType {

    IMMEDIATE,
    RESERVATION
}
