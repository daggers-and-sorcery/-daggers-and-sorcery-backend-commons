package com.morethanheroic.payment.barion.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.morethanheroic.payment.domain.PaymentEntity;
import com.morethanheroic.payment.domain.result.PaymentResult;
import com.morethanheroic.payment.repository.PaymentRepository;
import com.morethanheroic.payment.barion.service.domain.BarionPaymentContext;
import com.morethanheroic.payment.barion.service.domain.BarionPaymentEntity;
import com.morethanheroic.payment.barion.service.domain.BarionPaymentResultEntity;
import com.morethanheroic.payment.barion.service.request.BarionRequestFactory;
import com.morethanheroic.payment.barion.service.request.domain.BarionRequest;
import com.morethanheroic.payment.barion.service.response.domain.BarionResponse;
import com.morethanheroic.payment.service.PaymentProcessor;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.HttpHeaders;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.client.methods.RequestBuilder;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.charset.Charset;

@Slf4j
@Service
@RequiredArgsConstructor
@ConditionalOnProperty(name = "payment.provider", havingValue = "barion")
public class BarionPaymentProcessor implements PaymentProcessor<BarionPaymentContext> {

    private final BarionRequestFactory barionRequestFactory;
    private final PaymentRepository paymentRepository;
    private final ObjectMapper objectMapper;

    @Value("${payment.provider.barion.api-url}")
    private String barionApiUrl;

    @Override
    public BarionPaymentResultEntity processPayment(final BarionPaymentContext paymentContext) {
        final BarionPaymentEntity paymentEntity = paymentContext.getPaymentEntity();
        final BarionRequest barionRequest = barionRequestFactory.newRequest(paymentEntity);

        try {
            final String payload = objectMapper.writeValueAsString(barionRequest);

            final HttpClient httpClient = HttpClientBuilder.create()
                    .build();

            final HttpUriRequest httpRequest = RequestBuilder.post(barionApiUrl + "/v2/payment/start")
                    .addHeader(HttpHeaders.CONTENT_TYPE, "application/json")
                    .setEntity(new StringEntity(payload, Charset.forName("UTF-8")))
                    .build();

            final HttpResponse httpResponse = httpClient.execute(httpRequest);
            final String responseData = EntityUtils.toString(httpResponse.getEntity());
            final BarionResponse barionResponse = objectMapper.readValue(responseData, BarionResponse.class);

            updateProviderId(paymentEntity, barionResponse.getProviderId());

            return isSuccessfulResponse(httpResponse) ? buildSuccessfulPaymentResult(barionResponse.getRedirectUrl()) :
                    buildUnsuccessfulPaymentResult();
        } catch (IOException e) {
            log.error("Error happened while trying to write payment data!", e);

            return buildUnsuccessfulPaymentResult();
        }
    }

    private boolean isSuccessfulResponse(final HttpResponse httpResponse) {
        return httpResponse.getStatusLine().getStatusCode() == 200;
    }

    private BarionPaymentResultEntity buildUnsuccessfulPaymentResult() {
        return BarionPaymentResultEntity.builder()
                .result(PaymentResult.UNSUCCESSFUL)
                .build();
    }

    private BarionPaymentResultEntity buildSuccessfulPaymentResult(final String redirectUrl) {
        return BarionPaymentResultEntity.builder()
                .result(PaymentResult.SUCCESSFUL)
                .redirectUrl(redirectUrl)
                .build();
    }

    private void updateProviderId(final PaymentEntity paymentEntity, final String providerId) {
        paymentRepository.updateProviderId(paymentEntity.getId(), providerId);
    }
}
