package com.morethanheroic.payment.barion.service.callback;

import com.morethanheroic.payment.barion.service.domain.BarionPaymentEntity;
import com.morethanheroic.payment.domain.PaymentEntity;
import com.morethanheroic.payment.domain.PaymentStatus;
import com.morethanheroic.payment.service.callback.PaymentCallback;
import com.morethanheroic.payment.service.manipulator.PaymentManipulator;
import com.morethanheroic.payment.barion.service.status.QueryPaymentStatusRequestSender;
import com.morethanheroic.payment.barion.service.status.domain.QueryPaymentStatusResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@Order(Ordered.HIGHEST_PRECEDENCE)
@RequiredArgsConstructor
public class BarionUpdateStatusPaymentCallback implements PaymentCallback {

    private final PaymentManipulator paymentManipulator;
    private final QueryPaymentStatusRequestSender queryPaymentStatusRequestSender;

    @Override
    public void callback(final PaymentEntity paymentEntity) {
        log.info("Got barion callback call for " + paymentEntity.getId() + "!   ");

        final QueryPaymentStatusResponse paymentStatusResponse =
                queryPaymentStatusRequestSender.sendQueryStatusRequest(paymentEntity);

        log.info("Barion payment status query for id: [" + paymentEntity.getId() + "] and provider id: ["
                + paymentEntity.getProviderId() + "] result: " + paymentStatusResponse + "!");

        if (paymentStatusResponse.getErrors() != null && paymentStatusResponse.getErrors().size() > 0) {
            paymentStatusResponse.getErrors()
                    .forEach(queryPaymentStatusErrorResponse ->
                            log.error("Error [" + queryPaymentStatusErrorResponse.getErrorCode() + "] happened while " +
                                    "processing payment! Title: " + queryPaymentStatusErrorResponse.getTitle()
                                    + " Description: " + queryPaymentStatusErrorResponse.getDescription() + "!")
                    );

            return;
        }

        if (paymentStatusResponse.getStatus().equals("Succeeded")) {
            log.info("Got callback from Barion! Payment [" + paymentEntity.getId() + "] finished successfully!");

            ((BarionPaymentEntity) paymentEntity).setStatus(PaymentStatus.FINISHED);

            paymentManipulator.updateStatus(paymentEntity.getId(), PaymentStatus.FINISHED);
        } else {
            log.info("Got unknown payment status callback from Barion for payment [" + paymentEntity.getId()
                    + "] with status [" + paymentStatusResponse.getStatus() + "]!");
        }
    }
}
