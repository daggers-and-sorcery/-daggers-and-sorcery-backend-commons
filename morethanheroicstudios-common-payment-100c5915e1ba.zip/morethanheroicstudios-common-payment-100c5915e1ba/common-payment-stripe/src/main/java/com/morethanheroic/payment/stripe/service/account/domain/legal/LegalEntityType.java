package com.morethanheroic.payment.stripe.service.account.domain.legal;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public enum LegalEntityType {

    INDIVIDUAL("individual"),
    COMPANY("company");

    private final String name;
}
