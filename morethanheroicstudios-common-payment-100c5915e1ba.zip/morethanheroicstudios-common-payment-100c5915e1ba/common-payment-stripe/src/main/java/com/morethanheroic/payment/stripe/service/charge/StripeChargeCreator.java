package com.morethanheroic.payment.stripe.service.charge;

import com.morethanheroic.payment.domain.result.PaymentResult;
import com.morethanheroic.payment.stripe.configuration.StripePaymentsProperties;
import com.morethanheroic.payment.stripe.service.charge.domain.ChargeEntity;
import com.stripe.exception.*;
import com.stripe.model.Charge;
import com.stripe.net.RequestOptions;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

@Slf4j
@Service
@RequiredArgsConstructor
@ConditionalOnProperty(name = "payment.provider", havingValue = "stripe")
public class StripeChargeCreator {

    private final StripePaymentsProperties stripePaymentsProperties;

    public PaymentResult createCharge(final ChargeEntity chargeEntity) {
        try {
            final Map<String, Object> chargeParams = new HashMap<>();

            chargeParams.put("amount", chargeEntity.getPrice()
                    .multiply(BigDecimal.valueOf(100))
                    .intValue()
            );
            chargeParams.put("currency", chargeEntity.getCurrency().getCurrencyCode());
            chargeParams.put("source", chargeEntity.getChargedSource());

            if (chargeEntity.getApplicationFee() != 0) {
                chargeParams.put("application_fee", chargeEntity.getApplicationFee());
            }

            final Charge charge = Charge.create(
                    chargeParams,
                    RequestOptions.builder()
                            .setStripeAccount(chargeEntity.getChargingAccount())
                            .setApiKey(stripePaymentsProperties.getApiKey())
                            .build()
            );

            if (charge.getOutcome().getType().equals("authorized")) {
                return PaymentResult.SUCCESSFUL;
            }

        } catch (AuthenticationException | InvalidRequestException | CardException | APIConnectionException
                | APIException e) {
            log.error("Unable to charge a user!", e);
        }

        return PaymentResult.UNSUCCESSFUL;
    }
}
