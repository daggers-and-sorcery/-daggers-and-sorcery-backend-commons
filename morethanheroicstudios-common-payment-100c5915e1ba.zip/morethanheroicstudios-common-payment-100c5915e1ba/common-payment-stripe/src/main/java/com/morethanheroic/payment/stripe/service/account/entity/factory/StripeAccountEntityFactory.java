package com.morethanheroic.payment.stripe.service.account.entity.factory;

import com.morethanheroic.payment.stripe.configuration.StripePaymentsProperties;
import com.morethanheroic.payment.stripe.service.account.entity.factory.domain.AdditionalOwnerEntity;
import com.morethanheroic.payment.stripe.service.account.entity.factory.domain.StripeAccountEntity;
import com.morethanheroic.payment.stripe.service.account.entity.factory.exception.AccountEntityCreationException;
import com.stripe.exception.*;
import com.stripe.model.Account;
import com.stripe.model.LegalEntity;
import com.stripe.net.RequestOptions;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
public class StripeAccountEntityFactory {

    private final StripePaymentsProperties stripePaymentsProperties;

    public StripeAccountEntity getEntity(final String accountId) {
        try {
            final Account account = Account.retrieve(accountId,
                    RequestOptions.builder()
                            .setApiKey(stripePaymentsProperties.getApiKey())
                            .build()
            );

            return StripeAccountEntity.builder()
                    .verified(account.getVerification().getFieldsNeeded().isEmpty())
                    .additionalOwners(buildAdditionalOwners(account.getLegalEntity().getAdditionalOwners()))
                    .build();
        } catch (AuthenticationException | InvalidRequestException | CardException | APIConnectionException
                | APIException e) {
            throw new AccountEntityCreationException("Unable to create AccountEntity!", e);
        }
    }

    private List<AdditionalOwnerEntity> buildAdditionalOwners(final List<LegalEntity.Owner> owners) {
        final List<AdditionalOwnerEntity> result = new ArrayList<>();

        for (int i = 0; i < owners.size(); i++) {
            result.add(
                    AdditionalOwnerEntity.builder()
                            .id(i)
                            .firstName(owners.get(i).getFirstName())
                            .lastName(owners.get(i).getLastName())
                            .build()
            );
        }

        return result;
    }
}
