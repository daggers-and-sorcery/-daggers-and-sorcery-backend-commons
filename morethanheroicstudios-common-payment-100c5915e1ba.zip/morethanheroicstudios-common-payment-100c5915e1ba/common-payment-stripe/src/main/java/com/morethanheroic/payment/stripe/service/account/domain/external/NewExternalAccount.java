package com.morethanheroic.payment.stripe.service.account.domain.external;

import com.morethanheroic.payment.stripe.domain.account.AccountHolderType;
import com.neovisionaries.i18n.CountryCode;
import lombok.Builder;
import lombok.Getter;
import lombok.NonNull;

import java.util.Currency;

/**
 * Contains data about the external accounts (bank account, debit card etc) of the business.
 */
@Getter
@Builder
public class NewExternalAccount {

    /**
     * The type of external account. Should be bank_account. (Required)
     */
    @NonNull
    private final String object;

    /**
     * The country in which the bank account is located. (Required)
     */
    @NonNull
    private final CountryCode country;

    /**
     * The currency this account has chosen to use as the default. (Required)
     */
    @NonNull
    private final Currency currency;

    /**
     * The name of the person or business that owns the bank account. This field is required when attaching the bank
     * account to a Customer object.
     */
    private final String accountHolderName;

    /**
     * The type of entity that holds the account. This field is required when attaching the bank account to a Customer
     * object.
     */
    private final AccountHolderType accountHolderType;

    /**
     * The account number for the bank account, in string form. Must be a checking account. (Required)
     */
    @NonNull
    private final String accountNumber;
}
