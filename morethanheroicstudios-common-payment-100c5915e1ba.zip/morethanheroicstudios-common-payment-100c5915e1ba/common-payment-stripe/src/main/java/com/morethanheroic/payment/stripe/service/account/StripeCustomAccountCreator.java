package com.morethanheroic.payment.stripe.service.account;

import com.morethanheroic.payment.stripe.configuration.StripePaymentsProperties;
import com.morethanheroic.payment.stripe.service.account.domain.NewCustomAccount;
import com.morethanheroic.payment.stripe.service.account.domain.external.NewExternalAccount;
import com.morethanheroic.payment.stripe.service.account.domain.legal.NewAdditionalOwner;
import com.morethanheroic.payment.stripe.service.account.domain.legal.NewLegalEntity;
import com.morethanheroic.payment.stripe.service.account.domain.legal.NewLegalEntityAddress;
import com.morethanheroic.payment.stripe.service.account.exception.AccountCreationException;
import com.stripe.exception.*;
import com.stripe.model.Account;
import com.stripe.net.RequestOptions;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
@ConditionalOnProperty(name = "payment.provider", havingValue = "stripe")
public class StripeCustomAccountCreator {

    private final StripePaymentsProperties stripePaymentsProperties;

    public String createCustomAccount(final NewCustomAccount newCustomAccount) {
        try {
            log.info("Creating new account for business: " + newCustomAccount.getBusinessName());

            final Account account = Account.create(
                    buildAccountData(newCustomAccount),
                    RequestOptions.builder()
                            .setApiKey(stripePaymentsProperties.getApiKey())
                            .build()
            );

            return account.getId();
        } catch (AuthenticationException | InvalidRequestException | APIConnectionException | CardException
                | APIException e) {
            throw new AccountCreationException("Unable to create custom account for Stripe!", e);
        }
    }

    private Map<String, Object> buildAccountData(final NewCustomAccount newCustomAccount) {
        final Map<String, Object> accountData = new HashMap<>();

        accountData.put("type", newCustomAccount.getType().getName());
        accountData.put("country", newCustomAccount.getCountry().getAlpha2());
        accountData.put("email", newCustomAccount.getEmail());
        accountData.put("default_currency", newCustomAccount.getDefaultCurrency().getCurrencyCode());
        accountData.put("tos_acceptance", builtTosAcceptance(newCustomAccount.getIp(), newCustomAccount.getUserAgent()));

        if (newCustomAccount.getBusinessName() != null) {
            accountData.put("business_name", newCustomAccount.getBusinessName());
        }

        if (newCustomAccount.getExternalAccount() != null) {
            accountData.put("external_account", buildExternalAccounts(newCustomAccount.getExternalAccount()));
        }

        if (newCustomAccount.getLegalEntity() != null) {
            accountData.put("legal_entity", buildLegalEntity(newCustomAccount.getLegalEntity()));
        }

        if (newCustomAccount.getMetadata() != null) {
            accountData.put("metadata", newCustomAccount.getMetadata());
        }

        if (newCustomAccount.getProductDescription() != null) {
            accountData.put("product_description", newCustomAccount.getProductDescription());
        }

        return accountData;
    }

    private Map<String, Object> builtTosAcceptance(final String ip, final String userAgent) {
        final Map<String, Object> tosAcceptanceData = new HashMap<>();

        tosAcceptanceData.put("date", System.currentTimeMillis() / 1000L);
        tosAcceptanceData.put("ip", ip);
        tosAcceptanceData.put("user_agent", userAgent);

        return tosAcceptanceData;
    }

    private Map<String, Object> buildExternalAccounts(final NewExternalAccount externalAccounts) {
        final Map<String, Object> externalAccountData = new HashMap<>();

        externalAccountData.put("object", externalAccounts.getObject());
        externalAccountData.put("country", externalAccounts.getCountry().getAlpha2());
        externalAccountData.put("currency", externalAccounts.getCurrency().getCurrencyCode());
        externalAccountData.put("account_number", externalAccounts.getAccountNumber());

        if (externalAccounts.getAccountHolderName() != null) {
            externalAccountData.put("account_holder_name", externalAccounts.getAccountHolderName());
        }

        if (externalAccounts.getAccountHolderType() != null) {
            externalAccountData.put("account_holder_type", externalAccounts.getAccountHolderType().getName());
        }

        return externalAccountData;
    }

    private Map<String, Object> buildLegalEntity(final NewLegalEntity newLegalEntity) {
        final Map<String, Object> legalEntityData = new HashMap<>();

        legalEntityData.put("business_name", newLegalEntity.getBusinessName());
        legalEntityData.put("business_tax_id", newLegalEntity.getBusinessTaxId());
        legalEntityData.put("address", buildLegalEntityAddress(newLegalEntity.getAddress()));
        legalEntityData.put("first_name", newLegalEntity.getRepresentativeFirstName());
        legalEntityData.put("last_name", newLegalEntity.getRepresentativeLastName());
        legalEntityData.put("personal_address", buildLegalEntityAddress(newLegalEntity.getRepresentativeAddress()));
        legalEntityData.put("dob", buildDayOfBirth(newLegalEntity.getRepresentativeDayOfBirth()));
        legalEntityData.put("type", newLegalEntity.getType().getName());

        if (newLegalEntity.getAdditionalOwners() != null && !newLegalEntity.getAdditionalOwners().isEmpty()) {
            legalEntityData.put("additional_owners", buildAdditionalOwners(newLegalEntity.getAdditionalOwners()));
        }

        return legalEntityData;
    }

    private List<Map<String, Object>> buildAdditionalOwners(final List<NewAdditionalOwner> additionalOwners) {
        return additionalOwners.stream()
                .map((additionalOwner) -> {
                    final Map<String, Object> additionalOwnerData = new HashMap<>();

                    additionalOwnerData.put("address", buildLegalEntityAddress(additionalOwner.getAddress()));
                    additionalOwnerData.put("first_name", additionalOwner.getFirstName());
                    additionalOwnerData.put("last_name", additionalOwner.getLastName());
                    additionalOwnerData.put("dob", buildDayOfBirth(additionalOwner.getDayOfBirth()));

                    return additionalOwnerData;
                })
                .collect(Collectors.toList());
    }

    private Map<String, Object> buildDayOfBirth(final LocalDate dayOfBirth) {
        final Map<String, Object> dayOfBirthData = new HashMap<>();

        dayOfBirthData.put("day", dayOfBirth.getDayOfMonth());
        dayOfBirthData.put("month", dayOfBirth.getMonthValue());
        dayOfBirthData.put("year", dayOfBirth.getYear());

        return dayOfBirthData;
    }

    private Map<String, String> buildLegalEntityAddress(final NewLegalEntityAddress newLegalEntityAddress) {
        final Map<String, String> legalEntityAddressData = new HashMap<>();

        if (newLegalEntityAddress.getCity() != null) {
            legalEntityAddressData.put("city", newLegalEntityAddress.getCity());
        }

        if (newLegalEntityAddress.getCountry() != null) {
            legalEntityAddressData.put("country", newLegalEntityAddress.getCountry().getAlpha2());
        }

        if (newLegalEntityAddress.getLine1() != null) {
            legalEntityAddressData.put("line1", newLegalEntityAddress.getLine1());
        }

        if (newLegalEntityAddress.getLine2() != null) {
            legalEntityAddressData.put("line2", newLegalEntityAddress.getLine2());
        }

        if (newLegalEntityAddress.getPostalCode() != null) {
            legalEntityAddressData.put("postal_code", newLegalEntityAddress.getPostalCode());
        }

        if (newLegalEntityAddress.getState() != null) {
            legalEntityAddressData.put("state", newLegalEntityAddress.getState());
        }

        return legalEntityAddressData;
    }
}
