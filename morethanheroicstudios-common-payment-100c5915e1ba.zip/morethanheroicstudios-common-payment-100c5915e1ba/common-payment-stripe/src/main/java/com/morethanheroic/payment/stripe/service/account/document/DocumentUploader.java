package com.morethanheroic.payment.stripe.service.account.document;

import com.morethanheroic.payment.stripe.configuration.StripePaymentsProperties;
import com.stripe.exception.*;
import com.stripe.model.FileUpload;
import com.stripe.net.RequestOptions;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Service;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

@Slf4j
@Service
@RequiredArgsConstructor
@ConditionalOnProperty(name = "payment.provider", havingValue = "stripe")
public class DocumentUploader {

    private final StripePaymentsProperties stripePaymentsProperties;

    public String uploadLegalDocument(final String accountId, final File legalDocument) {
        final RequestOptions requestOptions = RequestOptions.builder()
                .setStripeAccount(accountId)
                .setApiKey(stripePaymentsProperties.getApiKey())
                .build();

        final Map<String, Object> fileUploadParams = new HashMap<>();
        fileUploadParams.put("purpose", "identity_document");
        fileUploadParams.put("file", legalDocument);

        try {
            final FileUpload fileUpload = FileUpload.create(fileUploadParams, requestOptions);

            return fileUpload.getId();
        } catch (AuthenticationException | InvalidRequestException | CardException | APIException
                | APIConnectionException e) {
            throw new RuntimeException(e);
        }
    }
}
