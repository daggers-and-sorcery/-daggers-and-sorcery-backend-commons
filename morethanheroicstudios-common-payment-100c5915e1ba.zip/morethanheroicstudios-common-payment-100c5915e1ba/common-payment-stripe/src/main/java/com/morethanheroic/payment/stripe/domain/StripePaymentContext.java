package com.morethanheroic.payment.stripe.domain;

import com.morethanheroic.payment.domain.PaymentContext;
import com.morethanheroic.payment.domain.PaymentEntity;
import lombok.Builder;
import lombok.Getter;

/**
 * A {@link PaymentContext} implementation that has Stripe specific attributes.
 */
@Getter
@Builder
public class StripePaymentContext implements PaymentContext {

    /**
     * Contains most of the payment data. Will be persisted to the database.
     */
    private final PaymentEntity paymentEntity;

    /**
     * Contains the identifier of the source of the money (eg a credit card).
     */
    private final String token;

    /**
     * Contains the account's Id that will receive the money. If set to null then the "main" stripe account will get the
     * funds.
     */
    private final String chargingAccount;

    /**
     * Contains any application fee. This parameter only makes sense when the {@link #chargingAccount} is a Stripe
     * Connect account and we want to get a cut from the payment. The cut will be added to our main account.
     *
     * @see <a href="https://stripe.com/docs/connect/direct-charges#collecting-fees">
     * https://stripe.com/docs/connect/direct-charges#collecting-fees</a>
     */
    private final long applicationFee;
}
