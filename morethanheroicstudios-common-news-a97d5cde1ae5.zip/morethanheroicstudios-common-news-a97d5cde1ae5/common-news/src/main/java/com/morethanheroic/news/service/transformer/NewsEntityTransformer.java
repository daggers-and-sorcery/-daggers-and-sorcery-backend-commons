package com.morethanheroic.news.service.transformer;

import com.morethanheroic.news.domain.NewsEntity;
import com.morethanheroic.news.repository.domain.NewsDatabaseEntity;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class NewsEntityTransformer {

    public List<NewsEntity> transform(final List<NewsDatabaseEntity> newsDatabaseEntities) {
        return newsDatabaseEntities.stream()
                .map(newsDatabaseEntity ->
                        NewsEntity.builder()
                                .id(newsDatabaseEntity.getId())
                                .postDate(newsDatabaseEntity.getPostDate())
                                .category(newsDatabaseEntity.getCategory())
                                .title(newsDatabaseEntity.getTitle())
                                .content(newsDatabaseEntity.getContent())
                                .build()
                )
                .collect(Collectors.toList());
    }
}
