package com.morethanheroic.news.domain;

import lombok.Builder;
import lombok.Getter;

import java.time.LocalDate;

@Getter
@Builder
public class NewsEntity {

    private int id;
    private String category;
    private String title;
    private String content;
    private LocalDate postDate;
}
