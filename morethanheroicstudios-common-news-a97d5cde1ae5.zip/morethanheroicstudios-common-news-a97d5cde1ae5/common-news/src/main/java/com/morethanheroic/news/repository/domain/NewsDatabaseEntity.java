package com.morethanheroic.news.repository.domain;

import lombok.Data;

import java.time.LocalDate;

@Data
public class NewsDatabaseEntity {

    private int id;
    private String category;
    private String title;
    private String content;
    private LocalDate postDate;
}
