package com.morethanheroic.news.repository;

import com.morethanheroic.news.repository.domain.NewsDatabaseEntity;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface NewsRepository {

    @Select("SELECT * FROM news ORDER BY post_date DESC LIMIT #{limit}")
    List<NewsDatabaseEntity> getLastNewsEntities(@Param("limit") int limit);
}
