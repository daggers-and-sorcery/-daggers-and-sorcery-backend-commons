package com.morethanheroic.news.service;

import com.morethanheroic.news.domain.NewsEntity;

import java.util.List;

import com.morethanheroic.news.repository.NewsRepository;
import com.morethanheroic.news.repository.domain.NewsDatabaseEntity;
import com.morethanheroic.news.service.transformer.NewsEntityTransformer;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class NewsEntityFactory {

    private static final int DEFAULT_RESULT_LIMIT = 10;

    private final NewsRepository newsRepository;
    private final NewsEntityTransformer newsEntityTransformer;

    /**
     * Return the past 10 news entities.
     *
     * @return the past 10 news entities
     */
    public List<NewsEntity> getNewsEntities() {
        return getNewsEntities(DEFAULT_RESULT_LIMIT);
    }

    /**
     * Return a given amount of the past news entities.
     *
     * @param limit the amount of news entities to return
     * @return the news entities
     */
    public List<NewsEntity> getNewsEntities(final int limit) {
        final List<NewsDatabaseEntity> databaseEntities = newsRepository.getLastNewsEntities(limit);

        return newsEntityTransformer.transform(databaseEntities);
    }
}
