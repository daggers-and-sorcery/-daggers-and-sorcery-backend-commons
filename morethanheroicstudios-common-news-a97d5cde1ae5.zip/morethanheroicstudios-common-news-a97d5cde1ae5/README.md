# Common News

## Changelog

- ***1.0.3***
    - Fixed the type to category changing sql xml.
- ***1.0.2***
    - Renamed type to category in news and also the data type is now String.
- ***1.0.1***
    - Fixed the mysql xml file that creates the news table.
- ***1.0.0***
    - Initial release.