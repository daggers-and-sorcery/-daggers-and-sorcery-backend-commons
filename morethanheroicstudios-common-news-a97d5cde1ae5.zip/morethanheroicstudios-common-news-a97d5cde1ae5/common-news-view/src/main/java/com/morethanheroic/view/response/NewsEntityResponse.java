package com.morethanheroic.view.response;

import lombok.Builder;
import lombok.Getter;

import java.time.LocalDate;

@Getter
@Builder
public class NewsEntityResponse {

    private final int id;
    private final String category;
    private final String title;
    private final String content;
    private final LocalDate postDate;
}
