package com.morethanheroic.view.controller;

import com.morethanheroic.news.service.NewsEntityFactory;
import com.morethanheroic.view.response.NewsEntityResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequiredArgsConstructor
public class NewsController {

    private final NewsEntityFactory newsEntityFactory;

    @GetMapping("/news")
    public List<NewsEntityResponse> listNews() {
        return newsEntityFactory.getNewsEntities().stream()
                .map(newsEntity ->
                        NewsEntityResponse.builder()
                                .id(newsEntity.getId())
                                .category(newsEntity.getCategory())
                                .title(newsEntity.getTitle())
                                .content(newsEntity.getContent())
                                .postDate(newsEntity.getPostDate())
                                .build()
                )
                .collect(Collectors.toList());
    }
}
