package com.morethanheroic.payment.ingenico.configuration;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Data
@Configuration
@ConfigurationProperties("payment.provider.ingenico")
public class IngenicoPaymentProperties {

    /**
     * Contains the psp ID that's available on Ingenico's site after login.
     */
    private String pspId;

    /**
     * This passphrase will be used when calculating the sha-in variable for Ingenico.
     */
    private String shaInPassphrase;
}
