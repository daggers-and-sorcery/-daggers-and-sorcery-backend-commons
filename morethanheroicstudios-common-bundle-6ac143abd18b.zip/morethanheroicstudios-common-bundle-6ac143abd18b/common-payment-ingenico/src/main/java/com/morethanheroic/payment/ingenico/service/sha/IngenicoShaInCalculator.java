package com.morethanheroic.payment.ingenico.service.sha;

import com.morethanheroic.payment.ingenico.configuration.IngenicoPaymentProperties;
import com.morethanheroic.payment.ingenico.service.sha.domain.ShaCalculationInput;
import lombok.RequiredArgsConstructor;
import org.apache.commons.codec.digest.DigestUtils;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class IngenicoShaInCalculator {

    private static final String EQUALS_SIGN = "=";
    private static final String AMOUNT_NAME = "AMOUNT";
    private static final String CURRENCY_NAME = "CURRENCY";
    private static final String LANGUAGE_NAME = "LANGUAGE";
    private static final String ORDERID_NAME = "ORDERID";
    private static final String PSPID_NAME = "PSPID";

    private final IngenicoPaymentProperties ingenicoPaymentProperties;

    /**
     * Calculate the SHA-IN hash for ingenico. More info is available on this link:
     * <a>https://payment-services.ingenico.com/int/en/ogone/support/guides/integration%20guides/e-commerce/security-pre-payment-check#shainsignature</a>
     * <p>
     * It's STRICTLY FORBIDDEN to move lines up or down in this calculation because the attributes should be
     * alphabetically sorted.
     *
     * @param shaCalculationInput the input object containing all the variables used in the calculation
     * @return the result SHA-IN string
     */
    public String calculateShaIn(final ShaCalculationInput shaCalculationInput) {
        final String hexResult = DigestUtils.sha1Hex(
                AMOUNT_NAME + EQUALS_SIGN + shaCalculationInput.getAmount() + ingenicoPaymentProperties.getShaInPassphrase()
                        + CURRENCY_NAME + EQUALS_SIGN + shaCalculationInput.getCurrency() + ingenicoPaymentProperties.getShaInPassphrase()
                        + LANGUAGE_NAME + EQUALS_SIGN + shaCalculationInput.getLanguage() + ingenicoPaymentProperties.getShaInPassphrase()
                        + ORDERID_NAME + EQUALS_SIGN + shaCalculationInput.getOrderId() + ingenicoPaymentProperties.getShaInPassphrase()
                        + PSPID_NAME + EQUALS_SIGN + shaCalculationInput.getPspId() + ingenicoPaymentProperties.getShaInPassphrase()
        );

        return hexResult.toUpperCase();
    }
}
