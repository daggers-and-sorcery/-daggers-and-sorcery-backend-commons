package com.morethanheroic.payment.ingenico.view.controller;

import com.morethanheroic.payment.service.callback.PaymentCallbackHandler;
import com.morethanheroic.payment.service.callback.domain.PaymentCallbackEntity;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
public class IngenicoCallbackController {

    private final PaymentCallbackHandler paymentCallbackHandler;

    @GetMapping("/payment/ingenico/callback")
    public void ingenicoCallback(@RequestParam("orderID") final String paymentId) {
        paymentCallbackHandler.handlePaymentCallback(
                PaymentCallbackEntity.builder()
                        .paymentId(paymentId)
                        .build()
        );
    }
}
