package com.morethanheroic.payment.ingenico.service.sha;

import com.morethanheroic.payment.ingenico.configuration.IngenicoPaymentProperties;
import com.morethanheroic.payment.ingenico.service.sha.IngenicoShaInCalculator;
import com.morethanheroic.payment.ingenico.service.sha.domain.ShaCalculationInput;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.*;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class IngenicoShaInCalculatorTest {

    @Mock
    private IngenicoPaymentProperties ingenicoPaymentProperties;

    @InjectMocks
    private IngenicoShaInCalculator shaInCalculator;

    @Test
    public void calculateShaIn() {
        when(ingenicoPaymentProperties.getShaInPassphrase()).thenReturn("Mysecretsig1875!?");

        final ShaCalculationInput shaCalculationInput =
                ShaCalculationInput.builder()
                        .amount(1500)
                        .currency("EUR")
                        .language("en_US")
                        .orderId("1234")
                        .pspId("MyPSPID")
                        .build();

        assertThat(shaInCalculator.calculateShaIn(shaCalculationInput), is("F4CC376CD7A834D997B91598FA747825A238BE0A"));
    }
}
