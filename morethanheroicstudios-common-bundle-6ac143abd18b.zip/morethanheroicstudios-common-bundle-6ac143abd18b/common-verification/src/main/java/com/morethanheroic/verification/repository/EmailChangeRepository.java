package com.morethanheroic.verification.repository;

import com.morethanheroic.verification.repository.domain.EmailChangeDatabaseEntity;
import org.apache.ibatis.annotations.*;

@Mapper
public interface EmailChangeRepository {

    @Select("SELECT * FROM email_change_verification WHERE id = #{id}")
    EmailChangeDatabaseEntity find(@Param("id") String id);

    @Delete("DELETE FROM email_change_verification WHERE id = #{id}")
    void remove(@Param("id") String id);

    @Insert("INSERT INTO email_change_verification SET id = #{id}, email = #{email}")
    void insert(EmailChangeDatabaseEntity emailChangeDatabaseEntity);
}
