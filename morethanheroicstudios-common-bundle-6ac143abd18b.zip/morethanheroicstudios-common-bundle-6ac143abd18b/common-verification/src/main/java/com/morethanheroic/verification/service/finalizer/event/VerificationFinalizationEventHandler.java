package com.morethanheroic.verification.service.finalizer.event;

import com.morethanheroic.event.EventHandler;
import com.morethanheroic.verification.service.finalizer.event.domain.VerificationFinalizationEventConfiguration;

public abstract class VerificationFinalizationEventHandler implements EventHandler<VerificationFinalizationEventConfiguration> {
}
