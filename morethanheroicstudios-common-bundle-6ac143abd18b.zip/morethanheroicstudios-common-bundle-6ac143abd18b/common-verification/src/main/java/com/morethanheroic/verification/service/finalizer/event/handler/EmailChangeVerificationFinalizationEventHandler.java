package com.morethanheroic.verification.service.finalizer.event.handler;

import com.morethanheroic.user.service.UserIdentifierChecker;
import com.morethanheroic.user.service.UserManipulator;
import com.morethanheroic.verification.repository.EmailChangeRepository;
import com.morethanheroic.verification.repository.domain.EmailChangeDatabaseEntity;
import com.morethanheroic.verification.service.domain.VerificationEntity;
import com.morethanheroic.verification.service.finalizer.event.VerificationFinalizationEventHandler;
import com.morethanheroic.verification.service.finalizer.event.domain.VerificationFinalizationEventConfiguration;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Slf4j
@Service
@Order(10)
@RequiredArgsConstructor
public class EmailChangeVerificationFinalizationEventHandler extends VerificationFinalizationEventHandler {

    private final EmailChangeRepository emailChangeRepository;
    private final UserIdentifierChecker userIdentifierChecker;
    private final UserManipulator userManipulator;

    @Override
    @Transactional
    public void onEvent(VerificationFinalizationEventConfiguration verificationFinalizationEventConfiguration) {
        log.info("User " + verificationFinalizationEventConfiguration.getVerificationEntity().getUser().getId()
                + " verifying his e-mail change address.");

        final VerificationEntity verificationEntity = verificationFinalizationEventConfiguration.getVerificationEntity();

        if (!verificationEntity.isMandatory()) {
            final EmailChangeDatabaseEntity emailChangeDatabaseEntity =
                    emailChangeRepository.find(verificationEntity.getVerificationId());

            if (!userIdentifierChecker.isEmailUsed(emailChangeDatabaseEntity.getEmail())) {
                userManipulator.updateEmail(verificationEntity.getUser(), emailChangeDatabaseEntity.getEmail());
            }

            emailChangeRepository.remove(verificationEntity.getVerificationId());
        }
    }
}
