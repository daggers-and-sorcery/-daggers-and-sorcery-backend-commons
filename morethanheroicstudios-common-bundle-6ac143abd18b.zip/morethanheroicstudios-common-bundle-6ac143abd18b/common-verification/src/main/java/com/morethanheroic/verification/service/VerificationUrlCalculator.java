package com.morethanheroic.verification.service;

import com.morethanheroic.application.configuration.ApplicationProperties;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class VerificationUrlCalculator {

    private final ApplicationProperties applicationProperties;

    @Value("${verification.url-postfix:#!/verification/{id}}")
    private String verificationUrlPostfix;

    public String calculateVerificationUrl(final String verificationId) {
        final String urlPostfix = verificationUrlPostfix.replace("{id}", verificationId);

        return applicationProperties.getWebEndpoint() + urlPostfix;
    }
}
