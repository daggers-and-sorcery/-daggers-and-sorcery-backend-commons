package com.morethanheroic.verification.service.domain;

import com.morethanheroic.user.domain.UserEntity;
import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class VerificationEntity {

    private final UserEntity user;
    private final String verificationId;
    private final String verificationUrl;
    private final boolean mandatory;
}
