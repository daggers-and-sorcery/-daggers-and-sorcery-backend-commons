package com.morethanheroic.verification.repository.domain;

import lombok.Data;

@Data
public class VerificationDatabaseEntity {

    private int userId;
    private String verificationId;
    private boolean mandatory;
}
