package com.morethanheroic.verification.service;

import com.morethanheroic.user.domain.UserEntity;
import com.morethanheroic.verification.service.domain.VerificationEntity;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
@RequiredArgsConstructor
public class VerificationCalculator {

    private final VerificationEntityFactory verificationEntityFactory;

    public boolean isVerified(final UserEntity userEntity) {
        final Optional<VerificationEntity> verificationEntity = verificationEntityFactory.getVerificationEntity(userEntity);

        return !verificationEntity.isPresent() || !verificationEntity.get().isMandatory();
    }
}
