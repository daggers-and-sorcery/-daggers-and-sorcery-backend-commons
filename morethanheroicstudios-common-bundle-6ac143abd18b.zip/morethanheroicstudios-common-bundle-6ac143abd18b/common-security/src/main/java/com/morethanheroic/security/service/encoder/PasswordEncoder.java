package com.morethanheroic.security.service.encoder;

import org.apache.commons.codec.digest.DigestUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class PasswordEncoder {

    @Value("${user.password.salt:''}")
    private String salt;

    public String encodePassword(final String password) {
        return DigestUtils.sha256Hex(password + salt);
    }
}
