package com.morethanheroic.login.service.login;

import com.morethanheroic.login.service.login.event.LoginEventDispatcher;
import com.morethanheroic.login.service.login.event.domain.LoginEventConfiguration;
import com.morethanheroic.login.service.login.domain.LoginEvaluationResult;
import com.morethanheroic.login.service.login.domain.LoginResult;
import com.morethanheroic.login.service.login.domain.entity.LoginEntity;
import com.morethanheroic.login.service.login.user.finder.UserEntityFinderLocator;
import com.morethanheroic.session.domain.SessionEntity;
import com.morethanheroic.user.domain.UserEntity;
import com.morethanheroic.verification.service.VerificationCalculator;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
@RequiredArgsConstructor
public class LoginHandler {

    private final LoginEventDispatcher loginEventDispatcher;
    private final VerificationCalculator verificationCalculator;
    private final UserEntityFinderLocator userEntityFinderLocator;

    public LoginEvaluationResult handleLogin(final SessionEntity sessionEntity, final LoginEntity loginEntity) {
        final Optional<UserEntity> optionalUserEntity = userEntityFinderLocator.find(loginEntity);

        if (!optionalUserEntity.isPresent()) {
            return LoginEvaluationResult.builder()
                    .result(LoginResult.INVALID_CREDENTIALS)
                    .build();
        }

        final UserEntity userEntity = optionalUserEntity.get();

        if (!verificationCalculator.isVerified(userEntity)) {
            return LoginEvaluationResult.builder()
                    .result(LoginResult.UNVERIFIED)
                    .user(userEntity)
                    .build();
        }

        handleSuccessfulLogin(sessionEntity, userEntity);

        return LoginEvaluationResult.builder()
                .result(LoginResult.SUCCESSFUL)
                .user(userEntity)
                .build();
    }

    private void handleSuccessfulLogin(SessionEntity sessionEntity, UserEntity userEntity) {
        loginEventDispatcher.dispatch(
                LoginEventConfiguration.builder()
                        .userEntity(userEntity)
                        .build()
        );

        sessionEntity.setAttribute("USER_ID", userEntity.getId());
    }
}
