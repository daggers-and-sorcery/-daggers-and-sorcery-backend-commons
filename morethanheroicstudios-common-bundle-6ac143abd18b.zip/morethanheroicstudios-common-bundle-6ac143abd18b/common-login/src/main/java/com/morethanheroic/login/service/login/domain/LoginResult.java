package com.morethanheroic.login.service.login.domain;

public enum LoginResult {

    SUCCESSFUL,
    UNVERIFIED,
    INVALID_CREDENTIALS
}
