package com.morethanheroic.login.service.login.user.finder;

import com.morethanheroic.login.service.login.domain.entity.LoginEntity;
import com.morethanheroic.user.domain.UserEntity;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class UserEntityFinderLocator {

    private final Map<Class<? extends LoginEntity>, UserEntityFinder<? extends LoginEntity>> userEntityFinderMap;

    public UserEntityFinderLocator(final List<UserEntityFinder<? extends LoginEntity>> userEntityFinders) {
        userEntityFinderMap = userEntityFinders.stream()
                .collect(Collectors.toMap(UserEntityFinder::finderFor, a -> a));
    }

    @SuppressWarnings("unchecked")
    public <T extends LoginEntity> Optional<UserEntity> find(final T loginEntity) {
        return ((UserEntityFinder<T>) userEntityFinderMap.get(loginEntity.getClass())).find(loginEntity);
    }
}
