package com.morethanheroic.login.service.login.user.finder;

import com.morethanheroic.login.service.login.domain.entity.LoginEntity;
import com.morethanheroic.user.domain.UserEntity;

import java.util.Optional;

/**
 * Finds {@link UserEntity}s for a provided {@link LoginEntity}s. Used in the login process.
 *
 * @param <T> the type of the supported login entity
 */
public interface UserEntityFinder<T extends LoginEntity> {

    /**
     * What type of {@link LoginEntity} this finder supports.
     *
     * @return the type of the supported login entity
     */
    Class<T> finderFor();

    /**
     * Finds and return an user based on the provided {@link LoginEntity}.
     *
     * @param loginEntity the login entity to find the user entity for
     * @return the found user entity or an empty optional
     */
    Optional<UserEntity> find(T loginEntity);
}
