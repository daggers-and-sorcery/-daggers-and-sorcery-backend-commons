package com.morethanheroic.login.service.login.event;

import com.morethanheroic.event.EventDispatcher;
import com.morethanheroic.login.service.login.event.domain.LoginEventConfiguration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;

@Service
public class LoginEventDispatcher implements EventDispatcher<LoginEventConfiguration> {

    private final List<LoginEventHandler> loginEventHandlers;

    public LoginEventDispatcher() {
        loginEventHandlers = Collections.emptyList();
    }

    @Autowired(required = false)
    public LoginEventDispatcher(List<LoginEventHandler> loginEventHandlers) {
        this.loginEventHandlers = loginEventHandlers;
    }

    @Override
    public void dispatch(LoginEventConfiguration loginEventConfiguration) {
        loginEventHandlers.forEach(loginEventHandler -> loginEventHandler.onEvent(loginEventConfiguration));
    }
}
