package com.morethanheroic.login.service.login.user.finder;

import com.morethanheroic.login.service.login.domain.entity.UsernameLoginEntity;
import com.morethanheroic.user.domain.UserEntity;
import com.morethanheroic.user.service.factory.UserEntityFactory;
import com.morethanheroic.user.service.factory.domain.PasswordFactoryRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
@RequiredArgsConstructor
public class UsernameLoginUserEntityFinder implements UserEntityFinder<UsernameLoginEntity> {

    private final UserEntityFactory userEntityFactory;

    @Override
    public Class<UsernameLoginEntity> finderFor() {
        return UsernameLoginEntity.class;
    }

    @Override
    public Optional<UserEntity> find(final UsernameLoginEntity loginEntity) {
        return Optional.ofNullable(
                userEntityFactory.getUserEntity(
                        PasswordFactoryRequest.builder()
                                .username(loginEntity.getUsername())
                                .password(loginEntity.getPassword())
                                .build()
                )
        );
    }
}
