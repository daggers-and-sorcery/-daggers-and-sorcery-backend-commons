package com.morethanheroic.login.service.login.domain.entity;

import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class UsernameLoginEntity implements LoginEntity {

    private String username;
    private String password;
}
