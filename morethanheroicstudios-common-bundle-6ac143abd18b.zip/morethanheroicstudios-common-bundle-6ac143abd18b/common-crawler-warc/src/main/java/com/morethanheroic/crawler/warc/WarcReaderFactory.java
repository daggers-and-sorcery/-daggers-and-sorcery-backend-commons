package com.morethanheroic.crawler.warc;

import com.morethanheroic.crawler.domain.DocumentLocation;
import org.springframework.stereotype.Service;

import java.io.BufferedInputStream;
import java.io.IOException;

@Service
public class WarcReaderFactory {

    public ExtendedWarcReader newReader(final DocumentLocation documentLocation) {
        try {
            return new ExtendedWarcReader(new AvailableInputStream(new BufferedInputStream(
                    documentLocation.getUrl().openStream(), 1048576)));
        } catch (IOException e) {
            throw new RuntimeException("Unable to create WARC reader!", e);
        }
    }
}
