package com.morethanheroic.crawler.warc.service.domain;

import com.mixnode.warcreader.record.WarcRecord;
import lombok.Data;

@Data
public class WarcEntity {

    private WarcRecord warcRecord;
    private String host = "";
    private String uri = "";
}
