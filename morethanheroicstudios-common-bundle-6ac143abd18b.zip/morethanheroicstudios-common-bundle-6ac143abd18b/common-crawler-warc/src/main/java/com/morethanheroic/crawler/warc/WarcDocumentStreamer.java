package com.morethanheroic.crawler.warc;

import com.mixnode.warcreader.WarcReader;
import com.mixnode.warcreader.record.RequestContentBlock;
import com.mixnode.warcreader.record.WarcRecord;
import com.morethanheroic.crawler.domain.DocumentLocation;
import com.morethanheroic.crawler.warc.domain.WarcDocument;
import lombok.RequiredArgsConstructor;
import org.apache.http.HttpResponse;
import org.apache.http.util.EntityUtils;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.charset.IllegalCharsetNameException;
import java.util.Iterator;
import java.util.Spliterator;
import java.util.Spliterators;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

@Service
@RequiredArgsConstructor
public class WarcDocumentStreamer {

    private final WarcReaderFactory warcReaderFactory;

    public Stream<WarcDocument> stream(final DocumentLocation warcFileLocation) {
        final ExtendedWarcReader warcReader = warcReaderFactory.newReader(warcFileLocation);

        final Iterator<WarcDocument> iterator = new Iterator<WarcDocument>() {

            private boolean hasNext = true;

            @Override
            public boolean hasNext() {
                return hasNext;
            }

            @Override
            public WarcDocument next() {
                WarcRecord warcRecord;
                String host = "";
                String uri = "";

                do {
                    warcRecord = readRecord(warcReader);

                    if (warcRecord == null) {
                        continue;
                    }

                    if (warcRecord.getType() == WarcRecord.WarcType.request) {
                        final RequestContentBlock requestContentBlock = (RequestContentBlock) warcRecord.getWarcContentBlock();

                        host = requestContentBlock.getFirstHeader("Host").getElements()[0].getName();
                        uri = requestContentBlock.getRequestLine().getUri();
                    }
                } while (!validRecord(warcRecord));

                if (warcRecord == null) {
                    hasNext = false;

                    warcReader.close();

                    return WarcDocument.builder()
                            .url("")
                            .body("")
                            .build();
                }

                try {
                    return WarcDocument.builder()
                            .url("http://" + host + uri)
                            .body(EntityUtils.toString(((HttpResponse) warcRecord.getWarcContentBlock()).getEntity()))
                            .build();
                } catch (IOException | IllegalCharsetNameException e) {
                    throw new RuntimeException("Unable to parse response body for http://" + host + uri);
                }
            }
        };

        return StreamSupport.stream(Spliterators.spliteratorUnknownSize(
                iterator, Spliterator.ORDERED | Spliterator.NONNULL), false);
    }

    private WarcRecord readRecord(final WarcReader warcReader) {
        try {
            return warcReader.readRecord();
        } catch (IOException e) {
            throw new RuntimeException("Unable to read WARC record!", e);
        }
    }

    private boolean validRecord(final WarcRecord warcRecord) {
        return warcRecord == null || (warcRecord.getType() == WarcRecord.WarcType.response
                && isSupportedContentType(warcRecord));
    }

    private boolean isSupportedContentType(final WarcRecord warcRecord) {
        final HttpResponse httpResponse = (HttpResponse) warcRecord.getWarcContentBlock();
        final String contentType = httpResponse.containsHeader("Content-Type") ?
                httpResponse.getFirstHeader("Content-Type").getValue() : null;

        return contentType != null && contentType.startsWith("text/html");
    }
}
