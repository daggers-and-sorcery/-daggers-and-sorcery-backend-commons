package com.morethanheroic.crawler.warc;

import com.mixnode.warcreader.WarcReader;

import java.io.IOException;
import java.io.InputStream;

public class ExtendedWarcReader extends WarcReader {

    public ExtendedWarcReader(final InputStream compressedStream) throws IOException {
        super(compressedStream);
    }

    public void close() {
        try {
            this.input.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
