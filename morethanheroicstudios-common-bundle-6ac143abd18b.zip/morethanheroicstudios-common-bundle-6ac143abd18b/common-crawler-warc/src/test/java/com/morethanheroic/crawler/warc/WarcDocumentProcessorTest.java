package com.morethanheroic.crawler.warc;

import com.morethanheroic.crawler.configuration.CommonCrawlerConfiguration;
import com.morethanheroic.crawler.domain.DocumentLocation;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.net.MalformedURLException;
import java.net.URL;

@Ignore
@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.NONE, classes = CommonCrawlerConfiguration.class)
public class WarcDocumentProcessorTest {

    @Autowired
    private WarcDocumentProcessor warcDocumentProcessor;


    @Test
    public void testWarcDocumentProcessing() throws MalformedURLException {
        final DocumentLocation documentLocation = DocumentLocation.builder()
                .url(new URL("https://commoncrawl.s3.amazonaws.com/crawl-data/CC-MAIN-2018-43/segments/1539583508988.18/warc/CC-MAIN-20181015080248-20181015101748-00000.warc.gz"))
                .build();

        warcDocumentProcessor.process(documentLocation)
                .forEach(document -> System.out.println(document.getLocation().getUrl()));
    }
}
