package com.morethanheroic.invoice.domain;

import com.morethanheroic.invoice.domain.customer.Customer;
import com.morethanheroic.invoice.domain.item.InvoiceItem;
import lombok.Builder;
import lombok.Getter;

import java.util.Currency;
import java.util.List;
import java.util.Locale;

@Getter
@Builder
public class DefaultInvoice implements Invoice {

    private final String id;
    private final InvoiceType type;
    private final Customer customer;
    private final Currency currency;
    private final Locale language;
    private final List<InvoiceItem> items;
    private final String primaryMessage;
    private final String secondaryMessage;
}
