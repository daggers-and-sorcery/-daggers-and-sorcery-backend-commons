package com.morethanheroic.invoice.domain.item;

import lombok.Builder;
import lombok.Getter;

import java.math.BigDecimal;

@Getter
@Builder
public class DefaultInvoiceItem implements InvoiceItem {

    private final String id;
    private final String name;
    private final String description;
    private final int quantity;
    private final String quantityType;
    private final double tax;
    private final BigDecimal unitPrice;
    private final BigDecimal price;
}
