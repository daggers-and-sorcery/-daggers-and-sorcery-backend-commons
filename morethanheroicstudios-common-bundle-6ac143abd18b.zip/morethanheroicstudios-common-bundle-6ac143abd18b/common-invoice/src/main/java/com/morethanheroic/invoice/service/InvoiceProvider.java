package com.morethanheroic.invoice.service;

import com.morethanheroic.invoice.domain.Invoice;

public interface InvoiceProvider {

    void handleInvoice(Invoice invoice);
}
