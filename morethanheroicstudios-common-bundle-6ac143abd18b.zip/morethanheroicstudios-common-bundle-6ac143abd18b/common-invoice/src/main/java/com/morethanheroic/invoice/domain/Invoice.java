package com.morethanheroic.invoice.domain;

import com.morethanheroic.invoice.domain.customer.Customer;
import com.morethanheroic.invoice.domain.item.InvoiceItem;

import java.util.Currency;
import java.util.List;
import java.util.Locale;

public interface Invoice {

    String getId();

    InvoiceType getType();

    Customer getCustomer();

    Currency getCurrency();

    Locale getLanguage();

    List<InvoiceItem> getItems();

    /**
     * Extra free-text message available on the invoice.
     *
     * @return the primary message
     */
    String getPrimaryMessage();

    /**
     * Extra free-text message available on the invoice.
     *
     * @return the secondary message
     */
    String getSecondaryMessage();
}
