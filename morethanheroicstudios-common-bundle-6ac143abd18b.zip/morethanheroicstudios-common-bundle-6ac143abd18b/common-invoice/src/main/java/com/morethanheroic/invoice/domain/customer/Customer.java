package com.morethanheroic.invoice.domain.customer;

public interface Customer {

    String getName();

    String getDetail();

    String getCity();

    String getAddress();

    String getZip();

    String getCountry();

    String getVatNumber();

    String getContactName();

    String getEmail();
}
