package com.morethanheroic.invoice.domain.item;

import java.math.BigDecimal;

public interface InvoiceItem {

    String getId();
    String getName();
    String getDescription();
    int getQuantity();
    String getQuantityType();
    double getTax();
    BigDecimal getPrice();
}
