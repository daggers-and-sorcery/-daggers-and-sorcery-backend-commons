package com.morethanheroic.response.service.advice;

import com.morethanheroic.response.exception.HttpStatusException;
import com.morethanheroic.response.service.advice.domain.HttpStatusExceptionResponse;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class HttpStatusExceptionHandlerAdvice {

    @ExceptionHandler(HttpStatusException.class)
    public ResponseEntity<HttpStatusExceptionResponse> handleException(final HttpStatusException httpStatusException) {
        return ResponseEntity.status(httpStatusException.getHttpStatus())
                .contentType(MediaType.APPLICATION_JSON)
                .body(
                        HttpStatusExceptionResponse.builder()
                                .error(httpStatusException.getMessage())
                                .build()
                );
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<HttpStatusExceptionResponse> handleException(final Exception exception) {
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .contentType(MediaType.APPLICATION_JSON)
                .body(
                        HttpStatusExceptionResponse.builder()
                                .error(exception.getMessage())
                                .build()
                );
    }
}
