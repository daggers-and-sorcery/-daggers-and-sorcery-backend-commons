package com.morethanheroic.response.service;

@Deprecated
public interface ResponseBuilderConfiguration {
}