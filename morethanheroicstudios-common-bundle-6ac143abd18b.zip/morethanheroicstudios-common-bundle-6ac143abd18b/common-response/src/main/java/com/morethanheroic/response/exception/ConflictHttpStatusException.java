package com.morethanheroic.response.exception;

import org.springframework.http.HttpStatus;

public class ConflictHttpStatusException extends HttpStatusException {

    public ConflictHttpStatusException(final String message) {
        super(HttpStatus.CONFLICT, message);
    }
}
