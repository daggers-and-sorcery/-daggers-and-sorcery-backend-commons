package com.morethanheroic.response.configuration;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("com.morethanheroic.response")
public class ResponseConfiguration {
}
