package com.morethanheroic.response.service;

import com.morethanheroic.response.domain.PartialResponse;

@Deprecated
public interface PartialResponseBuilder<T extends ResponseBuilderConfiguration> {

    PartialResponse build(T responseBuilderConfiguration);
}
