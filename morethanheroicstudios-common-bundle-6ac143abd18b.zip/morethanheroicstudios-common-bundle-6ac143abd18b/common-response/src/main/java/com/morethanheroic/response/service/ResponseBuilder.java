package com.morethanheroic.response.service;

import com.morethanheroic.response.domain.Response;

@Deprecated
public interface ResponseBuilder<T extends ResponseBuilderConfiguration> {

    Response build(T responseBuilderConfiguration);
}