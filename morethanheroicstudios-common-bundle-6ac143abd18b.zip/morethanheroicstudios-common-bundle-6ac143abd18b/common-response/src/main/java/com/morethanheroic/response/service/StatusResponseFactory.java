package com.morethanheroic.response.service;

import com.morethanheroic.response.service.domain.StatusResponse;
import org.springframework.stereotype.Service;

@Service
public class StatusResponseFactory {

    public StatusResponse newSuccessfulResponse() {
        return StatusResponse.builder()
                .successful(true)
                .build();
    }

    public StatusResponse newUnsuccessfulResponse() {
        return StatusResponse.builder()
                .successful(false)
                .build();
    }

    public StatusResponse newUnsuccessfulResponse(final String message) {
        return StatusResponse.builder()
                .successful(false)
                .message(message)
                .build();
    }
}
