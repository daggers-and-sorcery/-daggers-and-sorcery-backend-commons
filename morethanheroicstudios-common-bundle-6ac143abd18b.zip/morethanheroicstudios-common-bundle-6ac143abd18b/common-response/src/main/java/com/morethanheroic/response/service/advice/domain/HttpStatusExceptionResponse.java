package com.morethanheroic.response.service.advice.domain;

import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class HttpStatusExceptionResponse {

    private final String error;
}
