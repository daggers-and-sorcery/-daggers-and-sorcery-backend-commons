package com.morethanheroic.response.exception;

import org.springframework.http.HttpStatus;

public class UnauthorizedHttpStatusException extends HttpStatusException {

    public UnauthorizedHttpStatusException(final String message) {
        super(HttpStatus.UNAUTHORIZED, message);
    }
}
