package com.morethanheroic.payment.service;

import com.morethanheroic.payment.domain.DefaultPaymentEntity;
import com.morethanheroic.payment.domain.PaymentEntity;
import com.morethanheroic.payment.repository.PaymentRepository;
import com.morethanheroic.payment.repository.domain.PaymentDatabaseEntity;
import com.morethanheroic.payment.service.manipulator.persistence.PaymentEntityFactory;
import com.morethanheroic.payment.service.manipulator.persistence.PaymentItemEntityFactory;
import com.morethanheroic.user.service.factory.UserEntityFactory;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Currency;
import java.util.Locale;

@Service
@RequiredArgsConstructor
public class DefaultPaymentEntityFactory implements PaymentEntityFactory {

    private final PaymentRepository paymentRepository;
    private final UserEntityFactory userEntityFactory;
    private final PaymentItemEntityFactory paymentItemEntityFactory;

    @Override
    public PaymentEntity getPaymentEntity(final String paymentId) {
        final PaymentDatabaseEntity paymentDatabaseEntity = paymentRepository.findById(paymentId);

        return DefaultPaymentEntity.builder()
                .id(paymentDatabaseEntity.getId())
                .items(paymentItemEntityFactory.getItemEntities(paymentId))
                .price(paymentDatabaseEntity.getPrice())
                .currency(Currency.getInstance(paymentDatabaseEntity.getCurrency()))
                .locale(new Locale(paymentDatabaseEntity.getLocale()))
                .user(userEntityFactory.getUserEntity(paymentDatabaseEntity.getUserId()))
                .status(paymentDatabaseEntity.getStatus())
                .build();
    }
}
