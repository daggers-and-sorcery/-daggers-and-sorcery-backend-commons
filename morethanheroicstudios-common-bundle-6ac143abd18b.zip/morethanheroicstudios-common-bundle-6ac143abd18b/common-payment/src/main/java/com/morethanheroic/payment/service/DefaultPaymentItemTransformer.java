package com.morethanheroic.payment.service;

import com.morethanheroic.payment.domain.DefaultPaymentItemEntity;
import com.morethanheroic.payment.repository.domain.PaymentItemDatabaseEntity;
import org.springframework.stereotype.Service;

@Service
public class DefaultPaymentItemTransformer {

    public DefaultPaymentItemEntity transform(final PaymentItemDatabaseEntity paymentItemDatabaseEntity) {
        return DefaultPaymentItemEntity.builder()
                .id(paymentItemDatabaseEntity.getId())
                .itemId(paymentItemDatabaseEntity.getItemId())
                .itemType(paymentItemDatabaseEntity.getItemType())
                .name(paymentItemDatabaseEntity.getName())
                .description(paymentItemDatabaseEntity.getDescription())
                .price(paymentItemDatabaseEntity.getPrice())
                .quantity(paymentItemDatabaseEntity.getQuantity())
                .unit(paymentItemDatabaseEntity.getUnit())
                .unitPrice(paymentItemDatabaseEntity.getUnitPrice())
                .build();
    }
}
