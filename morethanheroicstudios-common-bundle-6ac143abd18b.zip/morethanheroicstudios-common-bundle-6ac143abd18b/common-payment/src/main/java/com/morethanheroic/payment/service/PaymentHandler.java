package com.morethanheroic.payment.service;

import com.morethanheroic.payment.domain.PaymentContext;
import com.morethanheroic.payment.domain.result.PaymentResultEntity;
import com.morethanheroic.payment.service.manipulator.PaymentSaver;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.stereotype.Service;

/**
 * This class is responsible for saving the payment to the database and initializing the request to the payment
 * provider.
 */
@Slf4j
@Service
@RequiredArgsConstructor
@ConditionalOnBean(PaymentProcessor.class)
public class PaymentHandler {

    private final PaymentProcessor paymentProcessor;
    private final PaymentSaver paymentSaver;

    public PaymentResultEntity handlePayment(final PaymentContext paymentContext) {
        log.info("Initializing paymentEntity: " + paymentContext.getPaymentEntity());

        paymentSaver.save(paymentContext.getPaymentEntity());

        final PaymentResultEntity result = paymentProcessor.processPayment(paymentContext);

        log.info("Finished paymentEntity: " + paymentContext.getPaymentEntity() + " with result: " + result);

        return result;
    }
}
