package com.morethanheroic.payment.service;

import com.morethanheroic.payment.domain.DefaultPaymentItemEntity;
import com.morethanheroic.payment.domain.PaymentItemEntity;
import com.morethanheroic.payment.repository.PaymentItemRepository;
import com.morethanheroic.payment.service.manipulator.persistence.PaymentItemEntityFactory;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class DefaultPaymentItemEntityFactory implements PaymentItemEntityFactory {

    private final DefaultPaymentItemTransformer ingenicoPaymentItemTransformer;
    private final PaymentItemRepository paymentItemRepository;

    @Override
    public List<DefaultPaymentItemEntity> getItemEntities(String paymentId) {
        return paymentItemRepository.findItemsByPaymentId(paymentId).stream()
                .map(ingenicoPaymentItemTransformer::transform)
                .collect(Collectors.toList());
    }

    @Override
    public PaymentItemEntity getItemEntity(String paymentId, int paymentItemId) {
        return ingenicoPaymentItemTransformer.transform(paymentItemRepository.findItem(paymentId, paymentItemId));
    }
}
