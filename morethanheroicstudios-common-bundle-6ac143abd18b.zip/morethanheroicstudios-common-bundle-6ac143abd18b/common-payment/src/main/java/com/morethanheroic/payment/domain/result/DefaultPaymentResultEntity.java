package com.morethanheroic.payment.domain.result;

import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class DefaultPaymentResultEntity implements PaymentResultEntity {

    private final PaymentResult result;
}
