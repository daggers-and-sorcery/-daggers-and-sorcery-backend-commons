package com.morethanheroic.payment.repository.domain;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class PaymentItemDatabaseEntity {

    private int id;
    private String paymentId;
    private String itemId;
    private String itemType;
    private String name;
    private String description;
    private int quantity;
    private String unit;
    private BigDecimal unitPrice;
    private BigDecimal price;
}
