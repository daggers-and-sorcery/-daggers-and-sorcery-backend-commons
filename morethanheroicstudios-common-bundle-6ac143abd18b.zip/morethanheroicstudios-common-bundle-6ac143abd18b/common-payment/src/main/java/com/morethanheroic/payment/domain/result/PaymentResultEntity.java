package com.morethanheroic.payment.domain.result;

public interface PaymentResultEntity {

    PaymentResult getResult();
}
