package com.morethanheroic.payment.service.manipulator.persistence;

import com.morethanheroic.payment.domain.PaymentEntity;

public interface PaymentEntityFactory {

    PaymentEntity getPaymentEntity(String id);
}
