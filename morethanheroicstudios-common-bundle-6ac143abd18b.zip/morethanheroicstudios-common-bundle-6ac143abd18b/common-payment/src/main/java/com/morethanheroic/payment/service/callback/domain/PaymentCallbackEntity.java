package com.morethanheroic.payment.service.callback.domain;

import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class PaymentCallbackEntity {

    private final String paymentId;
}
