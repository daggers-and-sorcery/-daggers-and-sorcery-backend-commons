package com.morethanheroic.payment.domain.result;

public enum PaymentResult {

    SUCCESSFUL,
    UNSUCCESSFUL
}
