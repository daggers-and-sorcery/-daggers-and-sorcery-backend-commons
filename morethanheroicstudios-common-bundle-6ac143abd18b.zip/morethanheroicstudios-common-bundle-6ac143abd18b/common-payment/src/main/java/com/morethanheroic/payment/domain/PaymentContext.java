package com.morethanheroic.payment.domain;

public interface PaymentContext {

    PaymentEntity getPaymentEntity();
}
