package com.morethanheroic.payment.service.manipulator.persistence;

import com.morethanheroic.payment.domain.PaymentEntity;

/**
 * This class is used to do something extra when a {@link PaymentEntity} is inserted into the database.
 */
public interface PaymentInsertExtender<T extends PaymentEntity> {

    void insert(T paymentEntity);
}
