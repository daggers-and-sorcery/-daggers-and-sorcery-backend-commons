package com.morethanheroic.payment.service.manipulator;

import com.morethanheroic.payment.domain.PaymentEntity;
import com.morethanheroic.payment.domain.PaymentStatus;
import com.morethanheroic.payment.repository.PaymentRepository;
import com.morethanheroic.payment.service.manipulator.persistence.PaymentEntityFactory;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

/**
 * This class is responsible for manipulating the payment related entities in the database.
 */
@Service
@RequiredArgsConstructor
public class PaymentManipulator {

    private final PaymentRepository paymentRepository;
    private final PaymentEntityFactory paymentEntityFactory;

    /**
     * Reconstruct a payment entity from the database based on its id.
     *
     * @param paymentId the id of the payment to reconstruct
     * @return the reconstructed payment
     */
    public PaymentEntity find(final String paymentId) {
        return paymentEntityFactory.getPaymentEntity(paymentId);
    }

    /**
     * Update the status of a payment.
     *
     * @param paymentId the id of the payment
     * @param paymentStatus the new status of the payment
     */
    public void updateStatus(final String paymentId, final PaymentStatus paymentStatus) {
        paymentRepository.updateStatus(paymentId, paymentStatus);
    }
}
