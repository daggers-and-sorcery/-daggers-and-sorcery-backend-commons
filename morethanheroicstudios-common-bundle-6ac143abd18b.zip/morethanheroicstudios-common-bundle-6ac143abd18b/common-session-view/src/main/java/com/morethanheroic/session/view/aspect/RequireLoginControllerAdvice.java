package com.morethanheroic.session.view.aspect;

import com.morethanheroic.response.service.StatusResponseFactory;
import com.morethanheroic.response.service.domain.StatusResponse;
import com.morethanheroic.session.aspect.domain.UnauthorizedException;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@Component
@ControllerAdvice
@RequiredArgsConstructor
public class RequireLoginControllerAdvice {

    private final StatusResponseFactory statusResponseFactory;

    @ExceptionHandler(UnauthorizedException.class)
    public ResponseEntity<StatusResponse> handleUnauthorizedException() {
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                .body(statusResponseFactory.newUnsuccessfulResponse("Unauthorized user! Please login to use this endpoint!"));
    }
}
