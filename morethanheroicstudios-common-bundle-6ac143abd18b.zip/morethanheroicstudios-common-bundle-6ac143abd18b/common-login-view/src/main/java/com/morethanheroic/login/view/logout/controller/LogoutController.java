package com.morethanheroic.login.view.logout.controller;

import com.morethanheroic.login.service.logout.LogoutHandler;
import com.morethanheroic.login.view.logout.response.domain.LogoutResponse;
import com.morethanheroic.session.domain.SessionEntity;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
public class LogoutController {

    private final LogoutHandler logoutHandler;

    @GetMapping("/user/logout")
    public LogoutResponse logout(final SessionEntity sessionEntity) {
        logoutHandler.handleRequest(sessionEntity);

        return LogoutResponse.builder()
                .successful(true)
                .build();
    }
}
