package com.morethanheroic.login.view.info.response.domain;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.morethanheroic.login.view.login.generic.response.domain.LoginUserResponse;
import lombok.Builder;
import lombok.Getter;

import java.util.Map;
import java.util.Optional;

@Getter
@Builder
public class LoginInfoResponse {

    private final boolean loggedIn;
    private final LoginUserResponse user;
    private final Map<String, Object> extended;

    @JsonInclude(JsonInclude.Include.NON_ABSENT)
    public Optional<LoginUserResponse> getUser() {
        return Optional.ofNullable(user);
    }

    @JsonInclude(JsonInclude.Include.NON_ABSENT)
    public Optional<Map<String, Object>> getExtended() {
        return Optional.ofNullable(extended);
    }
}
