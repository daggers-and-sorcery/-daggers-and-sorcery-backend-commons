package com.morethanheroic.login.view.login.generic.response.domain;

import lombok.Builder;
import lombok.Getter;

import java.util.Set;

@Getter
@Builder
public class LoginUserResponse {

    private final Set<String> roles;
}
