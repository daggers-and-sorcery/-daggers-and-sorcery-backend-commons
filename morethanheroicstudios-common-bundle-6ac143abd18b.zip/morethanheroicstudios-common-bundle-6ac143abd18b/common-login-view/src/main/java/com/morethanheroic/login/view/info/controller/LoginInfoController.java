package com.morethanheroic.login.view.info.controller;

import com.morethanheroic.login.view.info.response.LoginInfoResponseFactory;
import com.morethanheroic.login.view.info.response.domain.LoginInfoResponse;
import com.morethanheroic.user.domain.UserEntity;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
public class LoginInfoController {

    private final LoginInfoResponseFactory loginInfoResponseFactory;

    @GetMapping("/user/info")
    public LoginInfoResponse info(final UserEntity userEntity) {
        return loginInfoResponseFactory.newLoginInfo(userEntity);
    }
}
