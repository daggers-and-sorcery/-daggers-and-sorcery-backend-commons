package com.morethanheroic.login.view.login.username.request.domain;

import lombok.Data;

@Data
public class UsernameBasedLoginRequest {

    private String username;
    private String password;
}
