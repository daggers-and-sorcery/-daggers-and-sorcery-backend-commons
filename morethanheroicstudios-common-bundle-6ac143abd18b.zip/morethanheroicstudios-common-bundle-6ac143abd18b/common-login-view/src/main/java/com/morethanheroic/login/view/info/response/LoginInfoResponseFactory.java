package com.morethanheroic.login.view.info.response;

import com.morethanheroic.login.view.info.response.domain.LoginInfoResponse;
import com.morethanheroic.login.view.info.service.extender.InfoEndpointExtender;
import com.morethanheroic.login.view.info.service.extender.domain.InfoExtensionResult;
import com.morethanheroic.login.view.login.generic.response.LoginUserResponseFactory;
import com.morethanheroic.user.domain.UserEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class LoginInfoResponseFactory {

    private final LoginUserResponseFactory loginUserResponseFactory;
    private final List<InfoEndpointExtender> infoEndpointExtenders;

    public LoginInfoResponseFactory(final LoginUserResponseFactory loginUserResponseFactory,
                                    @Autowired(required = false) final List<InfoEndpointExtender> infoEndpointExtenders) {
        this.loginUserResponseFactory = loginUserResponseFactory;

        if (infoEndpointExtenders != null) {
            this.infoEndpointExtenders = infoEndpointExtenders;
        } else {
            this.infoEndpointExtenders = Collections.emptyList();
        }
    }

    public LoginInfoResponse newLoginInfo(final UserEntity userEntity) {
        final Map<String, Object> extendedValues = infoEndpointExtenders.stream()
                .map(infoEndpointExtender -> infoEndpointExtender.extendInfo(userEntity))
                .filter(Optional::isPresent)
                .map(Optional::get)
                .collect(Collectors.toMap(InfoExtensionResult::getExtensionName, InfoExtensionResult::getExtensionData));

        return LoginInfoResponse.builder()
                .loggedIn(userEntity != null)
                .user(loginUserResponseFactory.newLoginUserResponse(userEntity))
                .extended(extendedValues.isEmpty() ? null : extendedValues)
                .build();
    }
}
