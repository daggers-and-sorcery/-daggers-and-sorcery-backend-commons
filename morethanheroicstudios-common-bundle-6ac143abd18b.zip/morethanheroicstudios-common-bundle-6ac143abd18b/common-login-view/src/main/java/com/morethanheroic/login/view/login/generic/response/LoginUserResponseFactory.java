package com.morethanheroic.login.view.login.generic.response;

import com.morethanheroic.login.view.login.generic.response.domain.LoginUserResponse;
import com.morethanheroic.user.domain.UserEntity;
import com.morethanheroic.user.domain.authorization.Role;
import org.springframework.stereotype.Service;

import java.util.Set;
import java.util.stream.Collectors;

@Service
public class LoginUserResponseFactory {

    public LoginUserResponse newLoginUserResponse(final UserEntity userEntity) {
        if (userEntity == null) {
            return null;
        }

        return LoginUserResponse.builder()
                .roles(buildRoles(userEntity))
                .build();
    }

    private Set<String> buildRoles(final UserEntity userEntity) {
        return userEntity.getRoles().stream()
                .map(Role::getId)
                .collect(Collectors.toSet());
    }
}
