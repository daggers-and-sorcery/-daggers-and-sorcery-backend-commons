package com.morethanheroic.login.view.info.service.extender.domain;

import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class DefaultInfoExtensionResult implements InfoExtensionResult<Object> {

    private final Object extensionData;
    private final String extensionName;
}
