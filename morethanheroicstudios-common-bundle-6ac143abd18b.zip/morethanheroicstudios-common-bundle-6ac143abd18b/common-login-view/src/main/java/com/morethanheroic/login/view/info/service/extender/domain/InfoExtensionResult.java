package com.morethanheroic.login.view.info.service.extender.domain;

public interface InfoExtensionResult<T> {

    String getExtensionName();

    T getExtensionData();
}
