package com.morethanheroic.login.view.login.generic.response;

import com.morethanheroic.login.service.login.domain.LoginEvaluationResult;
import com.morethanheroic.login.view.login.generic.response.domain.LoginResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class LoginResponseFactory {

    private final LoginUserResponseFactory loginUserResponseFactory;

    public LoginResponse newLoginResponse(final LoginEvaluationResult loginEvaluationResult) {
        return LoginResponse.builder()
                .result(loginEvaluationResult.getResult())
                .user(loginUserResponseFactory.newLoginUserResponse(loginEvaluationResult.getUser().orElse(null)))
                .build();
    }
}
