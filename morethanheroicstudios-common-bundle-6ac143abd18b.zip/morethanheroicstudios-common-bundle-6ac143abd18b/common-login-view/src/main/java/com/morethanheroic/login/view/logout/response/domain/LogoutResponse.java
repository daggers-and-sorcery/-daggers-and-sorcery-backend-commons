package com.morethanheroic.login.view.logout.response.domain;

import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class LogoutResponse {

    private final boolean successful;
}
