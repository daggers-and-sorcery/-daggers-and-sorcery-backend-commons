package com.morethanheroic.login.view.login.email.controller;

import com.morethanheroic.login.service.login.LoginHandler;
import com.morethanheroic.login.service.login.domain.LoginEvaluationResult;
import com.morethanheroic.login.service.login.domain.entity.EmailLoginEntity;
import com.morethanheroic.login.view.login.email.request.domain.EmailBasedLoginRequest;
import com.morethanheroic.login.view.login.generic.response.LoginResponseFactory;
import com.morethanheroic.login.view.login.generic.response.domain.LoginResponse;
import com.morethanheroic.session.domain.SessionEntity;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
@ConditionalOnProperty(name = "login.email-based-login.enabled", havingValue = "true")
public class EmailBasedLoginController {

    private final LoginHandler loginHandler;
    private final LoginResponseFactory loginResponseFactory;

    @PostMapping("/user/login-by-email")
    public LoginResponse login(@RequestBody final EmailBasedLoginRequest loginRequest, final SessionEntity sessionEntity) {
        final LoginEvaluationResult loginEvaluationResult = loginHandler.handleLogin(sessionEntity,
                EmailLoginEntity.builder()
                        .email(loginRequest.getEmail())
                        .password(loginRequest.getPassword())
                        .build()
        );

        return loginResponseFactory.newLoginResponse(loginEvaluationResult);
    }
}
