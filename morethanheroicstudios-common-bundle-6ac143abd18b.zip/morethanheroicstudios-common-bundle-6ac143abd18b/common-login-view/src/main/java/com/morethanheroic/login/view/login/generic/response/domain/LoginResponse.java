package com.morethanheroic.login.view.login.generic.response.domain;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.morethanheroic.login.service.login.domain.LoginResult;
import lombok.Builder;
import lombok.Getter;

import java.util.Optional;

@Getter
@Builder
public class LoginResponse {

    private final LoginResult result;
    private final LoginUserResponse user;

    @JsonInclude(JsonInclude.Include.NON_ABSENT)
    public Optional<LoginUserResponse> getUser() {
        return Optional.ofNullable(user);
    }
}
