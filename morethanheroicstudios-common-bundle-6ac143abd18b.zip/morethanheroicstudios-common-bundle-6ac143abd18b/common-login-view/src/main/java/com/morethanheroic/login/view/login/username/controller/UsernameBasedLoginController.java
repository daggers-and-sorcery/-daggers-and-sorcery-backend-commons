package com.morethanheroic.login.view.login.username.controller;

import com.morethanheroic.login.service.login.LoginHandler;
import com.morethanheroic.login.service.login.domain.LoginEvaluationResult;
import com.morethanheroic.login.service.login.domain.entity.UsernameLoginEntity;
import com.morethanheroic.login.view.login.generic.response.LoginResponseFactory;
import com.morethanheroic.login.view.login.generic.response.domain.LoginResponse;
import com.morethanheroic.login.view.login.username.request.domain.UsernameBasedLoginRequest;
import com.morethanheroic.session.domain.SessionEntity;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

/**
 * A login controller endpoint that provides
 */
@RestController
@RequiredArgsConstructor
@ConditionalOnProperty(name = "login.username-based-login.enabled", havingValue = "true", matchIfMissing = true)
public class UsernameBasedLoginController {

    private final LoginHandler loginHandler;
    private final LoginResponseFactory loginResponseFactory;

    @PostMapping("/user/login-by-username")
    public LoginResponse login(@RequestBody final UsernameBasedLoginRequest loginRequest, final SessionEntity sessionEntity) {
        final LoginEvaluationResult loginEvaluationResult = loginHandler.handleLogin(sessionEntity,
                UsernameLoginEntity.builder()
                        .username(loginRequest.getUsername())
                        .password(loginRequest.getPassword())
                        .build()
        );

        return loginResponseFactory.newLoginResponse(loginEvaluationResult);
    }
}
