package com.morethanheroic.login.view.info.service.extender;

import com.morethanheroic.login.view.info.service.extender.domain.InfoExtensionResult;
import com.morethanheroic.user.domain.UserEntity;

import java.util.Optional;

public interface InfoEndpointExtender {

    Optional<InfoExtensionResult> extendInfo(UserEntity userEntity);
}
