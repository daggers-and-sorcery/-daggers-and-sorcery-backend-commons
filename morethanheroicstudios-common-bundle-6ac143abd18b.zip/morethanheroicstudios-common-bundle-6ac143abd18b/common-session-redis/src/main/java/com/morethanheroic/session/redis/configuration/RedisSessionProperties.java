package com.morethanheroic.session.redis.configuration;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Data
@Component
@ConfigurationProperties("session.provider.redis")
public class RedisSessionProperties {

    private String hostName;
    private int port;
    private String password;
}
