package com.morethanheroic.payment.barion.service.domain;

import com.morethanheroic.payment.domain.PaymentItemEntity;
import lombok.Builder;
import lombok.Getter;

import java.math.BigDecimal;

@Getter
@Builder
public class BarionPaymentItemEntity implements PaymentItemEntity {

    private final int id;
    private final String itemId;
    private final String itemType;
    private final String name;
    private final String description;
    private final int quantity;
    private final String unit;
    private final BigDecimal unitPrice;
    private final BigDecimal price;
}
