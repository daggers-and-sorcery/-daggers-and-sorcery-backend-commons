package com.morethanheroic.payment.barion.service.domain;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public enum BarionFundingSource {

    ALL("All"),
    BALANCE("Balance");

    private final String foundingSourceName;
}
