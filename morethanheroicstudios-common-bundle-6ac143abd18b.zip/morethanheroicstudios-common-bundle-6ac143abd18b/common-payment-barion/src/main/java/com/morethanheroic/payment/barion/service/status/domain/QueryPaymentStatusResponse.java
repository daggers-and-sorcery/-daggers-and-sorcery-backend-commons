package com.morethanheroic.payment.barion.service.status.domain;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.ToString;

import java.util.List;

@Data
@ToString
public class QueryPaymentStatusResponse {

    @JsonProperty(value = "Status", required = true)
    private String status;

    @JsonProperty("Errors")
    private List<QueryPaymentStatusErrorResponse> errors;
}
