package com.morethanheroic.payment.barion.service.manipulator.persistence;

import com.morethanheroic.payment.barion.repository.BarionPaymentRepository;
import com.morethanheroic.payment.barion.repository.domain.BarionPaymentDatabaseEntity;
import com.morethanheroic.payment.barion.service.domain.BarionPaymentEntity;
import com.morethanheroic.payment.service.manipulator.persistence.PaymentInsertExtender;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class BarionPaymentInsertExtender implements PaymentInsertExtender<BarionPaymentEntity> {

    private final BarionPaymentRepository barionPaymentRepository;

    @Override
    public void insert(BarionPaymentEntity paymentEntity) {
        final BarionPaymentDatabaseEntity barionPaymentDatabaseEntity = new BarionPaymentDatabaseEntity();

        barionPaymentDatabaseEntity.setId(paymentEntity.getId());
        barionPaymentDatabaseEntity.setPaymentType(paymentEntity.getPaymentType());

        barionPaymentRepository.insert(barionPaymentDatabaseEntity);
    }
}
