package com.morethanheroic.payment.barion.service.manipulator.persistence;

import com.morethanheroic.payment.domain.PaymentEntity;
import com.morethanheroic.payment.barion.repository.BarionPaymentRepository;
import com.morethanheroic.payment.repository.PaymentRepository;
import com.morethanheroic.payment.barion.repository.domain.BarionPaymentDatabaseEntity;
import com.morethanheroic.payment.repository.domain.PaymentDatabaseEntity;
import com.morethanheroic.payment.barion.service.domain.BarionPaymentEntity;
import com.morethanheroic.payment.service.manipulator.persistence.PaymentEntityFactory;
import com.morethanheroic.user.service.factory.UserEntityFactory;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

import java.util.Currency;
import java.util.Locale;

@Service
@Primary
@RequiredArgsConstructor
public class BarionPaymentEntityFactory implements PaymentEntityFactory {

    private final PaymentRepository paymentRepository;
    private final BarionPaymentRepository barionPaymentRepository;
    private final UserEntityFactory userEntityFactory;
    private final BarionPaymentItemEntityFactory barionPaymentItemEntityFactory;

    @Override
    public PaymentEntity getPaymentEntity(final String paymentId) {
        final PaymentDatabaseEntity paymentDatabaseEntity = paymentRepository.findById(paymentId);
        final BarionPaymentDatabaseEntity barionPaymentDatabaseEntity = barionPaymentRepository.findById(paymentId);

        return BarionPaymentEntity.builder()
                .id(paymentDatabaseEntity.getId())
                .providerId(paymentDatabaseEntity.getProviderId())
                .user(userEntityFactory.getUserEntity(paymentDatabaseEntity.getUserId()))
                .status(paymentDatabaseEntity.getStatus())
                .locale(new Locale(paymentDatabaseEntity.getLocale()))
                .currency(Currency.getInstance(paymentDatabaseEntity.getCurrency()))
                .price(paymentDatabaseEntity.getPrice())
                .items(barionPaymentItemEntityFactory.getItemEntities(paymentId))
                .paymentType(barionPaymentDatabaseEntity.getPaymentType())
                .build();
    }
}
