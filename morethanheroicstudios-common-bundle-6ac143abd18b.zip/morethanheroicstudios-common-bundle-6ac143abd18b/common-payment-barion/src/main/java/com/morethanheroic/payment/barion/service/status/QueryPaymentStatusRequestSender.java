package com.morethanheroic.payment.barion.service.status;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.morethanheroic.payment.domain.PaymentEntity;
import com.morethanheroic.payment.barion.service.status.domain.QueryPaymentStatusResponse;
import lombok.RequiredArgsConstructor;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.client.methods.RequestBuilder;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.IOException;

@Service
@RequiredArgsConstructor
public class QueryPaymentStatusRequestSender {

    private final ObjectMapper objectMapper;

    @Value("${payment.provider.barion.api-url}")
    private String barionApiUrl;

    @Value("${payment.provider.barion.pos-key}")
    private String barionPosKey;

    public QueryPaymentStatusResponse sendQueryStatusRequest(final PaymentEntity paymentEntity) {
        final HttpClient httpClient = HttpClientBuilder.create()
                .build();

        final HttpUriRequest httpRequest = RequestBuilder.get(barionApiUrl
                + "/v2/Payment/GetPaymentState?POSKey=" + barionPosKey + "&PaymentId=" + paymentEntity.getProviderId())
                .build();

        try {
            final HttpResponse httpResponse = httpClient.execute(httpRequest);
            final String responseData = EntityUtils.toString(httpResponse.getEntity());

            return objectMapper.readValue(responseData, QueryPaymentStatusResponse.class);
        } catch (IOException e) {
            throw new RuntimeException("Unable to handle payment state change!", e);
        }
    }
}
