package com.morethanheroic.payment.barion.service.status.domain;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class QueryPaymentStatusErrorResponse {

    @JsonProperty("ErrorCode")
    private String errorCode;

    @JsonProperty("Title")
    private String title;

    @JsonProperty("Description")
    private String description;
}
