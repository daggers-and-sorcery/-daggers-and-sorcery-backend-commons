package com.morethanheroic.payment.barion.service.domain;

import com.morethanheroic.payment.domain.result.PaymentResult;
import com.morethanheroic.payment.domain.result.PaymentResultEntity;
import lombok.Builder;
import lombok.Getter;
import lombok.ToString;

import java.util.Optional;

@Getter
@Builder
@ToString
public class BarionPaymentResultEntity implements PaymentResultEntity {

    private final PaymentResult result;
    private final String redirectUrl;

    public Optional<String> getRedirectUrl() {
        return Optional.ofNullable(redirectUrl);
    }
}
