package com.morethanheroic.payment.barion.service;

import com.morethanheroic.payment.barion.repository.BarionPaymentRepository;
import com.morethanheroic.payment.barion.service.configuration.TestBarionPaymentConfiguration;
import com.morethanheroic.payment.barion.service.domain.*;
import com.morethanheroic.payment.domain.PaymentStatus;
import com.morethanheroic.payment.domain.result.PaymentResult;
import com.morethanheroic.payment.repository.PaymentItemRepository;
import com.morethanheroic.payment.repository.PaymentRepository;
import com.morethanheroic.payment.service.PaymentUniqueIdFactory;
import com.morethanheroic.user.domain.UserEntity;
import com.morethanheroic.user.service.factory.UserEntityFactory;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.Currency;
import java.util.Locale;

import static com.github.npathai.hamcrestopt.OptionalMatchers.isPresent;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.isEmptyString;

@SpringBootTest
@RunWith(SpringRunner.class)
@ActiveProfiles("barion-payment-integration-test")
@ContextConfiguration(classes = {TestBarionPaymentConfiguration.class})
public class BarionPaymentProcessorIntegrationTest {

    @MockBean
    private PaymentRepository paymentRepository;

    @MockBean
    private PaymentItemRepository paymentItemRepository;

    @MockBean
    private BarionPaymentRepository barionPaymentRepository;

    @MockBean
    private UserEntityFactory userEntityFactory;

    @Autowired
    private PaymentUniqueIdFactory paymentUniqueIdFactory;

    @Autowired
    private BarionPaymentProcessor barionPaymentProcessor;

    @Test
    public void testIntegrationWithBarion() {
        final BarionPaymentResultEntity paymentResult = barionPaymentProcessor.processPayment(
                BarionPaymentContext.builder()
                        .paymentEntity(
                                BarionPaymentEntity.builder()
                                        .id(paymentUniqueIdFactory.newUniquePaymentId())
                                        .price(new BigDecimal("123.00"))
                                        .currency(Currency.getInstance("HUF"))
                                        .locale(new Locale("hu", "HU"))
                                        .paymentType(BarionPaymentType.IMMEDIATE)
                                        .status(PaymentStatus.INITIATED)
                                        .user(new UserEntity(123, "Test", "xyz", "test@mail.com",
                                                true, Collections.emptySet()))
                                        .items(
                                                Collections.singletonList(
                                                        BarionPaymentItemEntity.builder()
                                                                .itemId("testitem-id")
                                                                .name("Test item")
                                                                .description("Test item description.")
                                                                .quantity(1)
                                                                .unit("db")
                                                                .unitPrice(new BigDecimal(123))
                                                                .price(new BigDecimal(123))
                                                                .build()
                                                )
                                        )
                                        .build()
                        )
                        .build()
        );

        assertThat(paymentResult.getResult(), is(PaymentResult.SUCCESSFUL));
        assertThat(paymentResult.getRedirectUrl(), isPresent());
        assertThat(paymentResult.getRedirectUrl().get(), not(isEmptyString()));
    }
}