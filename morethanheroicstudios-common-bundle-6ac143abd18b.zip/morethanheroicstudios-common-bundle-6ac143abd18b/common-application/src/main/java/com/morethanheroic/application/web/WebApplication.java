package com.morethanheroic.application.web;

import com.morethanheroic.application.configuration.CorsProperties;
import com.morethanheroic.application.configuration.ResourcesProperties;
import com.morethanheroic.dependencyinjection.resolver.HandlerMethodArgumentResolverRegistrationBean;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.method.support.HandlerMethodArgumentResolver;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import java.util.List;

@Slf4j
@Configuration
@RequiredArgsConstructor
public class WebApplication implements WebMvcConfigurer {

    private final List<HandlerMethodArgumentResolverRegistrationBean> handlerMethodArgumentResolverRegistrationBeans;
    private final CorsProperties corsProperties;
    private final ResourcesProperties resourcesProperties;

    @Override
    public void addArgumentResolvers(final List<HandlerMethodArgumentResolver> argumentResolvers) {
        handlerMethodArgumentResolverRegistrationBeans
                .forEach(
                        handlerMethodArgumentResolverRegistrationBean -> {
                            log.info("Register HandlerMethodArgumentResolver: "
                                    + handlerMethodArgumentResolverRegistrationBean.getHandlerMethodArgumentResolver().getClass());

                            argumentResolvers.add(handlerMethodArgumentResolverRegistrationBean.getHandlerMethodArgumentResolver());
                        }
                );
    }

    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/**")
                .allowedMethods(corsProperties.getAllowedMethods())
                .allowedOrigins(corsProperties.getAllowedOrigins())
                .allowedHeaders(corsProperties.getAllowedHeaders())
                .exposedHeaders(corsProperties.getExposedHeaders())
                .allowCredentials(corsProperties.isAllowCredentials());
    }

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        if (resourcesProperties.getPathPatterns() != null) {
            registry.addResourceHandler(resourcesProperties.getPathPatterns())
                    .setCachePeriod(resourcesProperties.getCachePeriod());
        }
    }
}
