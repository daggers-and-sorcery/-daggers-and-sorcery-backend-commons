package com.morethanheroic.dependencyinjection.resolver;

import org.springframework.web.method.support.HandlerMethodArgumentResolver;

public class HandlerMethodArgumentResolverRegistrationBean {

    private final HandlerMethodArgumentResolver handlerMethodArgumentResolver;

    public HandlerMethodArgumentResolverRegistrationBean(HandlerMethodArgumentResolver handlerMethodArgumentResolver) {
        this.handlerMethodArgumentResolver = handlerMethodArgumentResolver;
    }

    public HandlerMethodArgumentResolver getHandlerMethodArgumentResolver() {
        return handlerMethodArgumentResolver;
    }
}