package com.morethanheroic.login.kongregate.service;

import com.morethanheroic.login.kongregate.service.domain.entity.KongregateLoginEntity;
import com.morethanheroic.login.service.login.domain.LoginEvaluationResult;
import com.morethanheroic.login.service.login.domain.LoginResult;
import com.morethanheroic.login.service.login.event.LoginEventDispatcher;
import com.morethanheroic.login.service.login.event.domain.LoginEventConfiguration;
import com.morethanheroic.login.service.login.user.finder.UserEntityFinderLocator;
import com.morethanheroic.session.domain.SessionEntity;
import com.morethanheroic.user.domain.UserEntity;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Slf4j
@Service
@RequiredArgsConstructor
public class KongregateLoginHandler {

    private final UserEntityFinderLocator userFinderLocator;
    private final LoginEventDispatcher loginEventDispatcher;

    public LoginEvaluationResult handleLogin(final SessionEntity sessionEntity, final KongregateLoginEntity kongregateLoginEntity) {
        log.info("Initializing login for user: " + kongregateLoginEntity.getUserId());

        final Optional<UserEntity> optionalUserEntity = userFinderLocator.find(kongregateLoginEntity);

        if (!optionalUserEntity.isPresent()) {
            throw new RuntimeException("Unable to register kongregate user with userId: "
                    + kongregateLoginEntity.getUserId() + " and authentication token: "
                    + kongregateLoginEntity.getAuthenticationToken());
        }

        final UserEntity userEntity = optionalUserEntity.get();

        // Dispatch the login events for the user
        loginEventDispatcher.dispatch(
                LoginEventConfiguration.builder()
                        .userEntity(userEntity)
                        .build()
        );

        // Setup of the session of the user
        sessionEntity.setAttribute("USER_ID", userEntity.getId());

        return LoginEvaluationResult.builder()
                .result(LoginResult.SUCCESSFUL)
                .user(userEntity)
                .build();
    }
}
