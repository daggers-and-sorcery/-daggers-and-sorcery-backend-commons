package com.morethanheroic.login.kongregate.service.domain.entity;

import com.morethanheroic.login.service.login.domain.entity.LoginEntity;
import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class KongregateLoginEntity implements LoginEntity {

    private final int userId;
    private final String authenticationToken;
}
