package com.morethanheroic.login.kongregate.configuration;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Data
@Component
@ConfigurationProperties("login.kongregate")
public class KongregateLoginConfigurationProperties {

    private String apiKey;
}
