package com.morethanheroic.login.kongregate.service.user.finder.domain;

import com.morethanheroic.login.service.login.domain.entity.LoginEntity;
import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class KongregateUserFinderEntity implements LoginEntity {

    private final int userId;
    private final String authenticationToken;
    private final String username;
}
