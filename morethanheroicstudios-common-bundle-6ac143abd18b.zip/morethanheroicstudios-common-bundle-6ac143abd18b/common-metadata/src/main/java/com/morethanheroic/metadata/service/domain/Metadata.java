package com.morethanheroic.metadata.service.domain;

public interface Metadata {

    String getName();
}
