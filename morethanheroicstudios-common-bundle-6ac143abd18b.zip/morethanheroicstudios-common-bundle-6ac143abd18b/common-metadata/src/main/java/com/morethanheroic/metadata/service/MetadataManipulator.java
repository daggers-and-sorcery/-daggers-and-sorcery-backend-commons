package com.morethanheroic.metadata.service;

import com.morethanheroic.metadata.repository.MetadataRepository;
import com.morethanheroic.metadata.repository.domain.MetadataDatabaseEntity;
import com.morethanheroic.metadata.service.domain.Metadata;
import com.morethanheroic.user.domain.UserEntity;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class MetadataManipulator {

    private final MetadataRepository metadataRepository;

    public long getMetadataValue(final UserEntity userEntity, final Metadata metadata) {
        final MetadataDatabaseEntity metadataDatabaseEntity = metadataRepository.findByUserIdAndName(
                userEntity.getId(), metadata.getName());

        return metadataDatabaseEntity != null ? metadataDatabaseEntity.getValue() : 0;
    }

    public void setMetadataValue(final UserEntity userEntity, final Metadata metadata, final long value) {
        final MetadataDatabaseEntity metadataDatabaseEntity = metadataRepository.findByUserIdAndName(
                userEntity.getId(), metadata.getName());

        if (metadataDatabaseEntity == null) {
            metadataRepository.insert(userEntity.getId(), metadata.getName(), value);
        } else {
            metadataRepository.update(userEntity.getId(), metadata.getName(), value);
        }
    }

    public void decreaseMetadataValue(final UserEntity userEntity, final Metadata metadata) {
        decreaseMetadataValue(userEntity, metadata, 1);
    }

    public void decreaseMetadataValue(final UserEntity userEntity, final Metadata metadata, final long amount) {
        setMetadataValue(userEntity, metadata, getMetadataValue(userEntity, metadata) - amount);
    }

    public void increaseMetadataValue(final UserEntity userEntity, final Metadata metadata) {
        increaseMetadataValue(userEntity, metadata, 1);
    }

    public void increaseMetadataValue(final UserEntity userEntity, final Metadata metadata, final long amount) {
        setMetadataValue(userEntity, metadata, getMetadataValue(userEntity, metadata) + amount);
    }
}
