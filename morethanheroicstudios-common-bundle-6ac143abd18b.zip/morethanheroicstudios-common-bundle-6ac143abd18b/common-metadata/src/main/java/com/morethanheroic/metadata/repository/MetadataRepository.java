package com.morethanheroic.metadata.repository;

import com.morethanheroic.metadata.repository.domain.MetadataDatabaseEntity;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

@Mapper
public interface MetadataRepository {

    @Select("SELECT * FROM metadata WHERE user_id = #{userId} AND name = #{name}")
    MetadataDatabaseEntity findByUserIdAndName(@Param("userId") int userId, @Param("name") String name);

    @Insert("UPDATE metadata SET value = #{value} WHERE user_id = #{userId} AND name = #{name}")
    void update(@Param("userId") long userId, @Param("name") String name, @Param("value") long value);

    @Insert("INSERT INTO metadata SET user_id = #{userId}, name = #{name}, value = #{value}")
    void insert(@Param("userId") long userId, @Param("name") String name, @Param("value") long value);
}
