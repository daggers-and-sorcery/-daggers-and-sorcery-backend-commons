package com.morethanheroic.metadata.repository.domain;

import lombok.Data;

@Data
public class MetadataDatabaseEntity {

    private int id;
    private long userId;
    private String name;
    private long value;
}
