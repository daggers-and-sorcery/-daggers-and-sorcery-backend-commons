# Common Metadata

## Changelog

- ***4.1.23.RELEASE***
  - Added helper methods to MetadataManipulator.
- ***4.0.9.RELEASE***
  - Issuing a bugfix for the 4.0.8.RELEASE.
- ***4.0.8.RELEASE***
  - Made the metadata update on set if exists.
- ***4.0.7.RELEASE***
  - The MetadataManipulator is updating a metadata if it already exists instead of re-inserting it.
- ***4.0.6.RELEASE***
  - The MetadataManipulator returns 0 if a metadata doesn't exists instead of throwing a NPE.
- ***4.0.2.RELEASE***
  - Moved in to the common-bundle repository.
- ***1.0.2***
  - Moved from int based metadata handling to a long based one.
