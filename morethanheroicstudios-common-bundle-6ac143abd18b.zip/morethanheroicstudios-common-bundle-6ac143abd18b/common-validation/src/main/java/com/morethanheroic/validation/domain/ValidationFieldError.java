package com.morethanheroic.validation.domain;

import lombok.Builder;
import lombok.Getter;
import lombok.ToString;

import javax.validation.Path;

@Builder
@ToString
@Getter
public class ValidationFieldError {

    private final Path field;
    private final String error;
}
