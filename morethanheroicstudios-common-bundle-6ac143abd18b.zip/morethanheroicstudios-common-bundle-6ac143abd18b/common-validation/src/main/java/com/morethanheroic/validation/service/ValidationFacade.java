package com.morethanheroic.validation.service;

import com.morethanheroic.validation.domain.ValidationFieldError;
import com.morethanheroic.validation.domain.ValidationFieldResult;
import com.morethanheroic.validation.domain.ValidationResult;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import javax.validation.ConstraintViolation;
import javax.validation.Path;
import javax.validation.Validator;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

@Service
@RequiredArgsConstructor
public class ValidationFacade {

    private final Validator validator;

    //TODO: a bit refactoring needed because this is too complicated
    public ValidationResult validate(Object entity) {
        Set<ConstraintViolation<Object>> constraintViolations = validator.validate(entity);

        final Map<Path, List<ValidationFieldError>> validationFieldErrorsMap = new HashMap<>();
        for (ConstraintViolation<Object> constraintViolation : constraintViolations) {
            Path path = constraintViolation.getPropertyPath();

            if (!validationFieldErrorsMap.containsKey(path)) {
                validationFieldErrorsMap.put(path, new ArrayList<>());
            }

            validationFieldErrorsMap.get(path).add(
                    ValidationFieldError.builder()
                            .field(path)
                            .error(constraintViolation.getMessage())
                            .build()
            );
        }

        final List<ValidationFieldResult> validationFieldResults = new ArrayList<>();
        for (Path validationFieldErrorsKey : validationFieldErrorsMap.keySet()) {
            validationFieldResults.add(
                    ValidationFieldResult.builder()
                            .path(validationFieldErrorsKey)
                            .isValid(false)
                            .validationFieldErrors(Collections.unmodifiableList(validationFieldErrorsMap.get(validationFieldErrorsKey)))
                            .build()
            );
        }

        return ValidationResult.builder()
                .isValid(validationFieldResults.size() == 0)
                .validationFieldResults(Collections.unmodifiableList(validationFieldResults))
                .build();
    }
}
