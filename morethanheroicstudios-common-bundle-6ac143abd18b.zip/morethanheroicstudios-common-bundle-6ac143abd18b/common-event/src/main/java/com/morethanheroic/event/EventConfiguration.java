package com.morethanheroic.event;

/**
 * This class is used to pass down data for the {@link EventHandler} that will handle the event.
 */
public interface EventConfiguration {
}
