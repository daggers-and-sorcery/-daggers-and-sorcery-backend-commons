# Common Event

This package provides a common way to fire application-wide events.
