package com.morethanheroic.payment.stripe.service.charge.domain;

import lombok.Builder;
import lombok.Getter;

import java.math.BigDecimal;
import java.util.Currency;

/**
 * Contains all of the data that's required to create a charge.
 *
 * @see <a href="https://stripe.com/docs/charges">https://stripe.com/docs/charges</a>
 * @see <a href="https://stripe.com/docs/connect/direct-charges#collecting-fees">
 * https://stripe.com/docs/connect/direct-charges#collecting-fees</a>
 */
@Getter
@Builder
public class ChargeEntity {

    /**
     * Contains the account's Id that will receive the money. If set to null then the "main" stripe account will get the
     * funds.
     */
    private final String chargingAccount;

    /**
     * Contains the source of the money (eg a credit card).
     */
    private final String chargedSource;

    /**
     * Contains the price we want to charge.
     */
    private final BigDecimal price;

    /**
     * Contains the currency of the charge.
     */
    private final Currency currency;

    /**
     * Contains any application fee. This parameter only makes sense when the {@link #chargingAccount} is a Stripe
     * Connect account and we want to get a cut from the payment. The cut will be added to our main account.
     *
     * @see <a href="https://stripe.com/docs/connect/direct-charges#collecting-fees">
     * https://stripe.com/docs/connect/direct-charges#collecting-fees</a>
     */
    private final long applicationFee;
}
