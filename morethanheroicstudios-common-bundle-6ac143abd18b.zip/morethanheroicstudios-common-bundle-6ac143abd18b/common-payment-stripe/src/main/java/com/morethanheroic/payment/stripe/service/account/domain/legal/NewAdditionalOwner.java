package com.morethanheroic.payment.stripe.service.account.domain.legal;

import lombok.Builder;
import lombok.Getter;

import java.time.LocalDate;

@Getter
@Builder
public class NewAdditionalOwner {

    private final String firstName;
    private final String lastName;
    private final LocalDate dayOfBirth;
    private final NewLegalEntityAddress address;
}
