package com.morethanheroic.payment.stripe.service.account.exception;

/**
 * Thrown when an error happens while trying to create a stripe account.
 */
public class AccountCreationException extends RuntimeException {

    public AccountCreationException(final String message, final Throwable throwable) {
        super(message, throwable);
    }
}
