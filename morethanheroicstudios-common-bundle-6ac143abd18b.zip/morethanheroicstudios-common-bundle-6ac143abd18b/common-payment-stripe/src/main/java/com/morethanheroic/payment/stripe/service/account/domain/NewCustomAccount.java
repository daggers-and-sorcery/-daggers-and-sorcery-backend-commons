package com.morethanheroic.payment.stripe.service.account.domain;

import com.morethanheroic.payment.stripe.domain.account.AccountType;
import com.morethanheroic.payment.stripe.service.account.domain.external.NewExternalAccount;
import com.morethanheroic.payment.stripe.service.account.domain.legal.NewLegalEntity;
import com.neovisionaries.i18n.CountryCode;
import lombok.Builder;
import lombok.Getter;
import lombok.NonNull;

import java.util.Currency;
import java.util.Map;

@Getter
@Builder
public class NewCustomAccount {

    @NonNull
    private final AccountType type;

    @NonNull
    private final CountryCode country;

    /**
     * The publicly visible name of the business.
     */
    private final String businessName;

    /**
     * The primary user’s email address. (Required.)
     */
    @NonNull
    private final String email;

    /**
     * Three-letter ISO currency code representing the default currency for the account. This must be a currency that
     * Stripe supports in the account’s country. (Required.)
     */
    @NonNull
    private final Currency defaultCurrency;

    /**
     * A card or bank account to attach to the account. You can provide either a token, like the ones returned by
     * Stripe.js, or a dictionary, as documented in the external_account parameter for bank account creation.
     * <p>
     * By default, providing an external account sets it as the new default external account for its currency, and
     * deletes the old default if one exists. To add additional external accounts without replacing the existing
     * default for the currency, use the bank account or card creation API.
     * <p>
     * (Custom only.)
     */
    private final NewExternalAccount externalAccount;

    /**
     * A set of key-value pairs that you can attach to an Account object. This can be useful for storing additional
     * information about the account in a structured format. (Custom and Express only.)
     */
    private final Map<String, String> metadata;

    /**
     * Internal-only description of the product sold by, or service provided by, the business. Used by Stripe for risk
     * and underwriting purposes. (Custom only.)
     */
    private final String productDescription;

    private final NewLegalEntity legalEntity;

    /**
     * The IP address from which the account representative accepted the Stripe Services Agreement.
     */
    @NonNull
    private final String ip;

    /**
     * The user agent of the browser from which the account representative accepted the Stripe Services Agreement.
     */
    @NonNull
    private final String userAgent;
}
