package com.morethanheroic.payment.stripe.service.account.entity.factory.exception;

public class AccountEntityCreationException extends RuntimeException {

    public AccountEntityCreationException(final String message, final Throwable throwable) {
        super(message, throwable);
    }
}
