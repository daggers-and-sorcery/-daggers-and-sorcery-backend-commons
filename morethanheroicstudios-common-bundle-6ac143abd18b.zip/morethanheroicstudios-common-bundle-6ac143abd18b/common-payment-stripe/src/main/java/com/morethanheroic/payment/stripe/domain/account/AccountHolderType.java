package com.morethanheroic.payment.stripe.domain.account;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public enum AccountHolderType {

    INDIVIDUAL("individual"),
    COMPANY("company");

    private final String name;
}
