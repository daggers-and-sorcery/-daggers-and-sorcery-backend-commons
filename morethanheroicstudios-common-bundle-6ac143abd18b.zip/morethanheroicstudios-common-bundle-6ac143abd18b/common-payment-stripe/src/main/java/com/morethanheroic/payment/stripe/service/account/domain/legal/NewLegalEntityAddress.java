package com.morethanheroic.payment.stripe.service.account.domain.legal;

import com.neovisionaries.i18n.CountryCode;
import lombok.Builder;
import lombok.Getter;

/**
 * Holds the data about the address of the legal entity.
 */
@Getter
@Builder
public class NewLegalEntityAddress {

    private final CountryCode country;
    private final String city;
    private final String line1;
    private final String line2;
    private final String postalCode;
    private final String state;
}
