package com.morethanheroic.payment.stripe.service;

import com.morethanheroic.payment.domain.PaymentEntity;
import com.morethanheroic.payment.domain.PaymentStatus;
import com.morethanheroic.payment.domain.result.DefaultPaymentResultEntity;
import com.morethanheroic.payment.domain.result.PaymentResult;
import com.morethanheroic.payment.domain.result.PaymentResultEntity;
import com.morethanheroic.payment.service.PaymentProcessor;
import com.morethanheroic.payment.service.callback.PaymentCallbackHandler;
import com.morethanheroic.payment.service.callback.domain.PaymentCallbackEntity;
import com.morethanheroic.payment.service.manipulator.PaymentManipulator;
import com.morethanheroic.payment.stripe.domain.StripePaymentContext;
import com.morethanheroic.payment.stripe.service.charge.StripeChargeCreator;
import com.morethanheroic.payment.stripe.service.charge.domain.ChargeEntity;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
@ConditionalOnProperty(name = "payment.provider", havingValue = "stripe")
public class StripePaymentProcessor implements PaymentProcessor<StripePaymentContext> {

    private final StripeChargeCreator stripeChargeCreator;
    private final PaymentCallbackHandler paymentCallbackHandler;
    private final PaymentManipulator paymentManipulator;

    @Override
    public PaymentResultEntity processPayment(final StripePaymentContext paymentContext) {
        final PaymentEntity payment = paymentContext.getPaymentEntity();

        // Charging the user
        final PaymentResult paymentResult = stripeChargeCreator.createCharge(
                ChargeEntity.builder()
                        .chargingAccount(paymentContext.getChargingAccount())
                        .chargedSource(paymentContext.getToken())
                        .price(payment.getPrice())
                        .currency(payment.getCurrency())
                        .applicationFee(paymentContext.getApplicationFee())
                        .build()
        );

        // Calling the payment callbacks
        paymentCallbackHandler.handlePaymentCallback(
                PaymentCallbackEntity.builder()
                        .paymentId(payment.getId())
                        .build()
        );

        // Updating the payment
        if (paymentResult == PaymentResult.SUCCESSFUL) {
            paymentManipulator.updateStatus(payment.getId(), PaymentStatus.FINISHED);
        }

        return DefaultPaymentResultEntity.builder()
                .result(paymentResult)
                .build();
    }
}
