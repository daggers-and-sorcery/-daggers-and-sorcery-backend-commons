package com.morethanheroic.payment.stripe.service.account.entity.factory.domain;

import lombok.Builder;
import lombok.Getter;

import java.util.List;

@Getter
@Builder
public class StripeAccountEntity {

    private final boolean verified;
    private final List<AdditionalOwnerEntity> additionalOwners;
}
