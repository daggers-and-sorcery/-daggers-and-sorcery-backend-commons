package com.morethanheroic.payment.stripe.service.account.verification;

import com.morethanheroic.payment.stripe.configuration.StripePaymentsProperties;
import com.morethanheroic.payment.stripe.service.account.document.DocumentUploader;
import com.stripe.exception.*;
import com.stripe.model.Account;
import com.stripe.model.FileUpload;
import com.stripe.net.RequestOptions;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Service;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

@Slf4j
@Service
@RequiredArgsConstructor
@ConditionalOnProperty(name = "payment.provider", havingValue = "stripe")
public class VerificationDocumentProcessor {

    private final DocumentUploader documentUploader;
    private final StripePaymentsProperties stripePaymentsProperties;

    public void verificationDocumentProvider(final String accountId, final File legalDocument) {
        final String fileId = documentUploader.uploadLegalDocument(accountId, legalDocument);

        try {
            Account account = Account.retrieve(accountId,
                    RequestOptions.builder()
                            .setApiKey(stripePaymentsProperties.getApiKey())
                            .build()
            );

            Map<String, String> verificationParams = new HashMap<>();
            verificationParams.put("document", fileId);

            Map<String, Object> legalEntityParams = new HashMap<>();
            legalEntityParams.put("verification", verificationParams);

            Map<String, Object> accountParams = new HashMap<>();
            accountParams.put("legal_entity", legalEntityParams);

            account.update(accountParams,
                    RequestOptions.builder()
                            .setApiKey(stripePaymentsProperties.getApiKey())
                            .build()
            );
        } catch (AuthenticationException | InvalidRequestException | CardException | APIConnectionException
                | APIException e) {
            throw new RuntimeException(e);
        }
    }

    public void verificationDocumentProviderForAdditionalOwner(final String accountId, final int ownerId,
            final File legalDocument) {
        final String fileId = documentUploader.uploadLegalDocument(accountId, legalDocument);

        try {
            Account account = Account.retrieve(accountId,
                    RequestOptions.builder()
                            .setApiKey(stripePaymentsProperties.getApiKey())
                            .build()
            );

            Map<String, String> verificationParams = new HashMap<>();
            verificationParams.put("document", fileId);

            Map<String, Object> legalEntityParams = new HashMap<>();
            legalEntityParams.put("verification", verificationParams);

            Map<String, Object> additionalOwnersIdParams = new HashMap<>();
            additionalOwnersIdParams.put(String.valueOf(ownerId), legalEntityParams);

            Map<String, Object> additionalOwnersParams = new HashMap<>();
            additionalOwnersParams.put("additional_owners", additionalOwnersIdParams);

            Map<String, Object> accountParams = new HashMap<>();
            accountParams.put("legal_entity", additionalOwnersParams);

            account.update(accountParams,
                    RequestOptions.builder()
                            .setApiKey(stripePaymentsProperties.getApiKey())
                            .build()
            );
        } catch (AuthenticationException | InvalidRequestException | CardException | APIConnectionException
                | APIException e) {
            throw new RuntimeException(e);
        }
    }
}
