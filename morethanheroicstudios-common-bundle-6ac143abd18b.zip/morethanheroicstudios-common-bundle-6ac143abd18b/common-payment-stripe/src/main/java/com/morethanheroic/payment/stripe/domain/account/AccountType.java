package com.morethanheroic.payment.stripe.domain.account;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public enum AccountType {

    /**
     * Standard accounts are normal Stripe accounts: Stripe will email the account holder to set up a username and
     * password, and will handle all account management directly with them.
     */
    STANDARD("standard"),

    /**
     * Custom accounts have extra parameters available to them, and require that you, the platform, handle all
     * communication with the account holder.
     */
    CUSTOM("custom");

    private final String name;
}
