package com.morethanheroic.payment.stripe.service.account.domain.legal;

import lombok.Builder;
import lombok.Getter;
import lombok.NonNull;

import java.time.LocalDate;
import java.util.List;

/**
 * Identifies the holder of the account.
 */
@Getter
@Builder
public class NewLegalEntity {

    /**
     * The address of the legal entity (i.e., individual or company).
     */
    @NonNull
    private final NewLegalEntityAddress address;

    /**
     * The legal name of the entity (companies only).
     */
    @NonNull
    private final String businessName;

    /**
     * The business ID number of the legal entity (companies only), as appropriate for the company’s country. (Examples
     * are an Employer ID Number in the U.S., a Business Number in Canada, or a Company Number in the UK.)
     */
    @NonNull
    private final String businessTaxId;

    /**
     * The account representative’s first name.
     */
    @NonNull
    private final String representativeFirstName;

    /**
     * The account representative’s last name.
     */
    @NonNull
    private final String representativeLastName;

    /**
     * The account representative’s date of birth.
     */
    @NonNull
    private final LocalDate representativeDayOfBirth;

    /**
     * The account representative’s address.
     */
    @NonNull
    private final NewLegalEntityAddress representativeAddress;

    /**
     * The legal entity type.
     */
    @NonNull
    private final LegalEntityType type;

    private final List<NewAdditionalOwner> additionalOwners;
}
