package com.morethanheroic.payment.stripe.service.account.entity.factory.domain;

import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class AdditionalOwnerEntity {

    private final int id;
    private final String firstName;
    private final String lastName;
}
