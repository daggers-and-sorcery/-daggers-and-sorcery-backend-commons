package com.morethanheroic.entity.domain;

public interface Entity<IDENTIFIER> {

    IDENTIFIER getId();
}
