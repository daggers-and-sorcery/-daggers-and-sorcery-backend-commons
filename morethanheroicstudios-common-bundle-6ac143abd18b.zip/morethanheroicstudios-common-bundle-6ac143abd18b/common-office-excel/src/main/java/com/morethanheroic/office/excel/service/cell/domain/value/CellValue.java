package com.morethanheroic.office.excel.service.cell.domain.value;

public interface CellValue<T> {

    T getValue();
}
