package com.morethanheroic.office.excel.service.document;

import com.morethanheroic.office.excel.service.document.domain.ExcelDocument;
import org.springframework.stereotype.Service;

@Service
public class ExcelDocumentFactory {

    public ExcelDocument newDocument() {
        return new ExcelDocument();
    }
}
