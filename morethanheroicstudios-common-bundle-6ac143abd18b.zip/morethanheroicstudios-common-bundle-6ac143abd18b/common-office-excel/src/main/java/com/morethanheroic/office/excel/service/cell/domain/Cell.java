package com.morethanheroic.office.excel.service.cell.domain;

import com.morethanheroic.office.excel.service.cell.domain.style.CellStyleContext;
import com.morethanheroic.office.excel.service.cell.domain.value.CellValue;
import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class Cell<T> {

    private final CellValue<T> value;
    private final CellStyleContext style;
}
