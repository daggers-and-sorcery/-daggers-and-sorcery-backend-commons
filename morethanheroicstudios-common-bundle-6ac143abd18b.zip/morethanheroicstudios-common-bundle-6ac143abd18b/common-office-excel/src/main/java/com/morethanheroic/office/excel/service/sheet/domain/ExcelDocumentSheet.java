package com.morethanheroic.office.excel.service.sheet.domain;

import com.morethanheroic.office.excel.service.cell.domain.value.RichTextStringCellValue;
import com.morethanheroic.office.excel.service.document.domain.ExcelDocument;
import com.morethanheroic.office.excel.service.cell.domain.style.CellStyleContext;
import com.morethanheroic.office.excel.service.cell.domain.value.CellValue;
import com.morethanheroic.office.excel.service.cell.domain.value.DoubleCellValue;
import com.morethanheroic.office.excel.service.cell.domain.value.StringCellValue;
import lombok.RequiredArgsConstructor;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.util.CellRangeAddress;

import java.util.Date;

/**
 * Contains the data of a sheet in an {@link ExcelDocument}.
 */
@RequiredArgsConstructor
public class ExcelDocumentSheet {

    private final Workbook workbook;
    private final Sheet sheet;

    public void setCell(final int rowId, final int columnId,
            final com.morethanheroic.office.excel.service.cell.domain.Cell cell) {
        if (!isRowExists(rowId)) {
            newRow(rowId);
        }

        final Cell rawCell = sheet.getRow(rowId).createCell(columnId);

        final CellValue<?> value = cell.getValue();
        final CellStyleContext cellStyleContext = cell.getStyle();

        if (value.getValue() == null) {
            rawCell.setCellValue((Date) null);
        } else if (value instanceof StringCellValue) {
            rawCell.setCellValue(((StringCellValue) value).getValue());
        } else if (value instanceof DoubleCellValue) {
            rawCell.setCellValue(((DoubleCellValue) value).getValue());
        } else if (value instanceof RichTextStringCellValue) {
            rawCell.setCellValue(((RichTextStringCellValue) value).getValue());
        }

        if (cellStyleContext != null) {
            setCellStyle(rawCell.getRowIndex(), rawCell.getColumnIndex(), cellStyleContext);
        }
    }

    public void setCellStyle(final int rowId, final int columnId, final CellStyleContext cellStyleContext) {
        final Font font = workbook.createFont();

        font.setBold(cellStyleContext.isFontBold());

        if (cellStyleContext.getFontColor() != null) {
            font.setColor(cellStyleContext.getFontColor().getIndex());
        } else {
            font.setColor(IndexedColors.BLACK.getIndex());
        }

        final CellStyle cellStyle = workbook.createCellStyle();
        cellStyle.setFont(font);

        if (cellStyleContext.getHorizontalAlignment() != null) {
            cellStyle.setAlignment(cellStyleContext.getHorizontalAlignment());
        }

        if (cellStyleContext.getVerticalAlignment() != null) {
            cellStyle.setVerticalAlignment(cellStyleContext.getVerticalAlignment());
        }

        if (cellStyleContext.getDataFormat() != null) {
            final DataFormat df = workbook.createDataFormat();

            cellStyle.setDataFormat(df.getFormat(cellStyleContext.getDataFormat()));
        }

        sheet.getRow(rowId).getCell(columnId).setCellStyle(cellStyle);
    }

    /**
     * Add a new row after the last row in the sheet.
     *
     * @param rowValues the values in the columns of the new row
     * @return return the newly created row's id
     */
    public int newRow(final CellValue... rowValues) {
        final int rowId = sheet.getLastRowNum() + 1;

        setRow(rowId, null, rowValues);

        return rowId;
    }

    /**
     * Add a new row after the last row in the sheet.
     *
     * @param cells the values in the columns of the new row
     * @return return the newly created row's id
     */
    public int newRow(final com.morethanheroic.office.excel.service.cell.domain.Cell... cells) {
        final int rowId = sheet.getLastRowNum() + 1;

        setRow(rowId, cells);

        return rowId;
    }

    public void newRow(final int rowId) {
        sheet.createRow(rowId);
    }

    public boolean isRowExists(final int rowId) {
        return sheet.getRow(rowId) != null;
    }

    public void mergeCells(final String cellRange) {
        sheet.addMergedRegion(CellRangeAddress.valueOf(cellRange));
    }

    /**
     * Set the values of the row at the given row id.
     *
     * @param rowId the id to set the cell values
     * @param cells the row values to set
     */
    public void setRow(final int rowId, final com.morethanheroic.office.excel.service.cell.domain.Cell... cells) {
        for (int i = 0; i < cells.length; i++) {
            setCell(rowId, i, cells[i]);
        }
    }

    /**
     * Set the values of the row at the given row id. Use the styling provided for all of the newly filled cells.
     *
     * @param rowId            the id to set the cell values
     * @param cellStyleContext the style of the cells
     * @param rowValues        the row values to set
     */
    public void setRow(final int rowId, final CellStyleContext cellStyleContext,
            final CellValue... rowValues) {
        for (int i = 0; i < rowValues.length; i++) {
            setCell(rowId, i,
                    com.morethanheroic.office.excel.service.cell.domain.Cell.builder()
                            .value(rowValues[i])
                            .style(cellStyleContext)
                            .build()
            );
        }
    }

    /**
     * Optimize the width of the given columns. After the optimization every content in the columns will be visible. The
     * width of the columns will be adjusted as needed.
     *
     * @param startingColumn the starting column of the optimization
     * @param endingColumn   the ending column of the optimization
     */
    public void optimizeColumnWidth(final int startingColumn, final int endingColumn) {
        for (int i = startingColumn; i <= endingColumn; i++) {
            sheet.autoSizeColumn(i);
        }
    }

    /**
     * Set a filter on a cell range (like H2 or A2:J2).
     *
     * @param cellRange the cell range to set the filter for
     */
    public void setFilter(final String cellRange) {
        sheet.setAutoFilter(CellRangeAddress.valueOf(cellRange));
    }
}
