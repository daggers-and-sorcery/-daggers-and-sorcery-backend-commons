package com.morethanheroic.office.excel.service.document.domain;

import com.morethanheroic.office.excel.service.sheet.domain.ExcelDocumentSheet;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.DefaultIndexedColorMap;
import org.apache.poi.xssf.usermodel.IndexedColorMap;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.awt.*;
import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.IOException;

public class ExcelDocument implements Closeable {

    private final Workbook workbook = new XSSFWorkbook();

    public ExcelDocumentSheet newSheet(final String sheetName) {
        final Sheet sheet = workbook.createSheet(sheetName);

        return new ExcelDocumentSheet(workbook, sheet);
    }

    public byte[] build() {
        final ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();

        try {
            workbook.write(byteArrayOutputStream);
        } catch (IOException e) {
            throw new RuntimeException("Failed to generate the xls document!");
        }

        return byteArrayOutputStream.toByteArray();
    }

    public Font newFont(final Color color) {
        final IndexedColorMap indexedColorMap = new DefaultIndexedColorMap();
        final XSSFColor xssfColor = new XSSFColor(new java.awt.Color(128, 0, 128), indexedColorMap);

        final Font font = workbook.createFont();
        font.setColor(xssfColor.getIndex());

        return font;
    }

    @Override
    public void close() {
        try {
            workbook.close();
        } catch (IOException e) {
            throw new RuntimeException("Unable to close ExcelDocument!", e);
        }
    }
}
