package com.morethanheroic.office.excel.service.cell.domain.value;

import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class DoubleCellValue implements CellValue<Double> {

    private final Double value;
}
