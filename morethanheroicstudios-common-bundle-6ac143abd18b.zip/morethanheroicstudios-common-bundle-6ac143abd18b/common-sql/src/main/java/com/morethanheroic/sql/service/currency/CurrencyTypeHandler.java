package com.morethanheroic.sql.service.currency;

import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Currency;
import org.apache.ibatis.type.JdbcType;
import org.apache.ibatis.type.MappedTypes;
import org.apache.ibatis.type.TypeHandler;

@MappedTypes(Currency.class)
public class CurrencyTypeHandler implements TypeHandler<Currency> {

    @Override
    public void setParameter(PreparedStatement ps, int i, Currency parameter, JdbcType jdbcType) throws SQLException {
        ps.setString(i, parameter.getCurrencyCode());
    }

    @Override
    public Currency getResult(ResultSet rs, String columnName) throws SQLException {
        return Currency.getInstance(rs.getString(columnName));
    }

    @Override
    public Currency getResult(ResultSet rs, int columnIndex) throws SQLException {
        return Currency.getInstance(rs.getString(columnIndex));
    }

    @Override
    public Currency getResult(CallableStatement cs, int columnIndex) throws SQLException {
        return Currency.getInstance(cs.getString(columnIndex));
    }
}
