package com.morethanheroic.session.configuration;

import com.morethanheroic.dependencyinjection.resolver.HandlerMethodArgumentResolverRegistrationBean;
import com.morethanheroic.session.service.resolver.SessionEntityHandlerMethodArgumentResolver;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("com.morethanheroic.session")
public class SessionConfiguration {

    @Bean
    public HandlerMethodArgumentResolverRegistrationBean sessionEntityHandlerMethodArgumentResolverRegistrationBean(
            SessionEntityHandlerMethodArgumentResolver sessionEntityHandlerMethodArgumentResolver) {
        return new HandlerMethodArgumentResolverRegistrationBean(
                sessionEntityHandlerMethodArgumentResolver);
    }
}
