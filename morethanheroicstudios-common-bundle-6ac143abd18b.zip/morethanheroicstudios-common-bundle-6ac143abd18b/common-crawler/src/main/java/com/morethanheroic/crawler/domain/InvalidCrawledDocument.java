package com.morethanheroic.crawler.domain;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

public class InvalidCrawledDocument implements CrawledDocument {

    @Override
    public DocumentLocation getLocation() {
        try {
            return DocumentLocation.builder()
                    .url(new URL(""))
                    .build();
        } catch (MalformedURLException e) {
            e.printStackTrace();

            throw new RuntimeException("This shouldn't be possible!");
        }
    }

    @Override
    public String getContent() {
        return "";
    }

    @Override
    public boolean hasElement(String selector) {
        return false;
    }

    @Override
    public Optional<CrawledElement> selectElement(String selector) {
        return Optional.empty();
    }

    @Override
    public List<CrawledElement> selectElements(String selector) {
        return Collections.emptyList();
    }
}
