package com.morethanheroic.crawler.jsoup.domain;

import com.morethanheroic.crawler.domain.CrawledDocument;
import com.morethanheroic.crawler.domain.CrawledElement;
import com.morethanheroic.crawler.domain.DocumentLocation;
import lombok.Builder;
import lombok.Getter;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Builder
public class JsoupCrawledDocument implements CrawledDocument {

    private final Document document;

    @Getter
    private final DocumentLocation location;

    @Override
    public String getContent() {
        return document.outerHtml();
    }

    @Override
    public boolean hasElement(final String selector) {
        return document.select(selector).first() != null;
    }

    @Override
    public Optional<CrawledElement> selectElement(final String selector) {
        final Element element = document.select(selector).first();

        if (element == null) {
            return Optional.empty();
        }

        return Optional.of(
                JsoupCrawledElement.builder()
                        .element(element)
                        .build()
        );
    }

    @Override
    public List<CrawledElement> selectElements(final String selector) {
        return document.select(selector).stream()
                .map(element ->
                        JsoupCrawledElement.builder()
                                .element(element)
                                .build()
                )
                .collect(Collectors.toList());
    }
}
