package com.morethanheroic.crawler.exception;

public class DownloadingException extends RuntimeException {

    public DownloadingException(final Throwable throwable) {
        super(throwable);
    }

    public DownloadingException(final String message, final Throwable throwable) {
        super(message, throwable);
    }
}
