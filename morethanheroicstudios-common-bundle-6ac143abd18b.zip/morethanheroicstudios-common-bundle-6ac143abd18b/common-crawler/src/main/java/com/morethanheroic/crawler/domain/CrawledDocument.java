package com.morethanheroic.crawler.domain;

import java.util.List;
import java.util.Optional;

public interface CrawledDocument {

  DocumentLocation getLocation();

  String getContent();

  boolean hasElement(final String selector);

  Optional<CrawledElement> selectElement(final String selector);

  List<CrawledElement> selectElements(final String selector);
}
