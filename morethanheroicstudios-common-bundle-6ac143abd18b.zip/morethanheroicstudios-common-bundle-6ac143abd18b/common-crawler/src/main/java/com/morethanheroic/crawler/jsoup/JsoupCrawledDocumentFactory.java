package com.morethanheroic.crawler.jsoup;

import com.morethanheroic.crawler.CrawledDocumentFactory;
import com.morethanheroic.crawler.DocumentLocationFactory;
import com.morethanheroic.crawler.domain.CrawledDocument;
import com.morethanheroic.crawler.domain.DocumentLocation;
import com.morethanheroic.crawler.exception.DownloadingException;
import com.morethanheroic.crawler.jsoup.domain.JsoupCrawledDocument;
import lombok.RequiredArgsConstructor;
import org.jsoup.Jsoup;
import org.jsoup.UncheckedIOException;
import org.jsoup.nodes.Document;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class JsoupCrawledDocumentFactory implements CrawledDocumentFactory {

    private static final int TIMEOUT_MILLISECONDS = 30000;

    private final DocumentLocationFactory documentLocationFactory;

    @Override
    public CrawledDocument newDocument(final String documentLocation) {
        return newDocument(documentLocationFactory.newLocation(documentLocation));
    }

    @SuppressWarnings("deprecation")
    public CrawledDocument newDocument(final DocumentLocation documentLocation) {
        try {
            final Document document = Jsoup.connect(documentLocation.getUrl().toString())
                    .headers(documentLocation.getHeaders())
                    .timeout(TIMEOUT_MILLISECONDS)
                    .validateTLSCertificates(false)
                    .maxBodySize(documentLocation.getMaxBodySize())
                    .get();

            return JsoupCrawledDocument.builder()
                    .location(documentLocation)
                    .document(document)
                    .build();
        } catch (Exception | UncheckedIOException e) {
            throw new DownloadingException(e);
        }
    }
}
