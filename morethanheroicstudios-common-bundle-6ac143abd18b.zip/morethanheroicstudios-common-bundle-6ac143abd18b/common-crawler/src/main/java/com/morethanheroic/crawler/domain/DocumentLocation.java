package com.morethanheroic.crawler.domain;

import java.util.Collections;
import lombok.Builder;
import lombok.Getter;

import java.net.URL;
import java.util.Map;

@Getter
@Builder
public class DocumentLocation {

    private final URL url;

    @Builder.Default
    private final Map<String, String> headers = Collections.emptyMap();

    @Builder.Default
    private final int maxBodySize = 8388608; // 8MB
}
