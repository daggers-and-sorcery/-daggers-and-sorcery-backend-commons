package com.morethanheroic.crawler;

import com.morethanheroic.crawler.domain.DocumentLocation;
import org.springframework.stereotype.Service;

import java.net.URL;
import java.util.*;
import java.util.stream.Collectors;

import static java.util.stream.Collectors.mapping;
import static java.util.stream.Collectors.toList;

@Service
public class LocationParameterParser {

    public List<String> parseParameter(final DocumentLocation documentLocation, final String parameterName) {
        return parseParameter(documentLocation.getUrl(), parameterName);
    }

    public Map<String, List<String>> parseParameters(final DocumentLocation documentLocation) {
        return parseParameters(documentLocation.getUrl());
    }

    public List<String> parseParameter(final URL location, final String parameterName) {
        final Map<String, List<String>> parameters = parseParameters(location);

        return parameters.getOrDefault(parameterName, Collections.emptyList());
    }

    public Map<String, List<String>> parseParameters(final URL location) {
        return Arrays.stream(location.getQuery().split("&"))
                .map(this::splitQueryParameter)
                .collect(Collectors.groupingBy(Map.Entry::getKey, LinkedHashMap::new,
                        mapping(Map.Entry::getValue, toList())));
    }

    private Map.Entry<String, String> splitQueryParameter(String it) {
        final int idx = it.indexOf("=");
        final String key = idx > 0 ? it.substring(0, idx) : it;
        final String value = idx > 0 && it.length() > idx + 1 ? it.substring(idx + 1) : null;
        return new AbstractMap.SimpleImmutableEntry<>(key, value);
    }
}
