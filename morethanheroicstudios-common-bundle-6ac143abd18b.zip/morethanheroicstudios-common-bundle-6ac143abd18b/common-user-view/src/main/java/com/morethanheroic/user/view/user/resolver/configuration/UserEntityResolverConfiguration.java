package com.morethanheroic.user.view.user.resolver.configuration;

import com.morethanheroic.dependencyinjection.resolver.HandlerMethodArgumentResolverRegistrationBean;
import com.morethanheroic.user.view.user.resolver.UserEntityHandlerMethodArgumentResolver;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class UserEntityResolverConfiguration {

    @Bean
    public HandlerMethodArgumentResolverRegistrationBean userEntityHandlerMethodArgumentResolverRegistrationBean(
            UserEntityHandlerMethodArgumentResolver userEntityHandlerMethodArgumentResolver) {
        return new HandlerMethodArgumentResolverRegistrationBean(
                userEntityHandlerMethodArgumentResolver);
    }
}
