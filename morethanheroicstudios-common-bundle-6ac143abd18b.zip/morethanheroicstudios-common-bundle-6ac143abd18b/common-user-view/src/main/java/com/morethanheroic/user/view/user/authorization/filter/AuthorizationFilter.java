package com.morethanheroic.user.view.user.authorization.filter;

import com.morethanheroic.user.domain.UserEntity;
import com.morethanheroic.user.domain.authorization.Role;
import com.morethanheroic.user.view.user.service.ViewUserEntityFactory;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Optional;
import java.util.Set;

@RequiredArgsConstructor
public class AuthorizationFilter implements Filter {

    private final ViewUserEntityFactory viewUserEntityFactory;
    private final Set<Role> requiredRoles;

    @Override
    public void init(FilterConfig filterConfig) {

    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        final HttpServletRequest httpServletRequest = (HttpServletRequest) request;
        final HttpServletResponse httpServletResponse = (HttpServletResponse) response;

        final Optional<UserEntity> userEntity = viewUserEntityFactory.getUserEntity(httpServletRequest.getSession());

        if (!userEntity.isPresent() || !userEntity.get().hasAnyRole(requiredRoles)) {
            httpServletResponse.setStatus(HttpStatus.UNAUTHORIZED.value());
        } else {
            chain.doFilter(request, response);
        }
    }

    @Override
    public void destroy() {

    }
}
