package com.morethanheroic.email.service;

import com.morethanheroic.application.configuration.ApplicationProperties;
import com.morethanheroic.email.service.domail.EmailMessage;
import com.morethanheroic.email.service.exception.EmailSendingException;
import com.morethanheroic.template.service.TemplateRenderer;
import com.morethanheroic.template.service.domain.TemplateRenderingContext;
import com.morethanheroic.user.domain.UserEntity;
import lombok.RequiredArgsConstructor;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

/**
 * This class is responsible for providing ways to send email messages.
 */
@Service
@RequiredArgsConstructor
public class EmailSender {

    private final JavaMailSender javaMailSender;
    private final TemplateRenderer templateRenderer;
    private final ApplicationProperties applicationProperties;

    /**
     * Sends an email to a target user with the given subject and a rendered template. The template will be rendered
     * based on the provided {@link TemplateRenderingContext}. The to address is set to the user's email while the
     * from address is the default email of the application.
     *
     * @param userEntity               the user to send the email to
     * @param subject                  the subject of the email
     * @param templateRenderingContext the context of the rendering of the email
     */
    public void sendEmail(final UserEntity userEntity, final String subject,
            final TemplateRenderingContext templateRenderingContext) {
        sendEmail(userEntity.getEmail(), subject, templateRenderingContext);
    }

    /**
     * Sends an email to a target email address with the given subject and a rendered template. The template will be
     * rendered based on the provided {@link TemplateRenderingContext}. The to address is set to the user's email while
     * the from address is the default email of the application.
     *
     * @param emailAddress             the email address to send the email to
     * @param subject                  the subject of the email
     * @param templateRenderingContext the context of the rendering of the email
     */
    public void sendEmail(final String emailAddress, final String subject,
            final TemplateRenderingContext templateRenderingContext) {
        sendEmail(
                EmailMessage.builder()
                        .from(applicationProperties.getDefaultEmail())
                        .to(emailAddress)
                        .subject(subject)
                        .content(templateRenderer.renderTemplate(templateRenderingContext))
                        .build()
        );
    }

    /**
     * Sends the provided {@link EmailMessage}.
     *
     * @param emailMessage the message to send
     * @throws EmailSendingException thrown when something bad happened while sending the email
     */
    public void sendEmail(final EmailMessage emailMessage) throws EmailSendingException {
        final MimeMessage mimeMessage = javaMailSender.createMimeMessage();
        final MimeMessageHelper messageHelper = new MimeMessageHelper(mimeMessage);

        try {
            messageHelper.setFrom(emailMessage.getFrom());
            messageHelper.setTo(emailMessage.getTo());
            messageHelper.setSubject(emailMessage.getSubject());
            messageHelper.setText(emailMessage.getContent(), true);
        } catch (MessagingException e) {
            throw new EmailSendingException("Failed to send an email.", e);
        }

        javaMailSender.send(mimeMessage);
    }
}
