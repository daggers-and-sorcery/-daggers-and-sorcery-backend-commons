package com.morethanheroic.email.service;

import com.morethanheroic.email.service.domail.EmailMessage;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.mail.MailSenderAutoConfiguration;
import org.springframework.context.annotation.Profile;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;

@Ignore
@Profile("integration-test")
@RunWith(SpringRunner.class)
@ContextConfiguration(classes = {MailSenderAutoConfiguration.class, EmailSender.class})
@TestPropertySource(locations = "classpath:application-integration-test.properties")
@EnableAutoConfiguration
public class EmailSenderTest {

    @Autowired
    private EmailSender mailSender;

    @Test
    public void testMailSending() {
        mailSender.sendEmail(
                EmailMessage.builder()
                        .to("laxika91@gmail.com")
                        .from("laxika91@gmail.com")
                        .subject("test")
                        .content("test content")
                        .build()
        );
    }
}
