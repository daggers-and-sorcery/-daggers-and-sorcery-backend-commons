# Common Email

## Changelog

- ***1.2.0***
    - Removed the deprecated methods.
    - Added a new way to send email by a provided email address.
- ***1.1.1***
    - Added new ways to send emails via the EmailSender.
- ***1.1.0***
    - Replaced a leaking exception in the EmailSender.