package com.morethanheroic.login.kongregate.view.login.controller;

import com.morethanheroic.login.kongregate.service.KongregateLoginHandler;
import com.morethanheroic.login.kongregate.service.domain.entity.KongregateLoginEntity;
import com.morethanheroic.login.kongregate.view.login.request.KongregateLoginRequest;
import com.morethanheroic.login.service.login.domain.LoginEvaluationResult;
import com.morethanheroic.login.service.login.domain.LoginResult;
import com.morethanheroic.response.service.StatusResponseFactory;
import com.morethanheroic.response.service.domain.StatusResponse;
import com.morethanheroic.session.domain.SessionEntity;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
public class KongregateLoginController {

    private final KongregateLoginHandler kongregateLoginHandler;
    private final StatusResponseFactory statusResponseFactory;

    @PostMapping("/user/kongregate/login")
    public StatusResponse login(@RequestBody final KongregateLoginRequest kongregateLoginRequest,
            final SessionEntity sessionEntity) {

        final LoginEvaluationResult loginEvaluationResult =
                kongregateLoginHandler.handleLogin(sessionEntity,
                        KongregateLoginEntity.builder()
                                .userId(kongregateLoginRequest.getUserId())
                                .authenticationToken(kongregateLoginRequest.getAuthenticationToken())
                                .build()
                );

        if (loginEvaluationResult.getResult() == LoginResult.SUCCESSFUL) {
            return statusResponseFactory.newSuccessfulResponse();
        }

        return statusResponseFactory.newUnsuccessfulResponse(
                "Unsuccessful login request: " + loginEvaluationResult.getResult());
    }
}
