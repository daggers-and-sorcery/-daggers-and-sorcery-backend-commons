package com.morethanheroic.login.kongregate.view.login.request;

import lombok.Data;

@Data
public class KongregateLoginRequest {

    private final int userId;
    private final String authenticationToken;
}
