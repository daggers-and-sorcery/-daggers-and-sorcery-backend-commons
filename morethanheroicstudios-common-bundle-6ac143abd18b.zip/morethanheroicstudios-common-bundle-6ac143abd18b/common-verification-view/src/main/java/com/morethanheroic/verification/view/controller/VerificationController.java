package com.morethanheroic.verification.view.controller;

import com.morethanheroic.verification.service.VerificationEntityFactory;
import com.morethanheroic.verification.service.domain.VerificationEntity;
import com.morethanheroic.verification.service.finalizer.VerificationFinalizer;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.util.Optional;

@RestController
@RequiredArgsConstructor
public class VerificationController {

    private final VerificationFinalizer verificationFinalizer;
    private final VerificationEntityFactory verificationEntityFactory;

    @GetMapping("/verification/{verificationId}")
    public ResponseEntity verify(@PathVariable final String verificationId) {
        final Optional<VerificationEntity> verificationEntity =
                verificationEntityFactory.getVerificationEntity(verificationId);

        if (!verificationEntity.isPresent()) {
            return ResponseEntity.badRequest()
                    .build();
        }

        verificationFinalizer.finalizeVerification(verificationEntity.get());

        return ResponseEntity.ok()
                .build();
    }
}
