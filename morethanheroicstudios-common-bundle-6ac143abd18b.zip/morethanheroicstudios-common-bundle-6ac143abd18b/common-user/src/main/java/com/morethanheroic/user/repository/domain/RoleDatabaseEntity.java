package com.morethanheroic.user.repository.domain;

import lombok.Data;

@Data
public class RoleDatabaseEntity {

    private int userId;
    private String roleId;
}
