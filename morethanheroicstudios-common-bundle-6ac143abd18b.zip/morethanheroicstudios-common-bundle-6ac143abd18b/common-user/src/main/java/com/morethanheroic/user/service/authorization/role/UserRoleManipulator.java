package com.morethanheroic.user.service.authorization.role;

import com.morethanheroic.user.domain.UserEntity;
import com.morethanheroic.user.domain.authorization.Role;
import com.morethanheroic.user.repository.RoleRepository;
import com.morethanheroic.user.repository.domain.RoleDatabaseEntity;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Arrays;

@Service
@RequiredArgsConstructor
public class UserRoleManipulator {

    private final RoleRepository roleRepository;

    /**
     * Add a role to the user.
     *
     * @param userEntity the user to add the role for
     * @param role       the role to add
     */
    public void addRole(final UserEntity userEntity, final Role role) {
        final RoleDatabaseEntity roleDatabaseEntity = new RoleDatabaseEntity();

        roleDatabaseEntity.setUserId(userEntity.getId());
        roleDatabaseEntity.setRoleId(role.getId());

        roleRepository.insert(roleDatabaseEntity);
    }

    /**
     * Remove a role from the user.
     *
     * @param userEntity the user to remove the role from
     * @param role       the role to remove
     */
    public void removeRole(final UserEntity userEntity, final Role role) {
        roleRepository.remove(userEntity.getId(), role);
    }

    /**
     * Replace the existing roles of the user with the new ones provided.
     *
     * @param userEntity the user to set the roles for
     * @param roles      the new roles to set
     */
    @Transactional
    public void setRoles(final UserEntity userEntity, final Role... roles) {
        clearRoles(userEntity);

        Arrays.stream(roles).forEach(role -> addRole(userEntity, role));
    }

    /**
     * Remove all of the roles of a user.
     *
     * @param userEntity the user to remove the roles for
     */
    public void clearRoles(final UserEntity userEntity) {
        roleRepository.clear(userEntity.getId());
    }
}
