package com.morethanheroic.user.service.factory;

import com.morethanheroic.security.service.encoder.PasswordEncoder;
import com.morethanheroic.user.domain.UserEntity;
import com.morethanheroic.user.repository.UserRepository;
import com.morethanheroic.user.repository.domain.UserDatabaseEntity;
import com.morethanheroic.user.service.authorization.role.UserRoleCalculator;
import com.morethanheroic.user.service.factory.domain.EmailAndPasswordFactoryRequest;
import com.morethanheroic.user.service.factory.domain.EmailFactoryRequest;
import com.morethanheroic.user.service.factory.domain.PasswordFactoryRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

@Service
@RequiredArgsConstructor
public class DefaultUserEntityFactory implements UserEntityFactory {

    private final UserRepository userRepository;
    private final UserRoleCalculator userRoleCalculator;
    private final PasswordEncoder passwordEncoder;
    private final UsernameFactory usernameFactory;

    /**
     * Return an {@link UserEntity} that's created for the user with the provided id.
     *
     * @param userId the id of the user to create the entity for
     * @return the created entity
     */
    @Override
    public UserEntity getUserEntity(final int userId) {
        final UserDatabaseEntity userDatabaseEntity = userRepository.findUserById(userId);

        return convertDatabaseUserEntity(userDatabaseEntity);
    }

    @Override
    public UserEntity getUserEntity(final PasswordFactoryRequest passwordFactoryRequest) {
        final String hashedPassword = passwordEncoder.encodePassword(passwordFactoryRequest.getPassword());

        final UserDatabaseEntity userDatabaseEntity = userRepository.findUserByUsernameAndPassword(
                passwordFactoryRequest.getUsername(), hashedPassword);

        if (userDatabaseEntity == null) {
            return null;
        }

        return convertDatabaseUserEntity(userDatabaseEntity);
    }

    @Override
    public UserEntity getUserEntity(final EmailFactoryRequest emailFactoryRequest) {
        final UserDatabaseEntity userDatabaseEntity = userRepository.findUserByEmail(emailFactoryRequest.getEmail());

        return convertDatabaseUserEntity(userDatabaseEntity);
    }

    @Override
    public UserEntity getUserEntity(final EmailAndPasswordFactoryRequest emailAndPasswordFactoryRequest) {
        final String hashedPassword = passwordEncoder.encodePassword(emailAndPasswordFactoryRequest.getPassword());

        final UserDatabaseEntity userDatabaseEntity = userRepository.findUserByEmailAndPassword(
                emailAndPasswordFactoryRequest.getEmail(), hashedPassword
        );

        return convertDatabaseUserEntity(userDatabaseEntity);
    }

    @Override
    public Optional<UserEntity> getUserEntity(String username) {
        final UserDatabaseEntity userDatabaseEntity = userRepository.findUserByUsername(username);

        return Optional.ofNullable(convertDatabaseUserEntity(userDatabaseEntity));
    }

    /**
     * Create a new user in the database then return the created user's {@link UserEntity}.
     * <p>
     * If the provided username is null an username will be generated for the user.
     *
     * @param username         the name of the new user
     * @param password         the password of the new user
     * @param email            the email of the user
     * @param acceptNewsletter true if the user accept any newsletter, false otherwise
     * @return the entity of the freshly created user
     */
    @Override
    public UserEntity newUserEntity(final String username, final String password, final String email,
                                    final boolean acceptNewsletter) {
        final String hashedPassword = passwordEncoder.encodePassword(password);
        final String checkedUsername = username != null ? username : usernameFactory.newGeneratedUsername();

        userRepository.insertUser(checkedUsername, hashedPassword, email, acceptNewsletter);

        return getUserEntity(
                EmailAndPasswordFactoryRequest.builder()
                        .email(email)
                        .password(password)
                        .build()
        );
    }

    /*
     * A transaction is required because otherwise the MyBatis Cursor doesn't work.
     * See: https://groups.google.com/forum/#!topic/mybatis-user/aFnnoBqLdaQ
     */
    @Override
    @Transactional
    public Stream<UserEntity> getUserEntities() {
        return StreamSupport.stream(userRepository.findUsers().spliterator(), false)
                .map(this::convertDatabaseUserEntity);
    }

    private UserEntity convertDatabaseUserEntity(final UserDatabaseEntity userDatabaseEntity) {
        if (userDatabaseEntity == null) {
            return null;
        }

        return new UserEntity(userDatabaseEntity.getId(), userDatabaseEntity.getUsername(),
                userDatabaseEntity.getPassword(), userDatabaseEntity.getEmail(),
                userDatabaseEntity.isAcceptNewsletter(),
                userRoleCalculator.calculateRolesForUser(userDatabaseEntity.getId()));
    }
}