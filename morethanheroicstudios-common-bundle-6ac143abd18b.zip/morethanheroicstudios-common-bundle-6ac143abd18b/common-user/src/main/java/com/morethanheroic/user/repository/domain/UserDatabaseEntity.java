package com.morethanheroic.user.repository.domain;

import lombok.Data;

@Data
public class UserDatabaseEntity {

    private int id;
    private String username;
    private String password;
    private String email;
    private boolean acceptNewsletter;
}
