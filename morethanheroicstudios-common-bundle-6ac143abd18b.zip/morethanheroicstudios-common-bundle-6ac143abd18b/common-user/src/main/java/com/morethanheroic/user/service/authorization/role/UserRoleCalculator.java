package com.morethanheroic.user.service.authorization.role;

import com.morethanheroic.user.domain.authorization.Role;
import com.morethanheroic.user.repository.RoleRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Set;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class UserRoleCalculator {

    private final RoleRepository roleRepository;
    private final RoleFactory roleFactory;

    public Set<Role> calculateRolesForUser(final int userId) {
        return roleRepository.findRolesForUser(userId).stream()
                .map(roleDatabaseEntity -> roleFactory.getRole(roleDatabaseEntity.getRoleId()))
                .map(role -> {
                    if (!role.isPresent()) {
                        throw new RuntimeException("Unknown role!");
                    }

                    return role.get();
                })
                .collect(Collectors.toSet());
    }
}
