package com.morethanheroic.user.service;

import com.morethanheroic.security.service.encoder.PasswordEncoder;
import com.morethanheroic.user.domain.UserEntity;
import com.morethanheroic.user.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class UserManipulator {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    public void updatePassword(final UserEntity userEntity, final String newPassword) {
        final String hashedPassword = passwordEncoder.encodePassword(newPassword);

        userRepository.updateUserPassword(userEntity.getId(), hashedPassword);
    }

    public void updateEmail(final UserEntity userEntity, final String newEmail) {
        userRepository.updateUserEmail(userEntity.getId(), newEmail);
    }
}
