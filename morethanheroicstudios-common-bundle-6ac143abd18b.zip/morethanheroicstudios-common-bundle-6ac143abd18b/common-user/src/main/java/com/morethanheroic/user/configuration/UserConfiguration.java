package com.morethanheroic.user.configuration;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("com.morethanheroic.user")
public class UserConfiguration {
}
