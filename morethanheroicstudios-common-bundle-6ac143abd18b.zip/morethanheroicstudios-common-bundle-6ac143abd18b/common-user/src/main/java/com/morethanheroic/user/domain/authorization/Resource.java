package com.morethanheroic.user.domain.authorization;

import java.util.Set;

public interface Resource {

    Set<Role> accessibleByRoles();
}
