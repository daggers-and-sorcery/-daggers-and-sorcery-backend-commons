package com.morethanheroic.user.service;

import com.morethanheroic.user.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

/**
 * Helps you to check that a user could be registered with a given identifier. The user have more than one
 * identifiers that should be unique.
 */
@Service
@RequiredArgsConstructor
public class UserIdentifierChecker {

    private final UserRepository userRepository;

    /**
     * Checks if the provided email address is used by an user already.
     *
     * @param email the email to check
     * @return true if the email is used, false otherwise
     */
    public boolean isEmailUsed(final String email) {
        return userRepository.isEmailRegistered(email);
    }
}
