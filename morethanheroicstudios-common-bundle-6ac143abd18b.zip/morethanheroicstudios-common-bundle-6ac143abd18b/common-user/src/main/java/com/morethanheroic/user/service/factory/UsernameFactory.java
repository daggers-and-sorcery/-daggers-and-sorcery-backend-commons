package com.morethanheroic.user.service.factory;

import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
public class UsernameFactory {

    public String newGeneratedUsername() {
        return UUID.randomUUID().toString();
    }
}
