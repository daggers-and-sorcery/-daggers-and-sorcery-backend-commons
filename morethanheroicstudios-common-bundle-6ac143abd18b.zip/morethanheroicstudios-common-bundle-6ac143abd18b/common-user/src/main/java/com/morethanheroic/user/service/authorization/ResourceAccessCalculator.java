package com.morethanheroic.user.service.authorization;

import com.morethanheroic.user.domain.UserEntity;
import com.morethanheroic.user.domain.authorization.Resource;
import org.springframework.stereotype.Service;

import java.util.Collections;

@Service
public class ResourceAccessCalculator {

    public boolean hasAccess(final UserEntity userEntity, final Resource resource) {
        return !Collections.disjoint(userEntity.getRoles(), resource.accessibleByRoles());
    }
}
