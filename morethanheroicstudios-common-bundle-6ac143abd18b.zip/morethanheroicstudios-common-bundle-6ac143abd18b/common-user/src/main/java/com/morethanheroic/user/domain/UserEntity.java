package com.morethanheroic.user.domain;

import com.morethanheroic.user.domain.authorization.Role;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

@Getter
@RequiredArgsConstructor
@EqualsAndHashCode(of = "id")
public class UserEntity {

    private final int id;
    private final String username;
    private final String password;
    private final String email;
    private final boolean acceptNewsletter;
    private final Set<Role> roles;

    public boolean hasRole(final Role... roles) {
        return hasRole(new HashSet<>(Arrays.asList(roles)));
    }

    public boolean hasRole(final Set<Role> roles) {
        return this.roles.containsAll(roles);
    }

    public boolean hasAnyRole(final Role... roles) {
        return hasAnyRole(new HashSet<>(Arrays.asList(roles)));
    }

    public boolean hasAnyRole(final Set<Role> roles) {
        return roles.stream()
                .anyMatch(this.roles::contains);
    }
}
