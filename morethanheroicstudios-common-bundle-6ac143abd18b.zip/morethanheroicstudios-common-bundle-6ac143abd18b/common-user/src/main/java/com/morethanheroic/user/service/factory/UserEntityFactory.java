package com.morethanheroic.user.service.factory;

import com.morethanheroic.user.domain.UserEntity;
import com.morethanheroic.user.service.factory.domain.EmailAndPasswordFactoryRequest;
import com.morethanheroic.user.service.factory.domain.EmailFactoryRequest;
import com.morethanheroic.user.service.factory.domain.PasswordFactoryRequest;

import java.util.Optional;
import java.util.stream.Stream;

/**
 * Use this class to get an entry point for creating your own user entities that based on the
 * provided {@link UserEntity} class.
 */
public interface UserEntityFactory<T extends UserEntity> {

    //TODO: Make them all optional!
    T getUserEntity(int id);

    T getUserEntity(PasswordFactoryRequest passwordFactoryRequest);

    T getUserEntity(EmailFactoryRequest emailFactoryRequest);

    T getUserEntity(EmailAndPasswordFactoryRequest emailAndPasswordFactoryRequest);

    Optional<T> getUserEntity(String username);

    T newUserEntity(String username, String password, String email, boolean acceptNewsletter);

    /**
     * Return all of the users in a streamed fashion. You should close the stream after finishing the operations on it!
     *
     * @return a stream of all the users
     */
    Stream<T> getUserEntities();
}
