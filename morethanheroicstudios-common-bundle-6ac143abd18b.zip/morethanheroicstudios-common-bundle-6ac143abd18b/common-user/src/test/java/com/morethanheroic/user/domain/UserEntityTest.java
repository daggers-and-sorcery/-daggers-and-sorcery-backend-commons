package com.morethanheroic.user.domain;

import com.morethanheroic.user.domain.authorization.Role;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import java.util.HashSet;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

@Ignore
public class UserEntityTest {

    private UserEntity underTest;

    @Before
    public void setup() {
        final HashSet<Role> roles = new HashSet<>();

        roles.add(TestRole.USER);
        roles.add(TestRole.ADMIN);

        underTest = new UserEntity(
                123,
                "testuser",
                "testpassword",
                "testemail",
                true,
                new HashSet<>(roles)
        );
    }

    @Test
    public void testHasRoleWhenTheUserHasTheRole() {
        final boolean result = underTest.hasRole(TestRole.ADMIN);

        assertThat(result, is(true));
    }

    @Test
    public void testHasRoleWhenTheUserDoesntHaveTheRole() {
        final boolean result = underTest.hasRole(TestRole.OWNER);

        assertThat(result, is(false));
    }

    @Test
    public void testHasAnyRoleWhenTheUserHasTheRole() {
        final boolean result = underTest.hasAnyRole(TestRole.ADMIN, TestRole.OWNER);

        assertThat(result, is(true));
    }

    @Test
    public void testHasAnyRoleWhenTheUserDoesntHaveTheRole() {
        final boolean result = underTest.hasAnyRole(TestRole.SUPERUSER, TestRole.OWNER);

        assertThat(result, is(false));
    }

    private enum TestRole implements Role {
        ADMIN,
        USER,
        OWNER,
        SUPERUSER;

        @Override
        public String getId() {
            return name();
        }
    }
}