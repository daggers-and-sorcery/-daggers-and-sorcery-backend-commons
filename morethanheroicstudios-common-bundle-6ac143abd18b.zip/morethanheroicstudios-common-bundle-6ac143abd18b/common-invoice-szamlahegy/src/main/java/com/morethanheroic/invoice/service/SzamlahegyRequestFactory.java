package com.morethanheroic.invoice.service;

import com.morethanheroic.invoice.domain.Invoice;
import com.morethanheroic.invoice.domain.InvoiceType;
import com.morethanheroic.invoice.domain.customer.Customer;
import com.morethanheroic.invoice.domain.item.InvoiceItem;
import com.morethanheroic.invoice.service.configuration.SzamlahegyInvoiceConfigurationProperties;
import com.morethanheroic.invoice.service.domain.SzamlahegyRequest;
import com.morethanheroic.invoice.service.domain.SzamlahegyRequestInvoice;
import com.morethanheroic.invoice.service.domain.SzamlahegyRequestInvoiceItem;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class SzamlahegyRequestFactory {

    private final SzamlahegyInvoiceConfigurationProperties szamlahegyInvoiceProperties;

    public SzamlahegyRequest newRequest(final Invoice invoice) {
        final Customer customer = invoice.getCustomer();

        return SzamlahegyRequest.builder()
                .apiKey(szamlahegyInvoiceProperties.getApiKey())
                .invoice(
                        SzamlahegyRequestInvoice.builder()
                                .id(invoice.getId())
                                .type(calculateInvoiceType(invoice.getType()))
                                .items(
                                        invoice.getItems().stream()
                                                .map(item -> buildItem(invoice, item))
                                                .collect(Collectors.toList())
                                )
                                .header(invoice.getPrimaryMessage())
                                .footer(invoice.getSecondaryMessage())
                                .customerAddress(customer.getAddress())
                                .customerZip(customer.getZip())
                                .customerCity(customer.getCity())
                                .customerName(customer.getName())
                                .customerContactName(customer.getContactName())
                                .customerCountry(customer.getCountry())
                                .customerDetail(customer.getDetail())
                                .customerEmail(customer.getEmail())
                                .customerVatNumber(customer.getVatNumber())
                                .currency(invoice.getCurrency().getCurrencyCode())
                                .language(invoice.getLanguage().getLanguage())
                                .paymentDate(LocalDate.now().toString())
                                .performDate(LocalDate.now().toString())
                                .paymentMethod("B")
                                .signed("N")
                                .paidAt(LocalDate.now().toString())
                                .build()
                )
                .build();
    }

    private String calculateInvoiceType(final InvoiceType invoiceType) {
        switch (invoiceType) {
            case NORMAL:
                return "N";
            case CANCELLATION:
                return "S";
            case PREPAYMENT_REQUEST:
                return "D";
            case TEST:
                return "T";
            default:
                throw new RuntimeException("Unknown InvoiceType: " + invoiceType);
        }
    }

    private SzamlahegyRequestInvoiceItem buildItem(final Invoice invoice, final InvoiceItem invoiceItem) {
        return SzamlahegyRequestInvoiceItem.builder()
                .id(invoiceItem.getId())
                .itemId(invoiceItem.getId())
                .name(invoiceItem.getName())
                .description(invoiceItem.getDescription())
                .tax(String.valueOf(invoiceItem.getTax()))
                .quantityType(invoiceItem.getQuantityType())
                .currency(invoice.getCurrency().getCurrencyCode())
                .unitPrice(invoiceItem.getPrice().divide(new BigDecimal(String.valueOf(invoiceItem.getQuantity())), RoundingMode.HALF_UP).toPlainString())
                .quantity(String.valueOf(invoiceItem.getQuantity()))
                .build();
    }
}
