package com.morethanheroic.swagger.view.configuration;

import com.google.common.base.Predicates;
import com.google.common.collect.ImmutableList;
import com.morethanheroic.user.domain.UserEntity;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.bind.annotation.RequestMethod;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ResponseMessage;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.Collections;

@Configuration
@EnableSwagger2
public class SwaggerViewConfiguration {

    @Bean
    public Docket api() {
        return new Docket(DocumentationType.SWAGGER_2)
                .directModelSubstitute(LocalTime.class, String.class)
                .directModelSubstitute(LocalDate.class, String.class)
                .directModelSubstitute(LocalDateTime.class, String.class)
                .ignoredParameterTypes(UserEntity.class)
                .useDefaultResponseMessages(false)
                .globalResponseMessage(RequestMethod.GET, ImmutableList.of(
                        new ResponseMessage(200, "OK", null, Collections.emptyMap(), Collections.emptyList())
                ))
                .select()
                .apis(RequestHandlerSelectors.any())
                .paths(
                        Predicates.not(
                                Predicates.or(
                                        PathSelectors.regex("/actuator"),
                                        PathSelectors.regex("/actuator/.*"),
                                        PathSelectors.regex("/error")
                                )
                        )
                )
                .build();
    }
}
