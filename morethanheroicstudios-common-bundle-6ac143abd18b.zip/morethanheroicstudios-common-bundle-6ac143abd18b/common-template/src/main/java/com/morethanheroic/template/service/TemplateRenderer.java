package com.morethanheroic.template.service;

import com.morethanheroic.template.service.domain.TemplateRenderingContext;

public interface TemplateRenderer {

    String renderTemplate(TemplateRenderingContext templateRenderingContext);
}
