package com.morethanheroic.template.service.domain;

import java.util.Locale;
import java.util.Map;

public interface TemplateRenderingContext {

    Map<String, Object> getVariables();

    Locale getLocale();

    String getTemplateLocation();
}
