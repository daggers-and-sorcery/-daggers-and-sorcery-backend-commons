package com.morethanheroic.template.service.domain;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

import java.util.Collections;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

@RequiredArgsConstructor
public class DefaultTemplateRenderingContext implements TemplateRenderingContext {

    private final Map<String, Object> variables = new HashMap<>();

    @Getter
    private final Locale locale;

    @Getter
    private final String templateLocation;

    public void setVariable(final String parameterName, final Object parameterValue) {
        variables.put(parameterName, parameterValue);
    }

    @Override
    public Map<String, Object> getVariables() {
        return Collections.unmodifiableMap(variables);
    }
}
