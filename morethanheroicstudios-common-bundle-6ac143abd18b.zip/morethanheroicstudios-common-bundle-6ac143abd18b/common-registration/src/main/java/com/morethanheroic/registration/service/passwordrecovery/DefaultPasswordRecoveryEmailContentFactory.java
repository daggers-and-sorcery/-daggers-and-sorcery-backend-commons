package com.morethanheroic.registration.service.passwordrecovery;

import com.morethanheroic.application.configuration.ApplicationProperties;
import com.morethanheroic.registration.service.passwordrecovery.configuration.PasswordRecoveryEmailConfigurationProperties;
import com.morethanheroic.registration.service.passwordrecovery.domain.PasswordRecoveryEmailContent;
import com.morethanheroic.template.service.TemplateRenderer;
import com.morethanheroic.template.service.domain.DefaultTemplateRenderingContext;
import com.morethanheroic.user.domain.UserEntity;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Locale;

@Service
@RequiredArgsConstructor
public class DefaultPasswordRecoveryEmailContentFactory implements PasswordRecoveryEmailContentFactory {

    private final ApplicationProperties applicationProperties;
    private final PasswordRecoveryEmailConfigurationProperties passwordRecoveryEmailConfigurationProperties;
    private final TemplateRenderer templateRenderer;
    private final PasswordRecoveryUrlCalculator passwordRecoveryUrlCalculator;

    @Override
    public PasswordRecoveryEmailContent newPasswordRecoveryEmailContent(final UserEntity userEntity,
            final String passwordRecoveryId) {

        final DefaultTemplateRenderingContext templateRenderingContext = new DefaultTemplateRenderingContext(
                new Locale("hu", "HU"),
                passwordRecoveryEmailConfigurationProperties.getContentHtmlFile()
        );

        templateRenderingContext.setVariable("passwordRecoveryUrl",
                passwordRecoveryUrlCalculator.calculateVerificationUrl(passwordRecoveryId));

        return PasswordRecoveryEmailContent.builder()
                .to(userEntity.getEmail())
                .from(applicationProperties.getDefaultEmail())
                .subject(passwordRecoveryEmailConfigurationProperties.getTitle())
                .content(templateRenderer.renderTemplate(templateRenderingContext))
                .build();
    }
}
