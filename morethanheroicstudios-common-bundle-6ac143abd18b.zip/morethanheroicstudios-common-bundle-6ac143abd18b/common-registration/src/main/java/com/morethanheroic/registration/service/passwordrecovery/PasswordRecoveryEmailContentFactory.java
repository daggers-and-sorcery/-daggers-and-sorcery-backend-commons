package com.morethanheroic.registration.service.passwordrecovery;

import com.morethanheroic.registration.service.passwordrecovery.domain.PasswordRecoveryEmailContent;
import com.morethanheroic.user.domain.UserEntity;

public interface PasswordRecoveryEmailContentFactory {

    PasswordRecoveryEmailContent newPasswordRecoveryEmailContent(UserEntity userEntity, String passwordRecoveryId);
}
