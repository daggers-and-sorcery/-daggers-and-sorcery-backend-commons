package com.morethanheroic.registration.service.event.email;

import com.morethanheroic.email.service.EmailSender;
import com.morethanheroic.registration.service.event.RegistrationEventHandler;
import com.morethanheroic.registration.service.event.domain.RegistrationEventConfiguration;
import com.morethanheroic.registration.service.event.email.content.configuration.RegistrationVerificationEmailConfigurationProperties;
import com.morethanheroic.template.service.domain.DefaultTemplateRenderingContext;
import com.morethanheroic.user.domain.UserEntity;
import com.morethanheroic.verification.service.VerificationEntityFactory;
import com.morethanheroic.verification.service.domain.VerificationEntity;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Service;

import java.util.Locale;

@Slf4j
@Service
@RequiredArgsConstructor
@ConditionalOnProperty(name = "registration.verification-email.enabled", havingValue = "true")
public class EmailSenderRegistrationEventHandler extends RegistrationEventHandler {

    private final RegistrationVerificationEmailConfigurationProperties registrationVerificationEmailConfigurationProperties;
    private final VerificationEntityFactory verificationEntityFactory;
    private final EmailSender emailSender;

    @Override
    public void onEvent(final RegistrationEventConfiguration registrationEventConfiguration) {
        final UserEntity userEntity = registrationEventConfiguration.getUserEntity();

        log.info("Sending registration verification email to user " + userEntity.getId() + ".");

        final VerificationEntity verificationEntity = verificationEntityFactory.newVerificationEntity(userEntity);

        final DefaultTemplateRenderingContext templateRenderingContext = new DefaultTemplateRenderingContext(
                new Locale("hu", "HU"),
                registrationVerificationEmailConfigurationProperties.getContentHtmlFile()
        );
        templateRenderingContext.setVariable("verificationLink", verificationEntity.getVerificationUrl());

        emailSender.sendEmail(userEntity, registrationVerificationEmailConfigurationProperties.getTitle(),
                templateRenderingContext);
    }
}
