package com.morethanheroic.registration.service.response;

import com.morethanheroic.registration.service.response.domain.SuccessfulRegistrationResponseBuilderConfiguration;
import com.morethanheroic.response.domain.Response;
import com.morethanheroic.response.service.ResponseBuilder;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class SuccessfulRegistrationResponseBuilder implements ResponseBuilder<SuccessfulRegistrationResponseBuilderConfiguration> {

    private final SuccessfulRegistrationPartialResponseBuilder successfulRegistrationPartialResponseBuilder;

    @Override
    public Response build(SuccessfulRegistrationResponseBuilderConfiguration successfulRegistrationResponseBuilderConfiguration) {
        Response response = new Response();

        response.setData("registration", successfulRegistrationPartialResponseBuilder.build(successfulRegistrationResponseBuilderConfiguration));

        return response;
    }
}
