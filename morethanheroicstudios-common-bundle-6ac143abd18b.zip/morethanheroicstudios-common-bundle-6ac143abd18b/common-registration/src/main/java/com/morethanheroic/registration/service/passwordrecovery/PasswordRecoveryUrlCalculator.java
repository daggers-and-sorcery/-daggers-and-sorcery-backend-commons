package com.morethanheroic.registration.service.passwordrecovery;

import com.morethanheroic.application.configuration.ApplicationProperties;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class PasswordRecoveryUrlCalculator {

    private final ApplicationProperties applicationProperties;

    @Value("${registration.password-recovery-email.password-recovery-url-postfix:#!/password-recovery/{id}}")
    private String verificationUrlPostfix;

    public String calculateVerificationUrl(final String passwordRecoveryId) {
        return this.applicationProperties.getWebEndpoint() + verificationUrlPostfix.replace("{id}", passwordRecoveryId);
    }
}