package com.morethanheroic.registration.service.response;

import com.morethanheroic.registration.service.response.domain.UnsuccessfulRegistrationPartialResponse;
import com.morethanheroic.registration.service.response.domain.UnsuccessfulRegistrationResponseBuilderConfiguration;
import com.morethanheroic.response.domain.PartialResponse;
import com.morethanheroic.response.service.PartialResponseBuilder;
import com.morethanheroic.validation.domain.ValidationFieldError;
import com.morethanheroic.validation.domain.ValidationFieldResult;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@Service
public class UnsuccessfulRegistrationPartialResponseBuilder implements PartialResponseBuilder<UnsuccessfulRegistrationResponseBuilderConfiguration> {

    @Override
    public PartialResponse build(UnsuccessfulRegistrationResponseBuilderConfiguration loginResponseBuilderConfiguration) {
        List<String> errors = new ArrayList<>();

        for (ValidationFieldResult validationFieldResult : loginResponseBuilderConfiguration.getValidationResult().getValidationFieldResults()) {
            for (ValidationFieldError validationFieldError : validationFieldResult.getValidationFieldErrors()) {
                errors.add(validationFieldError.getError());
            }
        }

        return UnsuccessfulRegistrationPartialResponse.builder()
                .successful(false)
                .errors(Collections.unmodifiableList(errors))
                .build();
    }
}