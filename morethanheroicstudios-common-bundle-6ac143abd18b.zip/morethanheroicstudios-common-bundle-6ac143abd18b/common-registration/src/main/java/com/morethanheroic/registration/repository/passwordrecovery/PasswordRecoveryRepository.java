package com.morethanheroic.registration.repository.passwordrecovery;

import com.morethanheroic.registration.repository.passwordrecovery.domain.PasswordRecoveryDatabaseEntry;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

@Mapper
public interface PasswordRecoveryRepository {

    @Select("SELECT * FROM password_recovery WHERE recovery_id = #{recoveryId}")
    PasswordRecoveryDatabaseEntry findPasswordRecovery(@Param("recoveryId") String recoveryId);

    @Insert("INSERT INTO password_recovery SET user_id = #{userId}, recovery_id = #{recoveryId}")
    void insertPasswordRecovery(@Param("userId") int userId, @Param("recoveryId") String recoveryId);

    @Insert("DELETE FROM password_recovery WHERE user_id = #{userId}")
    void deletePasswordRecovery(@Param("userId") int userId);
}
