package com.morethanheroic.registration.view.passwordrecovery.request.domain;

import lombok.Data;

@Data
public class InitializePasswordRecoveryRequest {

    private String email;
}
