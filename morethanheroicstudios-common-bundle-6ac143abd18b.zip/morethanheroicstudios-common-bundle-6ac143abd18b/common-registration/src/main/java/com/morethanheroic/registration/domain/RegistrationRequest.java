package com.morethanheroic.registration.domain;

import com.morethanheroic.validation.constraints.unique.domain.UniqueInDatabaseTable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Setter
@Getter
@ApiModel(description = "Contains the data that's required for a valid registration.")
public class RegistrationRequest {

    @Size(min = 6, max = 16, message = "USERNAME_LENGTH_INVALID")
    @UniqueInDatabaseTable(table = "user", field = "username", message = "USERNAME_NOT_UNIQUE")
    @ApiModelProperty(value = "This attribute is not mandatory. If it's not sent then a 36 character long UUID will be "
            + "generated automatically.", allowEmptyValue = true)
    private String username;

    @Size(min = 6, max = 16, message = "PASSWORD_LENGTH_INVALID")
    @NotNull(message = "TECHNICAL_ERROR")
    @ApiModelProperty(required = true)
    private String password;

    @Size(min = 3, max = 256, message = "EMAIL_LENGTH_INVALID")
    @UniqueInDatabaseTable(table = "user", field = "email", message = "EMAIL_NOT_UNIQUE")
    @NotNull(message = "TECHNICAL_ERROR")
    @ApiModelProperty(required = true)
    private String email;

    @ApiModelProperty(value = "If the user want to accept newsletters or not.", allowEmptyValue = true)
    private boolean acceptNewsletter;
}
