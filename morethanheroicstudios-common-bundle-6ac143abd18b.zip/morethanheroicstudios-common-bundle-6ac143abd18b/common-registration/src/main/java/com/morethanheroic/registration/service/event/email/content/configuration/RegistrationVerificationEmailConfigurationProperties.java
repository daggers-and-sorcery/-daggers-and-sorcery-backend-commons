package com.morethanheroic.registration.service.event.email.content.configuration;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Data
@Component
@ConfigurationProperties("registration.verification-email")
public class RegistrationVerificationEmailConfigurationProperties {

    private boolean enabled;
    private String title;
    private String contentHtmlFile;
}
