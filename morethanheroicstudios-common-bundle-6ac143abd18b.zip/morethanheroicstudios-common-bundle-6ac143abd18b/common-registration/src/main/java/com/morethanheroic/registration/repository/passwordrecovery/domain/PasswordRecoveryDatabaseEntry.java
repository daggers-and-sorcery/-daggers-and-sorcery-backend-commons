package com.morethanheroic.registration.repository.passwordrecovery.domain;

import lombok.Data;

@Data
public class PasswordRecoveryDatabaseEntry {

    private int userId;
    private String recoveryId;
}
