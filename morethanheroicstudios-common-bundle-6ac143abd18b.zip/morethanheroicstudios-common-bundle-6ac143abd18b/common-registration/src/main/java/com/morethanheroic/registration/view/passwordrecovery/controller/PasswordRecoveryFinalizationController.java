package com.morethanheroic.registration.view.passwordrecovery.controller;

import com.morethanheroic.registration.repository.passwordrecovery.PasswordRecoveryRepository;
import com.morethanheroic.registration.repository.passwordrecovery.domain.PasswordRecoveryDatabaseEntry;
import com.morethanheroic.registration.view.passwordrecovery.request.domain.FinalizePasswordRecoveryRequest;
import com.morethanheroic.response.service.StatusResponseFactory;
import com.morethanheroic.response.service.domain.StatusResponse;
import com.morethanheroic.user.domain.UserEntity;
import com.morethanheroic.user.service.UserManipulator;
import com.morethanheroic.user.service.factory.UserEntityFactory;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
public class PasswordRecoveryFinalizationController {

    private final StatusResponseFactory statusResponseFactory;
    private final PasswordRecoveryRepository passwordRecoveryRepository;
    private final UserManipulator userManipulator;
    private final UserEntityFactory userEntityFactory;

    @PostMapping("/user/recovery/finalize/{recoveryId}")
    public StatusResponse finalizePasswordRecovery(
            @RequestBody final FinalizePasswordRecoveryRequest finalizePasswordRecoveryRequest,
            @PathVariable final String recoveryId
    ) {
        final PasswordRecoveryDatabaseEntry passwordRecoveryDatabaseEntry =
                passwordRecoveryRepository.findPasswordRecovery(recoveryId);

        if (passwordRecoveryDatabaseEntry != null) {
            final UserEntity userEntity = userEntityFactory.getUserEntity(passwordRecoveryDatabaseEntry.getUserId());

            userManipulator.updatePassword(userEntity, finalizePasswordRecoveryRequest.getPassword());
            passwordRecoveryRepository.deletePasswordRecovery(userEntity.getId());

            return statusResponseFactory.newSuccessfulResponse();
        }

        return statusResponseFactory.newUnsuccessfulResponse("Unknown recovery id!");
    }
}
