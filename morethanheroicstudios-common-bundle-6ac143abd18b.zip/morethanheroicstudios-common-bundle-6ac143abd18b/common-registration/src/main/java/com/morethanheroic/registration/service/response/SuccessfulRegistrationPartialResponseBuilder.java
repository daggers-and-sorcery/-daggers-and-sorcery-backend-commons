package com.morethanheroic.registration.service.response;

import com.morethanheroic.registration.service.response.domain.SuccessfulRegistrationPartialResponse;
import com.morethanheroic.registration.service.response.domain.SuccessfulRegistrationResponseBuilderConfiguration;
import com.morethanheroic.response.domain.PartialResponse;
import com.morethanheroic.response.service.PartialResponseBuilder;
import org.springframework.stereotype.Service;

@Service
public class SuccessfulRegistrationPartialResponseBuilder implements PartialResponseBuilder<SuccessfulRegistrationResponseBuilderConfiguration> {

    @Override
    public PartialResponse build(SuccessfulRegistrationResponseBuilderConfiguration loginResponseBuilderConfiguration) {
        return SuccessfulRegistrationPartialResponse.builder()
                .successful(true)
                .build();
    }
}
