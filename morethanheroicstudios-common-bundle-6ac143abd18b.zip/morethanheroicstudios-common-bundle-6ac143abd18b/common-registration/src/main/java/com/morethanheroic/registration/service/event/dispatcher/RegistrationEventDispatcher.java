package com.morethanheroic.registration.service.event.dispatcher;

import com.morethanheroic.event.EventDispatcher;
import com.morethanheroic.registration.service.event.RegistrationEventHandler;
import com.morethanheroic.registration.service.event.domain.RegistrationEventConfiguration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;

@Service
public class RegistrationEventDispatcher implements EventDispatcher<RegistrationEventConfiguration> {

    private final List<RegistrationEventHandler> registrationEventHandlers;

    public RegistrationEventDispatcher() {
        registrationEventHandlers = Collections.emptyList();
    }

    @Autowired(required = false)
    public RegistrationEventDispatcher(List<RegistrationEventHandler> registrationEventHandlers) {
        this.registrationEventHandlers = registrationEventHandlers;
    }

    @Override
    public void dispatch(RegistrationEventConfiguration registrationEventConfiguration) {
        for(RegistrationEventHandler registrationEventHandler : registrationEventHandlers) {
            registrationEventHandler.onEvent(registrationEventConfiguration);
        }
    }
}