package com.morethanheroic.registration.service;

import com.morethanheroic.registration.domain.RegistrationRequest;
import com.morethanheroic.registration.service.event.dispatcher.RegistrationEventDispatcher;
import com.morethanheroic.registration.service.event.domain.RegistrationEventConfiguration;
import com.morethanheroic.registration.service.response.SuccessfulRegistrationResponseBuilder;
import com.morethanheroic.registration.service.response.UnsuccessfulRegistrationResponseBuilder;
import com.morethanheroic.registration.service.response.domain.SuccessfulRegistrationResponseBuilderConfiguration;
import com.morethanheroic.registration.service.response.domain.UnsuccessfulRegistrationResponseBuilderConfiguration;
import com.morethanheroic.response.domain.Response;
import com.morethanheroic.user.domain.UserEntity;
import com.morethanheroic.user.service.factory.UserEntityFactory;
import com.morethanheroic.validation.domain.ValidationResult;
import com.morethanheroic.validation.service.ValidationFacade;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class RegistrationFacade {

    private final UserEntityFactory userEntityFactory;
    private final UnsuccessfulRegistrationResponseBuilder unsuccessfulRegistrationResponseBuilder;
    private final SuccessfulRegistrationResponseBuilder successfulRegistrationResponseBuilder;
    private final RegistrationEventDispatcher registrationEventDispatcher;
    private final ValidationFacade validationFacade;

    @Transactional
    public Response handleRegistrationRequest(RegistrationRequest registrationRequest) {
        final ValidationResult validationResult = validationFacade.validate(registrationRequest);

        if (!validationResult.isValid()) {
            return handleUnsuccessfulRegistrationRequest(validationResult);
        }

        return handleSuccessfulRegistrationRequest(registrationRequest);
    }

    private Response handleUnsuccessfulRegistrationRequest(ValidationResult validationResult) {
        return unsuccessfulRegistrationResponseBuilder.build(
                UnsuccessfulRegistrationResponseBuilderConfiguration.builder()
                        .validationResult(validationResult)
                        .build()
        );
    }

    private Response handleSuccessfulRegistrationRequest(RegistrationRequest registrationRequest) {
        final UserEntity userEntity = userEntityFactory.newUserEntity(registrationRequest.getUsername(),
                registrationRequest.getPassword(), registrationRequest.getEmail(),
                registrationRequest.isAcceptNewsletter());

        registrationEventDispatcher.dispatch(
                RegistrationEventConfiguration.builder()
                        .userEntity(userEntity)
                        .registrationRequest(registrationRequest)
                        .build()
        );

        return successfulRegistrationResponseBuilder.build(
                SuccessfulRegistrationResponseBuilderConfiguration.builder()
                        .build()
        );
    }
}
