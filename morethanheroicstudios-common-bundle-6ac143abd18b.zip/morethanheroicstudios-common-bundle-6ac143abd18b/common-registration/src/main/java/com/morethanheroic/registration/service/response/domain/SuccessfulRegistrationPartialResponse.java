package com.morethanheroic.registration.service.response.domain;

import com.morethanheroic.response.domain.PartialResponse;
import lombok.Builder;
import lombok.Getter;
import lombok.ToString;

@Builder
@Getter
@ToString
public class SuccessfulRegistrationPartialResponse extends PartialResponse {

    private boolean successful;
}
