package com.morethanheroic.registration.view.passwordrecovery.controller;

import com.morethanheroic.email.service.EmailSender;
import com.morethanheroic.email.service.domail.EmailMessage;
import com.morethanheroic.email.service.exception.EmailSendingException;
import com.morethanheroic.registration.repository.passwordrecovery.PasswordRecoveryRepository;
import com.morethanheroic.registration.service.passwordrecovery.PasswordRecoveryEmailContentFactory;
import com.morethanheroic.registration.service.passwordrecovery.domain.PasswordRecoveryEmailContent;
import com.morethanheroic.registration.view.passwordrecovery.request.domain.InitializePasswordRecoveryRequest;
import com.morethanheroic.response.service.StatusResponseFactory;
import com.morethanheroic.response.service.domain.StatusResponse;
import com.morethanheroic.user.domain.UserEntity;
import com.morethanheroic.user.service.factory.UserEntityFactory;
import com.morethanheroic.user.service.factory.domain.EmailFactoryRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.UUID;

@Slf4j
@RestController
@RequiredArgsConstructor
public class PasswordRecoveryInitializationController {

    private final StatusResponseFactory statusResponseFactory;
    private final UserEntityFactory userEntityFactory;
    private final PasswordRecoveryEmailContentFactory passwordRecoveryEmailContentFactory;
    private final PasswordRecoveryRepository passwordRecoveryRepository;
    private final EmailSender emailSender;

    @PostMapping("/user/recovery/initialize")
    public StatusResponse initializePasswordRecovery(
            @RequestBody final InitializePasswordRecoveryRequest initializePasswordRecoveryRequest) {
        final UserEntity userEntity = userEntityFactory.getUserEntity(
                EmailFactoryRequest.builder()
                        .email(initializePasswordRecoveryRequest.getEmail())
                        .build()
        );

        if (userEntity != null) {
            passwordRecoveryRepository.deletePasswordRecovery(userEntity.getId());

            final String passwordRecoveryId = UUID.randomUUID().toString();
            passwordRecoveryRepository.insertPasswordRecovery(userEntity.getId(), passwordRecoveryId);

            final PasswordRecoveryEmailContent passwordRecoveryEmailContent =
                    passwordRecoveryEmailContentFactory.newPasswordRecoveryEmailContent(userEntity, passwordRecoveryId);

            try {
                emailSender.sendEmail(
                        EmailMessage.builder()
                                .to(passwordRecoveryEmailContent.getTo())
                                .from(passwordRecoveryEmailContent.getFrom())
                                .subject(passwordRecoveryEmailContent.getSubject())
                                .content(passwordRecoveryEmailContent.getContent())
                                .build()
                );
            } catch (EmailSendingException e) {
                log.error("Unable to send password recovery email!", e);

                return statusResponseFactory.newUnsuccessfulResponse("Unable to send password recovery email!");
            }

            return statusResponseFactory.newSuccessfulResponse();
        }

        return statusResponseFactory.newUnsuccessfulResponse("Email address not registered!");
    }
}
