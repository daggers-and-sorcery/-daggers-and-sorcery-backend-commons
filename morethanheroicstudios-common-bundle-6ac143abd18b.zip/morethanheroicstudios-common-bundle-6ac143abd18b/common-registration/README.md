# Common Registration

This package provides a common way for adding the registration feature to a web application.

## Installation

Add this project as a dependency to the application and enable class path scanning for `com.morethanheroic.registration`.

### Enabling e-mail sending

If you want to enable e-mail sending on user registration then set up the `registration.verification-email.*` properties.

### Adding custom logic to successful registrations

If you want to run some custom logic on successful registrations please implement `com.morethanheroic.registration.service.event.RegistrationEventHandler`.
