# Common Payment

## Changelog

- ***2.0.0***
    - Moved to Spring Boot 2.
    - Added a `TypeHandler` for the `Currency` classes.
    - Added Spring auto-configuration for the package.