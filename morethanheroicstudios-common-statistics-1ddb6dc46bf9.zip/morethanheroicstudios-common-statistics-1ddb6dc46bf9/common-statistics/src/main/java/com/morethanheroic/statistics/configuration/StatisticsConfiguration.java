package com.morethanheroic.statistics.configuration;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@ComponentScan("com.morethanheroic.statistics")
@Configuration
public class StatisticsConfiguration {

}
