package com.morethanheroic.statistics.service;

import java.util.concurrent.atomic.AtomicLong;
import java.util.function.Consumer;

public class StatisticsCounterEntity {

    private final AtomicLong counter;
    private final Consumer<Long> callback;

    public StatisticsCounterEntity() {
        this(null);
    }

    public StatisticsCounterEntity(final Consumer<Long> callback) {
        this(0, callback);
    }

    public StatisticsCounterEntity(final long initialValue) {
        this(initialValue, null);
    }

    public StatisticsCounterEntity(final long initialValue, final Consumer<Long> callback) {
        counter = new AtomicLong(initialValue);
        this.callback = callback;
    }

    public long incrementAndGet() {
        final long newValue = counter.incrementAndGet();

        if (callback != null) {
            callback.accept(newValue);
        }

        return newValue;
    }
}
