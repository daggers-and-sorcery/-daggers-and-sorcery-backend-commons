package com.morethanheroic.statistics.service;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Consumer;

import org.springframework.stereotype.Service;

@Service
public class StatisticsCollector {

    private final Map<String, StatisticsCounterEntity> statisticsMap = new HashMap<>();

    public void registerStatisticsEntity(final String name) {
        statisticsMap.put(name, new StatisticsCounterEntity());
    }

    public void registerStatisticsEntity(final String name, final Consumer<Long> callback) {
        statisticsMap.put(name, new StatisticsCounterEntity(callback));
    }

    public long incrementAndGet(final String name) {
        return statisticsMap.get(name).incrementAndGet();
    }

    public long registerOrIncrementAndGet(final String name) {
        if (!statisticsMap.containsKey(name)) {
            this.registerStatisticsEntity(name);
        }

        return statisticsMap.get(name).incrementAndGet();
    }

    public long registerOrIncrementAndGet(final String name, final Consumer<Long> callback) {
        if (!statisticsMap.containsKey(name)) {
            this.registerStatisticsEntity(name, callback);
        }

        return statisticsMap.get(name).incrementAndGet();
    }
}
