# Common Statistics

The common statistics plugin allows the application to collect statistics about it's runtime and run callbacks after every collection points.

## Changelog

- ***1.1.0***
    - Moved from int based counting to a long one.
- ***1.0.0***
    - Initial release.