package com.morethanheroic.registration.service.event.domain;

import com.morethanheroic.event.EventConfiguration;
import com.morethanheroic.registration.domain.RegistrationRequest;
import com.morethanheroic.user.domain.UserEntity;
import lombok.Builder;
import lombok.Getter;
import lombok.ToString;

@Builder
@Getter
@ToString
public class RegistrationEventConfiguration implements EventConfiguration {

    private final UserEntity userEntity;
    private final RegistrationRequest registrationRequest;
}
