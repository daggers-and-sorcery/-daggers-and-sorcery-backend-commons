package com.morethanheroic.registration.service.passwordrecovery.configuration;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Data
@Component
@ConfigurationProperties("registration.password-recovery-email")
public class PasswordRecoveryEmailConfigurationProperties {

    private String title;
    private String contentHtmlFile;
    private String passwordRecoveryUrlPostfix;
}
