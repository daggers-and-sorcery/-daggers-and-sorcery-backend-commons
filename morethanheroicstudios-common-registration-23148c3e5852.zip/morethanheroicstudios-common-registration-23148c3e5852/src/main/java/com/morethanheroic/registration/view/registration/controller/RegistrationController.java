package com.morethanheroic.registration.view.registration.controller;

import com.morethanheroic.registration.domain.RegistrationRequest;
import com.morethanheroic.registration.service.RegistrationFacade;
import com.morethanheroic.response.domain.Response;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
@Api(description = "Registration endpoint for the users.")
public class RegistrationController {

    private final RegistrationFacade registrationFacade;

    @PostMapping("/user/registration")
    @ApiOperation("Registers an user. Create it in the database, send a verification email by default.")
    public Response registration(@RequestBody final RegistrationRequest registrationRequest) {
        return registrationFacade.handleRegistrationRequest(registrationRequest);
    }
}
