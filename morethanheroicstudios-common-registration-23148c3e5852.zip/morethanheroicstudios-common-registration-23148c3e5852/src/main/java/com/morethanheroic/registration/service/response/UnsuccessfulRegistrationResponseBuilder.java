package com.morethanheroic.registration.service.response;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.morethanheroic.registration.service.response.domain.UnsuccessfulRegistrationResponseBuilderConfiguration;
import com.morethanheroic.response.domain.Response;
import com.morethanheroic.response.service.ResponseBuilder;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor(onConstructor = @__(@Autowired) )
public class UnsuccessfulRegistrationResponseBuilder implements ResponseBuilder<UnsuccessfulRegistrationResponseBuilderConfiguration> {

    private final UnsuccessfulRegistrationPartialResponseBuilder unsuccessfulRegistrationPartialResponseBuilder;

    @Override
    public Response build(UnsuccessfulRegistrationResponseBuilderConfiguration unsuccessfulRegistrationResponseBuilderConfiguration) {
        Response response = new Response();

        response.setData("registration", unsuccessfulRegistrationPartialResponseBuilder.build(unsuccessfulRegistrationResponseBuilderConfiguration));

        return response;
    }
}
