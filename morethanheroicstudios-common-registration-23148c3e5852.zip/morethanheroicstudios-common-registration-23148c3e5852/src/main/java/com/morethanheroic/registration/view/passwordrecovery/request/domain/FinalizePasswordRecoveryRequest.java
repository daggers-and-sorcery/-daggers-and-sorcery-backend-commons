package com.morethanheroic.registration.view.passwordrecovery.request.domain;

import lombok.Data;

@Data
public class FinalizePasswordRecoveryRequest {

    private String password;
}
