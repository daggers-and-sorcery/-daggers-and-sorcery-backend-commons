package com.morethanheroic.registration.service.response.domain;

import com.morethanheroic.response.domain.PartialResponse;
import lombok.Builder;
import lombok.Getter;
import lombok.ToString;

import java.util.List;

@Builder
@Getter
@ToString
public class UnsuccessfulRegistrationPartialResponse extends PartialResponse {

    private final boolean successful;
    private final List<String> errors;
}
