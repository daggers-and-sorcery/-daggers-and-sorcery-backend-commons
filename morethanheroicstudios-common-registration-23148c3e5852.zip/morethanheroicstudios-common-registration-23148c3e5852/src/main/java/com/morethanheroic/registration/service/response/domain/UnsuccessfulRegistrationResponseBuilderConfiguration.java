package com.morethanheroic.registration.service.response.domain;

import com.morethanheroic.response.service.ResponseBuilderConfiguration;
import com.morethanheroic.validation.domain.ValidationResult;
import lombok.Builder;
import lombok.Getter;
import lombok.ToString;

@Builder
@Getter
@ToString
public class UnsuccessfulRegistrationResponseBuilderConfiguration implements ResponseBuilderConfiguration {

    private final ValidationResult validationResult;
}
