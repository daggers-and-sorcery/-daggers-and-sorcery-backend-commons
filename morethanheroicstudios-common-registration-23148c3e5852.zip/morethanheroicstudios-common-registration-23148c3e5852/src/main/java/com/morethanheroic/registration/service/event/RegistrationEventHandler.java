package com.morethanheroic.registration.service.event;

import com.morethanheroic.event.EventHandler;
import com.morethanheroic.registration.service.event.domain.RegistrationEventConfiguration;

/**
 * Handle successful registration events here.
 */
public abstract class RegistrationEventHandler implements EventHandler<RegistrationEventConfiguration> {
}