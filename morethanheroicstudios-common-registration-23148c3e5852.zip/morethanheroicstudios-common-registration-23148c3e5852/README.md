# Common Registration

This package provides a common way for adding the registration feature to a web application.

## Installation

Add this project as a dependency to the application and enable class path scanning for `com.morethanheroic.registration`.

### Enabling e-mail sending

If you want to enable e-mail sending on user registration then set up the `registration.verification-email.*` properties.

### Adding custom logic to successful registrations

If you want to run some custom logic on successful registrations please implement `com.morethanheroic.registration.service.event.RegistrationEventHandler`.

## Changelog

- ***1.3.7***
    - Reworked the PasswordRecoveryFinalizationController to use StatusResponse.
- ***1.3.6***
    - Added a password recovery url generator for automatic password recovery url creation.
- ***1.3.5***
    - Added a default implementation for PasswordRecoveryEmailContentFactory.
- ***1.3.4***
    - Fixed that traces of the previous password recovery was not cleaned from the database.
- ***1.3.3***
    - Updated the common-verification dependency.
    - Improved logging in EmailSenderRegistrationEventHandler.
- ***1.3.2***
    - Fixed a bug in the EmailEventHandler.
- ***1.3.1***
    - Fixed a bad property in a @ConditionalOnProperty annotation.
- ***1.3.0***
    - Updated the common-verification and the common-email modules.
    - Using the new generation e-mail sending (removed self-rendering of the verification emails).
- ***1.2.13***
    - Removed the username from the password recovery flow.
- ***1.2.12***
    - Use the `VerificationEmailRendered` from the common-verification module to render the verification email instead of our own logic.
- ***1.2.11***
    - Updated to `common-verification` 1.2.0.
- ***1.2.10***
    - Added the `DefaultRegistrationEmailContentFactory`.
- ***1.2.9***
    - Added a few extra constraints on the RegistrationRequest and added some additional API documentation.
- ***1.2.8***
    - Added model annotations to the `RegistrationRequest`.
- ***1.2.7***
    - Removed the `@Builder` from the `RegistrationRequest`.
- ***1.2.6***
    - Small fixes and improvements. Added setters to the `RegistrationRequest`.
- ***1.2.5***
    - Updating Spring Boot version to 2.0.0.RELEASE.
- ***1.2.4***
    - Added the finalization part of the password recovery functionality.
- ***1.2.3***
    - Added the password recovery functionality.
- ***1.2.2***
    - Updating the email dependency to allow HTML emails.
- ***1.2.1***
    - Fixed a bug that allowed non-unique emails at registration.
- ***1.2.0***
    - Added support for the registration email sending.