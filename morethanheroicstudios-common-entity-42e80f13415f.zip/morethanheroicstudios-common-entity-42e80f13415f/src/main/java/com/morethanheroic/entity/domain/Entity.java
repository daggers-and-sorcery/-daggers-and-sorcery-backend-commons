package com.morethanheroic.entity.domain;

public interface Entity {

    int getId();
}
