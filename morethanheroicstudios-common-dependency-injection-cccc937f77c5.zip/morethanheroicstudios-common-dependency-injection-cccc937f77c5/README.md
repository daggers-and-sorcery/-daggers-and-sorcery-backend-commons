# Common Dependency Injection

## Changelog

- ***1.0.3***
    - Updated project lombok to a compile only dependency.
    - Updated Spring Boot version to 2.1.2.RELEASE.