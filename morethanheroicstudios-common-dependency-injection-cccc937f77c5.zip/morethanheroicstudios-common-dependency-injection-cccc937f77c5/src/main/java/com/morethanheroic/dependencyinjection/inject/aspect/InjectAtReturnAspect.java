package com.morethanheroic.dependencyinjection.inject.aspect;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

@Aspect
@Component
@Order
@Slf4j
@RequiredArgsConstructor
public class InjectAtReturnAspect {

    private final AutowireCapableBeanFactory autowireBeanFactory;

    @Around("@annotation(com.morethanheroic.dependencyinjection.inject.InjectAtReturn)")
    @SuppressWarnings("checkstyle:illegalthrows")
    public Object injectAtReturn(ProceedingJoinPoint proceedingJoinPoint) throws Throwable {
        final Object result = proceedingJoinPoint.proceed();

        if (result == null) {
            return null;
        }

        log.debug("Autowiring: " + result);

        autowireBeanFactory.autowireBean(result);
        autowireBeanFactory.initializeBean(result, null);

        return result;
    }
}
