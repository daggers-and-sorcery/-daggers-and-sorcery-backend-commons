# Common Game

Contains logic that are commonly used in games, especially in role-playing games (like drops).

## Changelog

- ***1.1.1***
    - Added a method that could calculate a random drop from two drop definitions.
- ***1.1.0***
    - Reworked the factory package (breaking changes).
    - Moved the drop definition domain under the factory.
- ***1.0.0***
    - Initial release.
    - Added the drop calculation logic.