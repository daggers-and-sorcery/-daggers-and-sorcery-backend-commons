package com.morethanheroic.game.drop.service;

import com.morethanheroic.game.drop.service.factory.definition.domain.DefaultDropDefinition;
import com.morethanheroic.game.drop.service.factory.entity.DropEntityFactory;
import com.morethanheroic.game.drop.service.factory.entity.domain.DropEntity;
import com.morethanheroic.math.service.PercentageCalculator;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Provide various ways to calculate drops randomly.
 */
@Service
@RequiredArgsConstructor
public class DropCalculator {

    private final PercentageCalculator percentageCalculator;
    private final DropEntityFactory dropEntityFactory;

    /**
     * Calculate what kinds of drops should someone acquire from a pile of drop definitions. Used for example when a
     * monster dies and it's drops should be calculated.
     *
     * @param dropEntities the definitions to calculate the drops from
     * @return the result drops
     */
    public List<DropEntity> calculateDrops(final List<DefaultDropDefinition> dropEntities) {
        return Collections.unmodifiableList(
                dropEntities.stream()
                        .filter(dropDefinition ->
                                percentageCalculator.calculateUnderPercentage(dropDefinition.getChance()))
                        .map(dropEntityFactory::getDropEntity)
                        .collect(Collectors.toList())
        );
    }

    /**
     * Choose a drop randomly from the two provided. The chance is disregarded on both definitions and there are a 50%
     * chance for each drop to be the chosen one.
     *
     * @param firstDrop  the first possible drop
     * @param secondDrop the second possible drop
     * @return the chosen drop
     */
    public DropEntity chooseOneRandomly(final DefaultDropDefinition firstDrop, final DefaultDropDefinition secondDrop) {
        if (percentageCalculator.calculatePercentageHit(50)) {
            return dropEntityFactory.getDropEntity(firstDrop);
        }

        return dropEntityFactory.getDropEntity(secondDrop);
    }
}
