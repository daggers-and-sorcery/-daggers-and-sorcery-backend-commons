package com.morethanheroic.game.drop.service.factory.definition;

import org.springframework.stereotype.Service;

@Service
public interface DropDefinitionFactory {
}
