package com.morethanheroic.game.drop.service.factory.definition;

import com.morethanheroic.game.drop.service.factory.definition.domain.DefaultDropDefinition;
import com.morethanheroic.game.drop.service.factory.definition.domain.DropDefinition;
import com.morethanheroic.game.item.service.domain.ItemDefinition;
import org.springframework.stereotype.Service;

@Service
public class DefaultDropDefinitionFactory implements DropDefinitionFactory {

    public DropDefinition getDropDefinition(final ItemDefinition itemDefinition, final double chance,
        final int minimumAmount, final int maximumAmount) {

        return DefaultDropDefinition.builder()
                .item(itemDefinition)
                .chance(chance)
                .minimumAmount(minimumAmount)
                .maximumAmount(maximumAmount)
                .build();
    }
}
