package com.morethanheroic.game.drop.service.factory.definition.domain;

import com.morethanheroic.game.item.service.domain.ItemDefinition;

public interface DropDefinition {

    ItemDefinition getItem();

    int getMinimumAmount();

    int getMaximumAmount();

    double getChance();
}
