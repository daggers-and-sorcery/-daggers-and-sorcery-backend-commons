package com.morethanheroic.game.drop.service.factory.entity;

import com.morethanheroic.game.drop.service.factory.definition.domain.DropDefinition;
import com.morethanheroic.game.drop.service.factory.entity.domain.DefaultDropEntity;
import com.morethanheroic.game.drop.service.factory.entity.domain.DropEntity;
import com.morethanheroic.game.item.service.domain.ItemDefinition;
import com.morethanheroic.math.service.RandomCalculator;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class DefaultDropEntityFactory implements DropEntityFactory {

    private final RandomCalculator randomCalculator;

    @Override
    public DropEntity getDropEntity(DropDefinition dropDefinition) {
        final int amount = randomCalculator.randomNumberBetween(dropDefinition.getMinimumAmount(),
                dropDefinition.getMaximumAmount());

        return getDropEntity(dropDefinition.getItem(), amount);
    }

    @Override
    public DropEntity getDropEntity(final ItemDefinition itemDefinition, final int amount) {
        return DefaultDropEntity.builder()
                .item(itemDefinition)
                .amount(amount)
                .build();
    }
}
