package com.morethanheroic.game.drop.service.factory.entity.domain;

import com.morethanheroic.game.item.service.domain.ItemDefinition;
import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class DefaultDropEntity implements DropEntity {

    private final ItemDefinition item;
    private final int amount;
    private final double chance;
}
