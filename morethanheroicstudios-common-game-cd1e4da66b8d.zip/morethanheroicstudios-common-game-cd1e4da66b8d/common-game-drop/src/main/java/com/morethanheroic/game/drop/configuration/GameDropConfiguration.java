package com.morethanheroic.game.drop.configuration;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("com.morethanheroic.game.drop")
public class GameDropConfiguration {
}
