package com.morethanheroic.game.drop.service.factory.entity;

import com.morethanheroic.game.drop.service.factory.definition.domain.DropDefinition;
import com.morethanheroic.game.drop.service.factory.entity.domain.DropEntity;
import com.morethanheroic.game.item.service.domain.ItemDefinition;

public interface DropEntityFactory {

    DropEntity getDropEntity(ItemDefinition itemDefinition, int amount);

    DropEntity getDropEntity(DropDefinition dropDefinition);
}
