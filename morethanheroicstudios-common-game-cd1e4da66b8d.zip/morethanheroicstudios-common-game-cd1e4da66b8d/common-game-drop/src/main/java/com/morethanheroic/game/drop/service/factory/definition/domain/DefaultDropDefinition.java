package com.morethanheroic.game.drop.service.factory.definition.domain;

import com.morethanheroic.game.item.service.domain.ItemDefinition;
import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class DefaultDropDefinition implements DropDefinition {

    private final ItemDefinition item;
    private final int minimumAmount;
    private final int maximumAmount;
    private final double chance;
}
