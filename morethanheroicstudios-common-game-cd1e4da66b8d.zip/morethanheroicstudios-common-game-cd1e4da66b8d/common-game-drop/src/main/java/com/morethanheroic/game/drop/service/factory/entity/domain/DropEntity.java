package com.morethanheroic.game.drop.service.factory.entity.domain;

import com.morethanheroic.game.item.service.domain.ItemDefinition;

public interface DropEntity {

    ItemDefinition getItem();

    int getAmount();
}
