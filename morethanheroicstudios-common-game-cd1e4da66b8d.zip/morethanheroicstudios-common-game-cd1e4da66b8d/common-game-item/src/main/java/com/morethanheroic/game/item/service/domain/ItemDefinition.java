package com.morethanheroic.game.item.service.domain;

public interface ItemDefinition {

    int getId();
}
