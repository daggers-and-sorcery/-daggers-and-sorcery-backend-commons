package com.morethanheroic.validation.domain;

import lombok.Builder;
import lombok.Getter;
import lombok.ToString;

import javax.validation.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

@Builder
@ToString
@Getter
public class ValidationResult {

    private final boolean isValid;
    private final List<ValidationFieldResult> validationFieldResults;
}
