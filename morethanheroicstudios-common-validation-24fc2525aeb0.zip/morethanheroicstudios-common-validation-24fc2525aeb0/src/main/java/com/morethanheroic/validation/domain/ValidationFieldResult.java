package com.morethanheroic.validation.domain;

import lombok.Builder;
import lombok.Getter;
import lombok.ToString;

import javax.validation.Path;
import java.util.List;

@ToString
@Getter
@Builder
public class ValidationFieldResult {

    private final boolean isValid;
    private final Path path;
    private final List<ValidationFieldError> validationFieldErrors;
}
