package com.morethanheroic.filerepository.service.event.domain;

import com.morethanheroic.event.EventConfiguration;
import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class FileRepositoryEventConfiguration implements EventConfiguration {

    private final String filePath;
    private final String fileName;
    private final EventType eventType;
    private final FileRepositoryOperationResult operationResult;
}
