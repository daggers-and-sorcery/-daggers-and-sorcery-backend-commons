package com.morethanheroic.filerepository.service.event.domain;

public enum FileRepositoryOperationResult {

    SUCCESSFUL_OPERATION,
    FAILED_OPERATION
}
