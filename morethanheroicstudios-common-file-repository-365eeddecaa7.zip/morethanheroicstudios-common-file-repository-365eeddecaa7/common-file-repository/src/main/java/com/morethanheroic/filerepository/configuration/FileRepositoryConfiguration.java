package com.morethanheroic.filerepository.configuration;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("com.morethanheroic.filerepository")
public class FileRepositoryConfiguration {
}
