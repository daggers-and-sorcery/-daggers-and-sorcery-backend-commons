package com.morethanheroic.filerepository.configuration;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Data
@Component
@ConfigurationProperties("file-repository")
public class FileRepositoryProperties {

  private String provider;
}
