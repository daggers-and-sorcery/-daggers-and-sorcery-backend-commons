package com.morethanheroic.filerepository.service.event.domain;

public enum EventType {

    INSERT
}
