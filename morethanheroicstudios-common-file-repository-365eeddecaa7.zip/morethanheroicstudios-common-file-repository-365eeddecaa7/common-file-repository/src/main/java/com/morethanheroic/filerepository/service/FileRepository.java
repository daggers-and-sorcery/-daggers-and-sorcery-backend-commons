package com.morethanheroic.filerepository.service;

import com.morethanheroic.filerepository.service.domain.FileMetadata;

import java.io.File;
import java.io.InputStream;

/**
 * This class could be used to manipulate a file repository. These files can be stored anywhere. The
 * exact location of the stored file data is implementation specific.
 */
public interface FileRepository {

    void writeFile(String filePath, String fileName, InputStream fileData,
                   FileMetadata fileMetadata);

    void writeFile(String filePath, String fileName, File file);

    InputStream readFile(String filePath, String fileName);
}
