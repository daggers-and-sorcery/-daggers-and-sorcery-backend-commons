package com.morethanheroic.filerepository.service.domain;

import com.morethanheroic.filerepository.service.FileRepository;

/**
 * Contains additional metadata about a content stored in a
 * {@link FileRepository}.
 */
public interface FileMetadata {

    String getContentType();

    int getLength();
}
