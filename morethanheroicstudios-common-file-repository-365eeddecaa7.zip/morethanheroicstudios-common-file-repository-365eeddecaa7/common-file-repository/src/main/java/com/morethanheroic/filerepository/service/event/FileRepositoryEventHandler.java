package com.morethanheroic.filerepository.service.event;

import com.morethanheroic.event.EventHandler;
import com.morethanheroic.filerepository.service.event.domain.FileRepositoryEventConfiguration;

public abstract class FileRepositoryEventHandler implements EventHandler<FileRepositoryEventConfiguration> {

}
