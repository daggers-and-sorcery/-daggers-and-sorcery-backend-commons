package com.morethanheroic.filerepository.service.event;

import com.morethanheroic.event.EventDispatcher;
import com.morethanheroic.filerepository.service.event.domain.FileRepositoryEventConfiguration;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;

@Service
public class FileRepositoryEventDispatcher implements EventDispatcher<FileRepositoryEventConfiguration> {

    private final List<FileRepositoryEventHandler> fileRepositoryEventHandlers;

    public FileRepositoryEventDispatcher(
            @Autowired(required = false) final List<FileRepositoryEventHandler> eventHandlers) {
        if (eventHandlers == null) {
            fileRepositoryEventHandlers = Collections.emptyList();
        } else {
            fileRepositoryEventHandlers = eventHandlers;
        }
    }

    @Override
    public void dispatch(final FileRepositoryEventConfiguration eventConfiguration) {
        fileRepositoryEventHandlers
                .forEach(fileRepositoryEventHandler -> fileRepositoryEventHandler.onEvent(eventConfiguration));
    }
}
