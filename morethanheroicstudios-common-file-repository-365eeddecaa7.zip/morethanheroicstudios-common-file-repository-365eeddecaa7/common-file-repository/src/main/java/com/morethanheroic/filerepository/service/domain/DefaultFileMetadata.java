package com.morethanheroic.filerepository.service.domain;

import lombok.Builder;
import lombok.Getter;
import lombok.ToString;

@Getter
@Builder
@ToString
public class DefaultFileMetadata implements FileMetadata {

    private final String contentType;

    @Builder.Default
    private final int length = -1;
}
