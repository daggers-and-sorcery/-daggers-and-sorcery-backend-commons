# Common File Repository

This package provides a common way for manipulating chunks of file data hosted somewhere like on disk, USB device or on a cloud provider like AWS.

## Installation

Add this project as a dependency. The bean registration will be done automatically.

## Usage

Configure the chosen repository type and inject the `FileRepository`.

### Events

The repositories will dispatch events after each repository call. To listen to these events extend the `FileRepositoryEventHandler` class.

## Changelog

- ***1.2.0***
    - Replaced `FileRepository.insertFile(...)` with `FileRepository.writeFile(...)`. This is a breaking change but only the name of the method was changed.
    - Added `FileRepository.readFile(...)` to be able to read files from AWS.
    - The beans in this module will be regiestered automatially in the future.
- ***1.1.6***
    - Added optional content length support.
- ***1.1.5***
    - Added logs to the AWS file repository manager.
- ***1.1.4***
    - Only allow either an endpoint or a region to be set for the AWS repository.
- ***1.1.3***
    - Made the `FileRepositoryEventHandler` a non-mandatory component to implement when using this module.
- ***1.1.2***
    - Added a configuration property to set the endpoint of the AWS S3 repository so we can use non AWS services that support the S3 protocol.
- ***1.1.1***
    - Updating version numbers.
- ***1.1.0***
    - Added file repository events.
- ***1.0.2***
    - Renamed the library from common-content-repository to common-file-repository.
- ***1.0.1***
    - Added multiple small fixes. Updating to this version is mandatory to make this dependency work.
- ***1.0.0***
    - Initial release with AWS S3 support.




