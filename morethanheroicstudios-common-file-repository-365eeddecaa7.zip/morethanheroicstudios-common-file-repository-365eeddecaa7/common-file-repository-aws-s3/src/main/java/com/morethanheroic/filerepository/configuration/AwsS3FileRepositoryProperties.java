package com.morethanheroic.filerepository.configuration;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Data
@Component
@ConfigurationProperties("file-repository.provider.aws-s3")
public class AwsS3FileRepositoryProperties {

  private String region;
  private String endpoint;
  private String bucketName;
  private String accessKey;
  private String secretKey;
}
