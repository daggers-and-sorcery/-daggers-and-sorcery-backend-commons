package com.morethanheroic.filerepository.service;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.morethanheroic.filerepository.configuration.AwsS3FileRepositoryProperties;
import com.morethanheroic.filerepository.service.domain.FileMetadata;
import com.morethanheroic.filerepository.service.event.FileRepositoryEventDispatcher;
import com.morethanheroic.filerepository.service.event.domain.EventType;
import com.morethanheroic.filerepository.service.event.domain.FileRepositoryEventConfiguration;
import com.morethanheroic.filerepository.service.event.domain.FileRepositoryOperationResult;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.InputStream;

@Slf4j
@Service
@RequiredArgsConstructor
@ConditionalOnProperty(name = "file-repository.provider", havingValue = "aws-s3")
public class AwsS3FileRepository implements FileRepository {

    private final AmazonS3 amazonS3Client;
    private final AwsS3FileRepositoryProperties awsS3FileRepositoryProperties;
    private final FileRepositoryEventDispatcher fileRepositoryEventDispatcher;

    @Override
    public void writeFile(final String filePath, final String fileName, final InputStream fileData,
                          final FileMetadata fileMetadata) {
        log.debug("Initializing file upload to an AWS based file repository! Target filename: " + fileName
                + " target path: " + filePath + " file metadata: " + fileMetadata + " target bucket: "
                + awsS3FileRepositoryProperties.getBucketName() + ".");

        try {
            amazonS3Client.putObject(awsS3FileRepositoryProperties.getBucketName(),
                    filePath + fileName, fileData, buildObjectMetadata(fileMetadata));
        } catch (Exception e) {
            log.error("Failed to upload payload to AWS based file repository! Target filename: " + fileName
                    + " target path: " + filePath + " file metadata: " + fileMetadata + " target bucket: "
                    + awsS3FileRepositoryProperties.getBucketName() + ".");

            dispatchEvent(fileName, filePath, FileRepositoryOperationResult.FAILED_OPERATION);

            throw e;
        }

        dispatchEvent(fileName, filePath, FileRepositoryOperationResult.SUCCESSFUL_OPERATION);
    }

    @Override
    public void writeFile(final String filePath, final String fileName, final File file) {
        try {
            amazonS3Client.putObject(awsS3FileRepositoryProperties.getBucketName(),
                    filePath + fileName, file);
        } catch (Exception e) {
            dispatchEvent(fileName, filePath, FileRepositoryOperationResult.FAILED_OPERATION);

            throw e;
        }

        dispatchEvent(fileName, filePath, FileRepositoryOperationResult.SUCCESSFUL_OPERATION);
    }

    @Override
    public InputStream readFile(final String filePath, final String fileName) {
        return amazonS3Client.getObject(awsS3FileRepositoryProperties.getBucketName(), filePath + fileName)
                .getObjectContent();
    }

    private ObjectMetadata buildObjectMetadata(final FileMetadata fileMetadata) {
        final ObjectMetadata objectMetadata = new ObjectMetadata();

        if (fileMetadata.getLength() > -1) {
            objectMetadata.setContentLength(fileMetadata.getLength());
        }

        objectMetadata.setContentType(fileMetadata.getContentType());

        return objectMetadata;
    }

    private void dispatchEvent(final String fileName, final String filePath,
                               final FileRepositoryOperationResult fileRepositoryOperationResult) {
        fileRepositoryEventDispatcher.dispatch(
                FileRepositoryEventConfiguration.builder()
                        .fileName(fileName)
                        .filePath(filePath)
                        .eventType(EventType.INSERT)
                        .operationResult(fileRepositoryOperationResult)
                        .build()
        );
    }
}
