package com.morethanheroic.filerepository.configuration;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.client.builder.AwsClientBuilder;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@RequiredArgsConstructor
public class AwsS3FileRepositoryConfiguration {

    private final AwsS3FileRepositoryProperties awsS3FileRepositoryProperties;

    @Bean
    public AmazonS3 amazonS3Client(final AWSStaticCredentialsProvider awsStaticCredentialsProvider) {
        final AmazonS3ClientBuilder builder = AmazonS3ClientBuilder.standard()
                .withCredentials(awsStaticCredentialsProvider);

        if (awsS3FileRepositoryProperties.getEndpoint() != null) {
            builder.withEndpointConfiguration(new AwsClientBuilder.EndpointConfiguration(
                    awsS3FileRepositoryProperties.getEndpoint(), awsS3FileRepositoryProperties.getRegion())
            );
        } else {
            builder.withRegion(awsS3FileRepositoryProperties.getRegion());
        }

        return builder.build();
    }

    @Bean
    protected AWSStaticCredentialsProvider awsStaticCredentialsProvider(final AWSCredentials awsCredentials) {
        return new AWSStaticCredentialsProvider(awsCredentials);
    }

    @Bean
    protected AWSCredentials awsCredentials() {
        return new BasicAWSCredentials(awsS3FileRepositoryProperties.getAccessKey(),
                awsS3FileRepositoryProperties.getSecretKey());
    }
}
