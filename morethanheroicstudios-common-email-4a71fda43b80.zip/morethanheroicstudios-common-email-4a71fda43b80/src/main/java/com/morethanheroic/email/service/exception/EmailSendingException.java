package com.morethanheroic.email.service.exception;

public class EmailSendingException extends RuntimeException {

    public EmailSendingException(final String message, final Throwable throwable) {
        super(message, throwable);
    }
}
