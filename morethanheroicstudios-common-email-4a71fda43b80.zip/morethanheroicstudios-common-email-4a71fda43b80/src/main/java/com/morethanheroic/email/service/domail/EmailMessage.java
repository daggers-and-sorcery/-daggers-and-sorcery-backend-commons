package com.morethanheroic.email.service.domail;

import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class EmailMessage {

  private final String from;
  private final String to;
  private final String subject;
  private final String content;
}
