package com.morethanheroic.office.excel.service.cell.domain.value;

import lombok.Builder;
import lombok.Getter;
import org.apache.poi.ss.usermodel.RichTextString;

@Getter
@Builder
public class RichTextStringCellValue implements CellValue<RichTextString> {

    private final RichTextString value;
}
