package com.morethanheroic.office.excel.service.cell.domain.style;

public class CellFormat {

    public static final String HUNGARIAN_FORINT_CURRENCY = "_-* # ##0 Ft_-;-* # ##0 Ft_-;_-* \"-\" Ft_-;_-@_-";
}
