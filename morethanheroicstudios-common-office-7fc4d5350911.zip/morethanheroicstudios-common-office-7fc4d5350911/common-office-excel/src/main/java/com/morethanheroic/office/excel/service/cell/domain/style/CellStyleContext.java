package com.morethanheroic.office.excel.service.cell.domain.style;

import com.morethanheroic.office.excel.service.style.domain.Color;
import lombok.Builder;
import lombok.Getter;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.VerticalAlignment;

/**
 * Contains all data that is required to format a cell.
 */
@Getter
@Builder
public class CellStyleContext {

    private final String dataFormat;
    private final Color fontColor;
    private final boolean fontBold;
    private final HorizontalAlignment horizontalAlignment;
    private final VerticalAlignment verticalAlignment;
}
