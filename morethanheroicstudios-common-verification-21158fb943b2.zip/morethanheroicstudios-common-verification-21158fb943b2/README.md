# Common Verification

This module provides a common way for adding the email verification feature to a web application. This module is only responsible for calculating and saving the verification ids. Sending the email is supported by the `common-registration` module.

## Installation

Add this project as a dependency to the application and enable class path scanning for `com.morethanheroic.verification`.

The email verification logic is also handled by this registration module. If you want to add verification links to your registration emails then call the `VerificationFactory#newVerification(UserEntity)` to create a new verification link. Add this link to the email's body. The controller that will handle the verification process is automatically provided by this module.

You also need to specify the properties provided by the application module. They will be used to generate the verification link.

You will also need to create an email_verification table in your database. The Liquibase XML files for this is provided in the resources directory.

### Events

On a verification call the finalizer publish a `VerificationFinalization` event. To handle this event, extend the `VerificationFinalizationEventHandler` abstract class and register it as a `@Component`.

### Email change verification

This module also handles when a user want to change his/her registered email address. In this case a verification email will be sent to the user and if the user clicks on the verification link then his/her email will be changed. These emails addresses are NOT mandatory to be verified for login so the users can still login with their old email address if they not verify their new email address.

## Changelog

- ***2.0.0***
    - Split this common module into two separate smaller modules. One for the service layer and another for the view one.
- ***1.3.3***
    - Removed the now unused VerificationEmailRenderer.
    - Fixed the default e-mail verification URL postfix string.
    - Added some logging for the email change verification finalization.
- ***1.3.2***
	- Fixed that the VerificationEntity were built incorrectly at an other place too.
- ***1.3.1***
    - Fixed that the VerificationEntity was built incorrectly because the mandatory variable was always false.
- ***1.3.0***
    - The VerificationController will return with 400 (Bad Request) if the verification entry is already deleted (the email is already verified). In other cases we will return with 200 (Ok).
    - Added a way to be able to configure the verification url postfix.
- ***1.2.6***
    - Added a VerificationEmailRenderer for rendering verification email contents.
- ***1.2.5***
    - Fixed that non-mandatory verifications were handled incorrectly.
- ***1.2.4***
    - Fixed the EmailChangeRepository#remove's delete MySQL query.
- ***1.2.3***
    - Fixed a bug in the email change verifications not being updated.
- ***1.2.2***
    - If a user ask for a new verification email he/she will get one and the data in the database will be updated with the new verificationId.
- ***1.2.1***
    - Added a missing field in the SQL database to the verification table.
    - **New SQL changelog released.**
- ***1.2.0***
    - Added login for application wide verification events.
    - Added the change email verification feature.
    - **New SQL changelog released.**
- ***1.1.0***
    - Renamed the Entity classes to make them more streamlined with the domain objects in other modules.
    - Relying on the common-application module to get the properties (available urls etc...) of the actually running application instead the module's own property.
    - Increased Spring Boot version to 2.0.1.
- ***1.0.5***
    - Fixed that the hasVerification calculated the user's verification incorrectly.
- ***1.0.4***
    - Added a way to check if a user is verified.
- ***1.0.2***
    - Modified the sql schema fixing the verification_id column's type.
    - **New SQL changelog released.**
- ***1.0.1***
    - Added the changelog for creating the verification table in the database.
    - **New SQL changelog released.**
- ***1.0.0***
    - Initial release of the module.