package com.morethanheroic.verification.service.finalizer.event;

import com.morethanheroic.event.EventDispatcher;
import com.morethanheroic.verification.service.finalizer.event.domain.VerificationFinalizationEventConfiguration;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class VerificationFinalizationEventDispatcher implements EventDispatcher<VerificationFinalizationEventConfiguration> {

    private final List<VerificationFinalizationEventHandler> verificationFinalizationEventHandlers;

    @Override
    public void dispatch(final VerificationFinalizationEventConfiguration verificationFinalizationEventConfiguration) {
        verificationFinalizationEventHandlers.forEach(verificationFinalizationEventHandler ->
                verificationFinalizationEventHandler.onEvent(verificationFinalizationEventConfiguration)
        );
    }
}
