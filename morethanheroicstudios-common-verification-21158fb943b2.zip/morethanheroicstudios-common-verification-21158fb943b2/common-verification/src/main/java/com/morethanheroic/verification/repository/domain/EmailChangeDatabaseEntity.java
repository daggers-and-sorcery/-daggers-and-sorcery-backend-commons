package com.morethanheroic.verification.repository.domain;

import lombok.Data;

@Data
public class EmailChangeDatabaseEntity {

    /**
     * This is the Verification's id that this entity belongs to.
     */
    private String id;

    /**
     * The email to change the user's current email after successful verification.
     */
    private String email;
}
