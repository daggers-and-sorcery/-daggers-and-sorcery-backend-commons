package com.morethanheroic.verification.service.finalizer;

import com.morethanheroic.verification.service.domain.VerificationEntity;
import com.morethanheroic.verification.service.finalizer.event.VerificationFinalizationEventDispatcher;
import com.morethanheroic.verification.service.finalizer.event.domain.VerificationFinalizationEventConfiguration;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class VerificationFinalizer {

    private final VerificationFinalizationEventDispatcher verificationFinalizationEventDispatcher;

    public void finalizeVerification(final VerificationEntity verificationEntity) {
        verificationFinalizationEventDispatcher.dispatch(
                VerificationFinalizationEventConfiguration.builder()
                        .verificationEntity(verificationEntity)
                        .build()
        );
    }
}
