package com.morethanheroic.verification.service;

import com.morethanheroic.user.service.factory.UserEntityFactory;
import com.morethanheroic.verification.repository.domain.VerificationDatabaseEntity;
import com.morethanheroic.verification.service.domain.VerificationEntity;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

/**
 * This class is responsible for converting a {@link VerificationDatabaseEntity} to a {@link VerificationEntity}.
 */
@Service
@RequiredArgsConstructor
public class VerificationEntityTransformer {

    private final UserEntityFactory userEntityFactory;
    private final VerificationUrlCalculator verificationUrlCalculator;

    /**
     * Converts a {@link VerificationDatabaseEntity} to a {@link VerificationEntity}.
     *
     * @param verificationDatabaseEntity the database entity to convert
     * @return the conversion result
     */
    public VerificationEntity transform(final VerificationDatabaseEntity verificationDatabaseEntity) {
        final String verificationUrl = verificationUrlCalculator.calculateVerificationUrl(
                verificationDatabaseEntity.getVerificationId());

        return VerificationEntity.builder()
                .verificationId(verificationDatabaseEntity.getVerificationId())
                .verificationUrl(verificationUrl)
                .user(userEntityFactory.getUserEntity(verificationDatabaseEntity.getUserId()))
                .mandatory(verificationDatabaseEntity.isMandatory())
                .build();
    }
}
