package com.morethanheroic.verification.repository;

import com.morethanheroic.verification.repository.domain.VerificationDatabaseEntity;
import org.apache.ibatis.annotations.*;

@Mapper
public interface VerificationRepository {

    @Select("SELECT * FROM verification WHERE verification_id = #{verificationId}")
    VerificationDatabaseEntity findVerificationById(@Param("verificationId") String verificationId);
    
    @Select("SELECT * FROM verification WHERE user_id = #{userId}")
    VerificationDatabaseEntity findVerificationByUserId(@Param("userId") long userId);

    @Insert("INSERT INTO verification SET user_id = #{userId}, verification_id = #{verificationId}, mandatory = #{mandatory}")
    void insertVerification(
            @Param("userId") int userId,
            @Param("verificationId") String verificationId,
            @Param("mandatory") boolean mandatory
    );

    @Update("UPDATE verification SET verification_id = #{verificationId} WHERE user_id = #{userId}")
    void updateVerificationForUser(@Param("userId") long userId, @Param("verificationId") String verificationId);

    @Delete("DELETE FROM verification WHERE verification_id = #{verificationId}")
    void removeVerification(@Param("verificationId") String verificationId);
}
