package com.morethanheroic.verification.service;

import com.morethanheroic.user.domain.UserEntity;
import com.morethanheroic.verification.repository.EmailChangeRepository;
import com.morethanheroic.verification.repository.VerificationRepository;
import com.morethanheroic.verification.repository.domain.EmailChangeDatabaseEntity;
import com.morethanheroic.verification.repository.domain.VerificationDatabaseEntity;
import com.morethanheroic.verification.service.domain.VerificationEntity;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Optional;
import java.util.UUID;

/**
 * This class is responsible for creating new {@link VerificationEntity} instances.
 */
@Service
@RequiredArgsConstructor
public class VerificationEntityFactory {

    private final VerificationRepository verificationRepository;
    private final EmailChangeRepository emailChangeRepository;
    private final VerificationUrlCalculator verificationUrlCalculator;
    private final VerificationEntityTransformer verificationEntityTransformer;

    /**
     * Get a verification's data by it's id.
     *
     * @param verificationId the id of the verification to get
     * @return the data of the verification that belongs to the provided id
     */
    public Optional<VerificationEntity> getVerificationEntity(final String verificationId) {
        final VerificationDatabaseEntity verificationDatabaseEntity = verificationRepository.findVerificationById(verificationId);

        if (verificationDatabaseEntity == null) {
            return Optional.empty();
        }

        return Optional.of(verificationEntityTransformer.transform(verificationDatabaseEntity));
    }

    /**
     * Get the verification data for an user.
     *
     * @param userEntity the user to get the data for
     * @return the data that contains the verification requirements of the user
     */
    public Optional<VerificationEntity> getVerificationEntity(final UserEntity userEntity) {
        final VerificationDatabaseEntity verificationDatabaseEntity =
                verificationRepository.findVerificationByUserId(userEntity.getId());

        if (verificationDatabaseEntity == null) {
            return Optional.empty();
        }

        return Optional.of(verificationEntityTransformer.transform(verificationDatabaseEntity));
    }

    public boolean hasVerification(final UserEntity userEntity) {
        //TODO: Create a faster way for this if necessary.
        return getVerificationEntity(userEntity).isPresent();
    }

    public VerificationEntity newVerificationEntity(final UserEntity userEntity) {
        final String verificationId = UUID.randomUUID().toString();

        createNewVerificationEntry(userEntity, verificationId, true);

        return VerificationEntity.builder()
                .user(userEntity)
                .verificationId(verificationId)
                .verificationUrl(verificationUrlCalculator.calculateVerificationUrl(verificationId))
                .build();
    }

    public VerificationEntity newEmailChangeVerificationEntity(final UserEntity userEntity, final String newEmail) {
        final String verificationId = UUID.randomUUID().toString();

        createNewVerificationEntry(userEntity, verificationId, false);

        final EmailChangeDatabaseEntity emailChangeDatabaseEntity = new EmailChangeDatabaseEntity();
        emailChangeDatabaseEntity.setId(verificationId);
        emailChangeDatabaseEntity.setEmail(newEmail);

        emailChangeRepository.insert(emailChangeDatabaseEntity);

        return VerificationEntity.builder()
                .user(userEntity)
                .verificationId(verificationId)
                .verificationUrl(verificationUrlCalculator.calculateVerificationUrl(verificationId))
                .build();
    }

    private void createNewVerificationEntry(final UserEntity userEntity, final String verificationId,
                                            final boolean mandatory) {
        final Optional<VerificationEntity> verificationEntity = getVerificationEntity(userEntity);

        if (verificationEntity.isPresent()) {
            if (!verificationEntity.get().isMandatory()) {
                emailChangeRepository.remove(verificationEntity.get().getVerificationId());
            }

            verificationRepository.updateVerificationForUser(userEntity.getId(), verificationId);
        } else {
            verificationRepository.insertVerification(userEntity.getId(), verificationId, mandatory);
        }
    }
}
