package com.morethanheroic.verification.service.configuration;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Data
@Component
@ConfigurationProperties("verification")
public class VerificationProperties {

    /**
     * What should we add after the website's domain when calculating the verification url. Use &lbrace;id&rbrace; to mark the
     * verification id in the url.
     *
     * For example '#!/verification/&lbrace;id&rbrace;' will result in http://example.com/#!/verification/123456.
     */
    private String urlPostfix;
}
