package com.morethanheroic.verification.service.finalizer.event.handler;

import com.morethanheroic.verification.repository.VerificationRepository;
import com.morethanheroic.verification.service.finalizer.event.VerificationFinalizationEventHandler;
import com.morethanheroic.verification.service.finalizer.event.domain.VerificationFinalizationEventConfiguration;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class DefaultVerificationFinalizationEventHandler extends VerificationFinalizationEventHandler {

    private final VerificationRepository verificationRepository;

    @Override
    public void onEvent(final VerificationFinalizationEventConfiguration verificationFinalizationEventConfiguration) {
        verificationRepository.removeVerification(
                verificationFinalizationEventConfiguration.getVerificationEntity().getVerificationId());
    }
}
