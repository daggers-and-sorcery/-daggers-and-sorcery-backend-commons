package com.morethanheroic.verification.service.finalizer.event.domain;

import com.morethanheroic.event.EventConfiguration;
import com.morethanheroic.verification.service.domain.VerificationEntity;
import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class VerificationFinalizationEventConfiguration implements EventConfiguration {

    private final VerificationEntity verificationEntity;
}
