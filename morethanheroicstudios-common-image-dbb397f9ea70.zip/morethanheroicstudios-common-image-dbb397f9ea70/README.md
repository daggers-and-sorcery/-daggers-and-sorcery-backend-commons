# Common Image

## Changelog

- ***1.0.1***
    - Added Spring Boot bean auto-registration for this module.
- ***1.0.0***
    - Initial release.