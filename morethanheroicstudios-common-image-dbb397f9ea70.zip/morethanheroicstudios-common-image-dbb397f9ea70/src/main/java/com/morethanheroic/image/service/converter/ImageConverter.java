package com.morethanheroic.image.service.converter;

import org.springframework.stereotype.Service;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

/**
 * This class is providing various nethods to convert between image encodings (like jpg/bmp/png etc).
 */
@Service
public class ImageConverter {

    /**
     * Convert an image to png format. The image data is handled by the provided input stream.
     *
     * @param inputStream the input stream to get the image data from
     * @return an input stream that holds the converted image data
     */
    public InputStream convertImageToPng(final InputStream inputStream) {
        try {
            final BufferedImage bufferedImage = ImageIO.read(inputStream);
            final ByteArrayOutputStream byteArrayOut = new ByteArrayOutputStream();

            ImageIO.write(bufferedImage, "png", byteArrayOut);

            return new ByteArrayInputStream(byteArrayOut.toByteArray());
        } catch (IOException e) {
            throw new RuntimeException("Unable to convert image.");
        }
    }
}
