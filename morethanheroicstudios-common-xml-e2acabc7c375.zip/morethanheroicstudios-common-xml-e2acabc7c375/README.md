# Common XML

## Changelog
- ***1.1.0***
    - Updated the Gradle version to 5.0-rc-1.
    - Updated the Java version to Java 11.
    - Updated Spring Boot version to 2.1.0.RELEASE.
    - Added JAXB as a dependency.