package com.morethanheroic.xml.service.loader.exception;

/**
 * Exception thrown when an error happens while loading a definition.
 */
public class DefinitionLoaderException extends RuntimeException {

    public DefinitionLoaderException(String message, Throwable throwable) {
        super(message, throwable);
    }

    public DefinitionLoaderException(String message) {
        super(message);
    }
}
