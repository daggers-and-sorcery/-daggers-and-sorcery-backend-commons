package com.morethanheroic.xml.service.loader;

import com.morethanheroic.xml.service.loader.domain.DefinitionLoadingContext;

import java.util.List;

/**
 * Blueprint for writing xml definition loaders.
 * @param <T> The type of the loadable target.
 */
public interface XmlDefinitionLoader<T> {

    <Z> List<Z> loadDefinitions(DefinitionLoadingContext definitionLoadingContext);
}
