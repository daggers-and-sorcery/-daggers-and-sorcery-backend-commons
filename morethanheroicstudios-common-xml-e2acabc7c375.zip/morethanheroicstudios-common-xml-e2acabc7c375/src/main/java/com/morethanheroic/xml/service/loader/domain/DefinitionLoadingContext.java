package com.morethanheroic.xml.service.loader.domain;

/**
 * Shows that an object is a context of a definition loading.
 */
public interface DefinitionLoadingContext {
}
