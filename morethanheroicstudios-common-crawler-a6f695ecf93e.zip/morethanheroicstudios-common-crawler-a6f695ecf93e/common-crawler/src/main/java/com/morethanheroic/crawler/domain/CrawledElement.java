package com.morethanheroic.crawler.domain;

import java.util.List;
import java.util.Optional;

public interface CrawledElement {

    String getAttribute(final String attributeName);

    /**
     * Return the "tag" type of this element. For example "a" when the element reperesents an
     * "&#x3C;a&#x3E;xyz&#x3C;/a&#x3E;" tag.
     *
     * @return the "tag" type of this element
     */
    String getTag();

    Optional<CrawledElement> selectElement(final String selector);

    List<CrawledElement> selectElements(final String selector);

    List<CrawledElement> getChildren();

    void removeChild(final String selector);

    String getText();

    String getTrimmedText();
}
