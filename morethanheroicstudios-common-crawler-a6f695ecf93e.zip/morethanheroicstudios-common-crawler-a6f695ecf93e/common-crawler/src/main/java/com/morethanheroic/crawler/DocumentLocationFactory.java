package com.morethanheroic.crawler;

import com.morethanheroic.crawler.domain.DocumentLocation;

import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.Path;
import java.util.Collections;
import java.util.Map;

import org.springframework.stereotype.Service;

@Service
public class DocumentLocationFactory {

    public DocumentLocation newLocation(final String location) {
        try {
            return newLocation(new URL(location), Collections.emptyMap());
        } catch (MalformedURLException e) {
            throw new RuntimeException(e);
        }
    }

    public DocumentLocation newLocation(final Path location) {
        try {
            return newLocation(location.toUri().toURL());
        } catch (MalformedURLException e) {
            throw new RuntimeException(e);
        }
    }

    public DocumentLocation newLocation(final URL location) {
        return newLocation(location, Collections.emptyMap());
    }

    public DocumentLocation newLocation(final URL location, final Map<String, String> headers) {
        return DocumentLocation.builder()
                .url(location)
                .headers(headers)
                .build();
    }
}
