package com.morethanheroic.crawler;

import com.morethanheroic.crawler.domain.CrawledDocument;
import com.morethanheroic.crawler.domain.DocumentLocation;

public interface CrawledDocumentFactory {

    CrawledDocument newDocument(final DocumentLocation documentLocation);
}
