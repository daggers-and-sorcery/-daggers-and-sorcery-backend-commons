package com.morethanheroic.crawler.jsoup.domain;

import com.morethanheroic.crawler.domain.CrawledElement;
import lombok.Builder;
import org.jsoup.nodes.Element;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Builder
public class JsoupCrawledElement implements CrawledElement {

    private final Element element;

    @Override
    public String getAttribute(final String attributeName) {
        return element.attr(attributeName);
    }

    @Override
    public String getTag() {
        return element.tagName();
    }

    @Override
    public Optional<CrawledElement> selectElement(final String selector) {
        final Element selectedElement = element.select(selector).first();

        if (selectedElement != null) {
            return Optional.of(
                    JsoupCrawledElement.builder()
                            .element(selectedElement)
                            .build()
            );
        } else {
            return Optional.empty();
        }
    }

    @Override
    public List<CrawledElement> selectElements(String selector) {
        return element.select(selector).stream()
                .map(element ->
                        JsoupCrawledElement.builder()
                                .element(element)
                                .build()
                )
                .collect(Collectors.toList());
    }

    @Override
    public List<CrawledElement> getChildren() {
        return element.children().stream()
                .map(child ->
                        JsoupCrawledElement.builder()
                                .element(child)
                                .build()
                )
                .collect(Collectors.toList());
    }

    @Override
    public void removeChild(final String selector) {
        element.select(selector).remove();
    }

    @Override
    public String getText() {
        return element.text();
    }

    @Override
    public String getTrimmedText() {
        return this.getText().trim();
    }
}
