package com.morethanheroic.crawler.download;

import com.morethanheroic.crawler.exception.DownloadingException;
import org.apache.commons.io.IOUtils;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

/**
 * This class provides various ways to download files from the web.
 */
@Service
public class FileDownloader {

    public void downloadFile(final String downloadTarget, final File resultLocation) {
        this.downloadFile(downloadTarget, resultLocation, 30000);
    }

    public void downloadFile(final URL downloadTarget, final File resultLocation) {
        this.downloadFile(downloadTarget, resultLocation, 30000);
    }

    public void downloadFile(final String downloadTarget, final File resultLocation, final int timeout) {
        try {
            this.downloadFile(new URL(downloadTarget), resultLocation, timeout);
        } catch (MalformedURLException e) {
            throw new DownloadingException("Unable to translate download target location to url!", e);
        }
    }

    public void downloadFile(final URL downloadTarget, final File resultLocation, final int timeout) {
        try {
            final URLConnection urlConnection = downloadTarget.openConnection();
            urlConnection.setConnectTimeout(timeout);
            urlConnection.setReadTimeout(timeout);

            try (final InputStream inputStream = urlConnection.getInputStream()) {
                try (final FileOutputStream outputStream = new FileOutputStream(resultLocation)) {
                    IOUtils.copyLarge(inputStream, outputStream);
                }
            }
        } catch (Exception e) {
            throw new DownloadingException("Error occurred while downloading file!", e);
        }
    }
}
