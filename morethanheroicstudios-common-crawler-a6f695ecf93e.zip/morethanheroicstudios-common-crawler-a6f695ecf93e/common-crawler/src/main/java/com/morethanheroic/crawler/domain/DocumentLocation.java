package com.morethanheroic.crawler.domain;

import lombok.Builder;
import lombok.Getter;

import java.net.URL;
import java.util.Map;

@Getter
@Builder
public class DocumentLocation {

    private final URL url;
    private final Map<String, String> headers;
}
