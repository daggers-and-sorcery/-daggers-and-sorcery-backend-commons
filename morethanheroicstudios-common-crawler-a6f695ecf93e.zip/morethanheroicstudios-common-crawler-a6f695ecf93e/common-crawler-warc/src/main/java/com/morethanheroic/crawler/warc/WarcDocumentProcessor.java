package com.morethanheroic.crawler.warc;

import com.morethanheroic.crawler.domain.CrawledDocument;
import com.morethanheroic.crawler.domain.DocumentLocation;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.stream.Stream;

@Service
@RequiredArgsConstructor
public class WarcDocumentProcessor {

    private final WarcDocumentStreamer warcDocumentStreamer;
    private final WarcCrawledDocumentFactory warcCrawledDocumentFactory;

    public Stream<CrawledDocument> process(final DocumentLocation warcFileLocation) {
        return warcDocumentStreamer.stream(warcFileLocation)
                .map(warcCrawledDocumentFactory::buildDocument);
    }
}
