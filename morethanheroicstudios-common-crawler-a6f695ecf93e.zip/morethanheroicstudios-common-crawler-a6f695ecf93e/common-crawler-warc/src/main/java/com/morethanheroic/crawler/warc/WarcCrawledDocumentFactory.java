package com.morethanheroic.crawler.warc;

import com.morethanheroic.crawler.domain.CrawledDocument;
import com.morethanheroic.crawler.domain.DocumentLocation;
import com.morethanheroic.crawler.domain.InvalidCrawledDocument;
import com.morethanheroic.crawler.jsoup.domain.JsoupCrawledDocument;
import com.morethanheroic.crawler.warc.domain.WarcDocument;
import lombok.extern.slf4j.Slf4j;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.springframework.stereotype.Service;

import java.net.MalformedURLException;
import java.net.URL;

@Slf4j
@Service
public class WarcCrawledDocumentFactory {

    public CrawledDocument buildDocument(final WarcDocument warcDocumen) {
        final Document document;

        try {
            document = Jsoup.parse(warcDocumen.getBody(), warcDocumen.getUrl());
        } catch (Exception e) {
            log.error("Error while building crawled document: " + e.getMessage());

            return new InvalidCrawledDocument();
        }

        try {
            return JsoupCrawledDocument.builder()
                    .location(
                            DocumentLocation.builder()
                                    .url(new URL(warcDocumen.getUrl()))
                                    .build()
                    )
                    .document(document)
                    .build();
        } catch (MalformedURLException e) {
            log.error("Error while building crawled document: " + e.getMessage());

            return new InvalidCrawledDocument();
        }
    }
}
