package com.morethanheroic.crawler.warc.domain;

import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class WarcDocument {

    private final String url;
    private final String body;
}
