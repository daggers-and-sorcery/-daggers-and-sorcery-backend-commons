# Common Swagger

## Changelog

- ***1.0.0***
    - Initial release.