package com.morethanheroic.invoice.domain.customer;

import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class DefaultCustomer implements Customer {

    private final String name;
    private final String detail;
    private final String city;
    private final String address;
    private final String zip;
    private final String country;
    private final String vatNumber;
    private final String contactName;
    private final String email;
}
