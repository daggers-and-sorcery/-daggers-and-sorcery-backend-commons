package com.morethanheroic.invoice.domain;

public enum  InvoiceType {

    NORMAL,
    TEST,
    CANCELLATION,
    PREPAYMENT_REQUEST
}
