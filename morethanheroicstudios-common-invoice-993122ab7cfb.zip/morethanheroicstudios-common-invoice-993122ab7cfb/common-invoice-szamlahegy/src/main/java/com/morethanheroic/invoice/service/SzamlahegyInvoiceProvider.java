package com.morethanheroic.invoice.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.morethanheroic.invoice.domain.Invoice;
import com.morethanheroic.invoice.service.domain.SzamlahegyRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.springframework.stereotype.Service;

import java.io.IOException;

@Slf4j
@Service
@RequiredArgsConstructor
public class SzamlahegyInvoiceProvider implements InvoiceProvider {

    private static final String SZAMLAHEGY_API_URL = "https://ugyfel.szamlahegy.hu/api/v1/invoices";

    private final SzamlahegyRequestFactory szamlahegyRequestFactory;
    private final ObjectMapper objectMapper;

    @Override
    public void handleInvoice(final Invoice invoice) {
        final SzamlahegyRequest szamlahegyRequest = szamlahegyRequestFactory.newRequest(invoice);

        try (final CloseableHttpClient httpclient = HttpClients.createDefault()) {
            final String requestBody = objectMapper.writeValueAsString(szamlahegyRequest);

            final HttpPost httpPost = new HttpPost(SZAMLAHEGY_API_URL);
            httpPost.setEntity(new StringEntity(requestBody, ContentType.APPLICATION_JSON));

            try (CloseableHttpResponse response = httpclient.execute(httpPost)) {
                log.info("Got response from Szamlahegy! Status: " + response.getStatusLine() + " body: "
                        + EntityUtils.toString(response.getEntity()));
            }
        } catch (IOException e) {
            throw new RuntimeException("Unable to create Invoice!", e);
        }
    }
}
