package com.morethanheroic.invoice.service.domain;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Getter;

import java.util.List;

@Getter
@Builder
public class SzamlahegyRequestInvoice {

    @JsonProperty("customer_name")
    private final String customerName;

    @JsonProperty("customer_detail")
    private final String customerDetail;

    @JsonProperty("customer_city")
    private final String customerCity;

    @JsonProperty("customer_address")
    private final String customerAddress;

    @JsonProperty("customer_country")
    private final String customerCountry;

    @JsonProperty("customer_contact_name")
    private final String customerContactName;

    @JsonProperty("customer_zip")
    private final String customerZip;

    @JsonProperty("customer_email")
    private final String customerEmail;

    @JsonProperty("customer_vatnr")
    private final String customerVatNumber;

    @JsonProperty("payment_method")
    private final String paymentMethod;

    @JsonProperty("payment_date")
    private final String paymentDate;

    @JsonProperty("perform_date")
    private final String performDate;

    @JsonProperty("paid_at")
    private final String paidAt;

    @JsonProperty("kind")
    private final String type;

    @JsonProperty("foreign_id")
    private final String id;

    @JsonProperty("invoice_rows_attributes")
    private final List<SzamlahegyRequestInvoiceItem> items;

    @JsonProperty("currency")
    private final String currency;

    @JsonProperty("language")
    private final String language;

    @JsonProperty("header")
    private final String header;

    @JsonProperty("footer")
    private final String footer;

    @JsonProperty("signed")
    private final String signed;
}
