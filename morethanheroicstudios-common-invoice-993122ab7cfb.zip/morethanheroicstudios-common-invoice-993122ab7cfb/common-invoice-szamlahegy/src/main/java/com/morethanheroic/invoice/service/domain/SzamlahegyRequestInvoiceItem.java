package com.morethanheroic.invoice.service.domain;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class SzamlahegyRequestInvoiceItem {

    /**
     * Unique id of the row.
     */
    @JsonProperty("foreign_id")
    private final String id;

    /**
     * Id of the sold product.
     */
    @JsonProperty("productnr")
    private final String itemId;

    @JsonProperty("name")
    private final String name;

    @JsonProperty("detail")
    private final String description;

    @JsonProperty("currency")
    private final String currency;

    @JsonProperty("price_slab")
    private final String unitPrice;

    @JsonProperty("tax")
    private final String tax;

    @JsonProperty("quantity")
    private final String quantity;

    @JsonProperty("quantity_type")
    private final String quantityType;

    @JsonProperty("stock_management")
    private final boolean stockManagement = false;

    @JsonProperty("visible")
    private final boolean publiclyVisibleItem = false;

    @JsonProperty("has_dimensions")
    private final boolean hasDimensions = false;
}
