package com.morethanheroic.invoice.service.domain;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class SzamlahegyRequest {

    @JsonProperty("api_key")
    private final String apiKey;
    private final SzamlahegyRequestInvoice invoice;
}
