# Common Invoice

## Changelog

- ***1.1.4***
    - Added the signed property to the szamlahegy requests.
- ***1.1.3***
    - Added the primaryMessage and the secondaryMessage fields.
- ***1.1.2***
    - Added the quantity field for the invoice rows.
- ***1.1.1***
    - Added the Szamlahegy implementation in it's final form.
- ***1.1.0***
    - Added the InvoiceConfigurationProperties.
    - Moved the InvoiceProvider from com.morethanheroic.invoice to com.morethanheroic.invoice.service.
- ***1.0.0***
    - Initial release.