# Common Security

This module provides a common way for adding security related functionality to an application.

## Installation

Add this project as a dependency to the application.

## Changelog

- ***2.0.0***
    - Replaced the existing Spring based password hashing with an apache-common-codec based one.
    - Changed the default salt used for password hashing.
    - Updated Spring Boot version from 1.5 to 2.0.6.