package com.morethanheroic.qrcode.service.domain.schema;

import java.net.URL;
import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class UrlContentType {

  private URL url;
}
