package com.morethanheroic.qrcode.service;

import com.morethanheroic.qrcode.service.domain.schema.UrlContentType;
import java.io.ByteArrayOutputStream;
import net.glxn.qrgen.core.scheme.Url;
import net.glxn.qrgen.javase.QRCode;
import org.springframework.stereotype.Service;

@Service
public class QrCodeGenerator {

  public ByteArrayOutputStream newQrCode(final UrlContentType urlContentType) {
    return QRCode.from(Url.parse(urlContentType.getUrl().toString())).stream();
  }
}
