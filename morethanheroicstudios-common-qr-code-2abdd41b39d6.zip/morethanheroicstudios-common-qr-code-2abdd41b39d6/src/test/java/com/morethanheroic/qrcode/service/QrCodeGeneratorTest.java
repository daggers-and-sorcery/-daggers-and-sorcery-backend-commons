package com.morethanheroic.qrcode.service;

import com.morethanheroic.qrcode.service.domain.schema.UrlContentType;
import java.net.MalformedURLException;
import java.net.URL;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class QrCodeGeneratorTest {

  @InjectMocks
  private QrCodeGenerator underTest;

  @Test
  public void testNewQrCode() throws MalformedURLException {
    underTest.newQrCode(
        UrlContentType.builder()
            .url(new URL("http://www.example.com/"))
            .build()
    );
  }
}