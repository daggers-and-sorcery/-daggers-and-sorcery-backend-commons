# Common Qr Code

This package provides a common way for creating QR Code images.

## Installation

Add this project as a dependency to the application and enable class path scanning for `com.morethanheroic.qrcode`.

## Changelog

- ***1.0.3***
    - Updated the qr code lib to 2.5.0.
- ***1.0.2***
    - Updated the `qrgen` dependency.
- ***1.0.0***
    - Initial release.
