# Common Metadata

## Changelog

- ***1.0.2***
    - Moved from int based metadata handling to a long one.