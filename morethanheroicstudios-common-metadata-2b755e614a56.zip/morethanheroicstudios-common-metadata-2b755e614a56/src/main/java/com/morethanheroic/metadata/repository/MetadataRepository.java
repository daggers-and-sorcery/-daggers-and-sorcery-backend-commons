package com.morethanheroic.metadata.repository;

import com.morethanheroic.metadata.repository.domain.MetadataDatabaseEntity;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

@Mapper
public interface MetadataRepository {

    @Select("SELECT * FROM metadata WHERE user_id = #{userId} AND name = #{name}")
    MetadataDatabaseEntity findByUserIdAndName(@Param("userId") int userId, @Param("name") String name);

    @Insert("INSERT INTO metadata SET user_id = #{metadata.userId}, name = #{metadata.name}, value = #{metadata.value}")
    void insert(@Param("metadata") MetadataDatabaseEntity metadataDatabaseEntity);
}
