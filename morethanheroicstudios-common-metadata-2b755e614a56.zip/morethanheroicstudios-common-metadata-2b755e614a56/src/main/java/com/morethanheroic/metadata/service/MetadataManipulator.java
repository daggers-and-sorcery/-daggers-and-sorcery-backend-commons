package com.morethanheroic.metadata.service;

import com.morethanheroic.metadata.repository.MetadataRepository;
import com.morethanheroic.metadata.repository.domain.MetadataDatabaseEntity;
import com.morethanheroic.metadata.service.domain.Metadata;
import com.morethanheroic.user.domain.UserEntity;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class MetadataManipulator {

    private final MetadataRepository metadataRepository;

    public long getMetadataValue(final UserEntity userEntity, final Metadata metadataId) {
        return metadataRepository.findByUserIdAndName(userEntity.getId(), metadataId.getName()).getValue();
    }

    public void setMetadataValue(final UserEntity userEntity, final Metadata metadata, final long value) {
        final MetadataDatabaseEntity metadataDatabaseEntity = new MetadataDatabaseEntity();

        metadataDatabaseEntity.setUserId(userEntity.getId());
        metadataDatabaseEntity.setName(metadata.getName());
        metadataDatabaseEntity.setValue(value);

        metadataRepository.insert(metadataDatabaseEntity);
    }
}
