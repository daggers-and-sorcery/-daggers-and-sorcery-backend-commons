package com.morethanheroic.session.redis.configuration;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.RedisPassword;
import org.springframework.data.redis.connection.RedisStandaloneConfiguration;
import org.springframework.data.redis.connection.lettuce.LettuceConnectionFactory;
import org.springframework.session.data.redis.config.annotation.web.http.EnableRedisHttpSession;

@Slf4j
@Configuration
@EnableRedisHttpSession(maxInactiveIntervalInSeconds = 31556926)
@ConditionalOnProperty(value = "session.provider", havingValue = "redis")
@RequiredArgsConstructor
public class RedisSessionBackend {

    private final RedisSessionProperties redisSessionProperties;

    @Bean
    public LettuceConnectionFactory redisConnectionFactory() {
        log.info("Using Redis as session backend!");
        log.info("Connecting to Redis at " + redisSessionProperties.getHostName() + ":" + redisSessionProperties.getPort() + "!");

        final RedisStandaloneConfiguration redisStandaloneConfiguration = new RedisStandaloneConfiguration();

        redisStandaloneConfiguration.setHostName(redisSessionProperties.getHostName());
        redisStandaloneConfiguration.setPort(redisSessionProperties.getPort());

        if (!redisSessionProperties.getPassword().isEmpty()) {
            redisStandaloneConfiguration.setPassword(RedisPassword.of(redisSessionProperties.getPassword()));
        }

        return new LettuceConnectionFactory(redisStandaloneConfiguration);
    }
}
