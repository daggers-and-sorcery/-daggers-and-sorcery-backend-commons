package com.morethanheroic.session.aspect;

import com.morethanheroic.session.aspect.domain.UnauthorizedException;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;

@Aspect
@Component
public class RequireLoginAspect {

    @Before("@annotation(com.morethanheroic.session.aspect.domain.RequireLogin)")
    public void checkUserLoggedIn() {
        final HttpServletRequest httpServletRequest =
                ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes()).getRequest();

        if (httpServletRequest.getSession().getAttribute("USER_ID") == null) {
            throw new UnauthorizedException();
        }
    }
}
