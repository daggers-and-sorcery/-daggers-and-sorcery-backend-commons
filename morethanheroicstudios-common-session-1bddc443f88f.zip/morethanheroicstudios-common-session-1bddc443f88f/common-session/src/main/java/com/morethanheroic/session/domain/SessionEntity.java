package com.morethanheroic.session.domain;

import lombok.RequiredArgsConstructor;

import javax.servlet.http.HttpSession;

@RequiredArgsConstructor
public class SessionEntity {

    private final HttpSession httpSession;

    public void setAttribute(String key, Object value) {
        httpSession.setAttribute(key, value);
    }

    public Object getAttribute(String key) {
        return httpSession.getAttribute(key);
    }

    public boolean isAttributeSet(String key) {
        return httpSession.getAttribute(key) != null;
    }

    public void close() {
        httpSession.invalidate();
    }
}
