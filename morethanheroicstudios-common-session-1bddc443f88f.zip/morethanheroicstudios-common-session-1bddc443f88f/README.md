# Common Session

## Changelog

- ***2.3.0***
    - Removed the spring-boot-starter-web dependency from the common-session module.
    - Added the common-session-view module.
    - Added a ControllerAdvice to the view module that handles the UnauthorizedException from the RequireLoginAdvice.
- ***2.2.5***
    - Renamed the HandlerMethodArgumentResolverRegistrationBean for the SessionEntityHandlerMethodArgumentResolver because it's override the UserEntityHandlerMethodArgumentResolver.
- ***2.2.4***
    - Added a HandlerMethodArgumentResolverRegistrationBean for SessionEntityHandlerMethodArgumentResolver.
- ***2.2.3***
    - Removed unused leftover variables.
- ***2.2.2***
    - Removed accidentally leftover old common-session-redis dependency from common-session.
- ***2.2.1***
    - Added the SessionConfigurationProperties to provide auto-discovery for session properties (provider only for now).
- ***2.2.0***
    - Removed the deprecated legacy authentication filter and it's configuration.
    - Added Spring auto-configuration support.
    - Added redis session property loading via @ConfigurationProperties. The new property names differ from the previous ones so the session properties should be revised.
    - Updated Spring Boot version to 2.0.3.RELEASE.
    - Started releasing javadocs and sources alongside the binaries jar.
- ***2.1.0***
    - First working libs after 2.0.x. Don't use 2.0.x.
- ***2.0.x***
    - Merged the common-session and the common-session-redis modules into one repo.
    - Reworked and tested the new release layout.