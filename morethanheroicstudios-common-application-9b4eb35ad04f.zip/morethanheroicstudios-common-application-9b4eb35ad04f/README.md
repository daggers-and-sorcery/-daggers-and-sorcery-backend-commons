# Common Application

This module is responsible for the very basic functionality of the application like initializing the CORS filters, provide basic information about the application like the domein it's running on etc.

## Changelog

- ***1.2.3***
    - Added exposedHeaders to CORS.
    - Added the ResourcesProperties.
- ***1.2.2***
    - Added this readme.
    - Added the default-email property to the application properties.
