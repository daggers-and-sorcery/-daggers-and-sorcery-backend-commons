package com.morethanheroic.application.configuration;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Data
@Component
@ConfigurationProperties("application")
public class ApplicationProperties {

    private String apiDomain;
    private String webDomain;
    private int apiPort;
    private int webPort;
    private String protocol;
    private String defaultEmail;

    public String getApiEndpoint() {
        if (apiPort != 80 || apiPort != 443) {
            return protocol + "://" + apiDomain + ":" + apiPort + "/";
        } else {
            return protocol + "://" + apiDomain + "/";
        }
    }

    public String getWebEndpoint() {
        if (webPort != 80 || webPort != 443) {
            return protocol + "://" + webDomain + ":" + webPort + "/";
        } else {
            return protocol + "://" + webDomain + "/";
        }
    }
}
