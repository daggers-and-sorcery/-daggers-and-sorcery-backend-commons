package com.morethanheroic.application;

import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.web.servlet.ServletContextInitializer;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

import javax.servlet.ServletContext;
import java.nio.charset.Charset;
import java.util.Locale;
import java.util.TimeZone;

@Slf4j
@Component
public class DefaultPropertyInitializer implements ServletContextInitializer {

    @Override
    public void onStartup(ServletContext servletContext) {
        // Can be set runtime before Spring instantiates any beans.
        TimeZone.setDefault(TimeZone.getTimeZone("UTC"));

        // Cannot override encoding in java at runtime as some strings have already been read
        // however, we can assert and ensure right values are loaded here.

        // Verify system property is set.
        Assert.isTrue("UTF-8".equals(System.getProperty("file.encoding")), "The file encoding must be UTF-8 to start! Please start the application with the -Dfile.encoding=UTF8 VM attribute.");

        // Actually verify it is being used.
        Charset charset = Charset.defaultCharset();
        Assert.isTrue(charset.equals(Charset.forName("UTF-8")), "The charset must be UTF-8 to start! Please set the default charset to UTF-8 then start again!");

        // Set up the actual locale.
        Locale.setDefault(Locale.ENGLISH);
    }
}
